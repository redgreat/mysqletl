create definer = user_wh@`%` view vi_purchaseinfo as
select `a`.`Id`                                                                                                      AS `Id`,
       `a`.`MainPartId`                                                                                              AS `MainPartId`,
       `fn_GetMainPartNameById`(`a`.`MainPartId`)                                                                    AS `MainPartName`,
       `a`.`OwnerId`                                                                                                 AS `OwnerId`,
       `b`.`ShortName`                                                                                               AS `OwnerShortName`,
       `a`.`PlanNo`                                                                                                  AS `PlanNo`,
       `a`.`PurchaseNo`                                                                                              AS `PurchaseNo`,
       `a`.`PurchaseType`                                                                                            AS `PurchaseTypeId`,
       (case `a`.`PurchaseType`
            when 'CG0' then '采购订货'
            when 'CG1' then '采购退货'
            when 'CG2' then '采购换出'
            when 'CG3' then '采购换入'
            when 'SC0' then '生产入库'
            when 'SC1' then '生产退货'
            when 'DG0' then '代管订货'
            when 'DG1' then '代管退货'
            when 'TG0' then '推广出库'
            when 'TG1'
                then '推广退货' end)                                                                                 AS `PurchaseTypeName`,
       `a`.`SupplierConcat`                                                                                          AS `SupplierConcat`,
       `a`.`ParentWarehouseId`                                                                                       AS `ParentWarehouseId`,
       ifnull(`fn_GetWarehouseNameById`(`a`.`ParentWarehouseId`),
              `fn_GetSupplierNameById`(`a`.`ParentWarehouseId`))                                                     AS `ParentWarehouseName`,
       `a`.`WarehouseId`                                                                                             AS `WarehouseId`,
       ifnull(`fn_GetWarehouseNameById`(`a`.`WarehouseId`),
              `fn_GetSupplierNameById`(`a`.`WarehouseId`))                                                           AS `WarehouseName`,
       `a`.`PurchasePerson`                                                                                          AS `PurchasePerson`,
       `a`.`PurchaseName`                                                                                            AS `PurchaseName`,
       `a`.`AuditPerson`                                                                                             AS `AuditPerson`,
       `a`.`AuditName`                                                                                               AS `AuditName`,
       `a`.`AuditTime`                                                                                               AS `AuditTime`,
       `a`.`AuditState`                                                                                              AS `AuditState`,
       `a`.`PlanPrice`                                                                                               AS `PlanPrice`,
       `a`.`PurchasePrice`                                                                                           AS `PurchasePrice`,
       `a`.`TicketType`                                                                                              AS `TicketType`,
       (case `a`.`TicketType`
            when 0 then '不开票'
            when 1 then '增值税专用发票'
            when 2 then '增值税普通发票'
            when 3
                then 'invoice' end)                                                                                  AS `TicketTypeName`,
       `a`.`IsPament`                                                                                                AS `IsPament`,
       `a`.`PredictTime`                                                                                             AS `PredictTime`,
       `a`.`Remark`                                                                                                  AS `Remark`,
       1                                                                                                             AS `SortOrder`,
       `a`.`CreatedAt`                                                                                               AS `CreatedAt`
from (`whcenter`.`tb_purchaseinfo` `a` left join `whcenter`.`tb_ownerinfo` `b`
      on (((`a`.`OwnerId` = `b`.`Id`) and (`b`.`Deleted` = 0))))
where (`a`.`Deleted` = 0);

-- comment on column vi_purchaseinfo.Id not supported: 主键(PC)

-- comment on column vi_purchaseinfo.MainPartId not supported: 业务所属Id(tb_mainpartinfo.Id)

-- comment on column vi_purchaseinfo.OwnerId not supported: 货主主表Id(tb_ownerinfo.Id)

-- comment on column vi_purchaseinfo.OwnerShortName not supported: 货主简称

-- comment on column vi_purchaseinfo.PlanNo not supported: 计划单编码

-- comment on column vi_purchaseinfo.PurchaseNo not supported: 采购单号

-- comment on column vi_purchaseinfo.PurchaseTypeId not supported: 采购单类型(CG0 采购订货 CG1 采购退货 CG2 采购换出 CG3 采购换入SC0 生产入库 SC1 生产出库 DG0 代管订货 DG1 代管退货  TG0 推广出库 TG1 推广退货)

-- comment on column vi_purchaseinfo.SupplierConcat not supported: 采购商名称拼接

-- comment on column vi_purchaseinfo.ParentWarehouseId not supported: 上级仓库Id(tb_warehouse.Id)

-- comment on column vi_purchaseinfo.WarehouseId not supported: 仓库Id(tb_warehouse.Id)

-- comment on column vi_purchaseinfo.PurchasePerson not supported: 下单人Code

-- comment on column vi_purchaseinfo.PurchaseName not supported: 下单人姓名

-- comment on column vi_purchaseinfo.AuditPerson not supported: 审核人Code

-- comment on column vi_purchaseinfo.AuditName not supported: 审核人姓名

-- comment on column vi_purchaseinfo.AuditTime not supported: 审核时间

-- comment on column vi_purchaseinfo.AuditState not supported: 单据状态(0未提交1待收货2收货中3已收货4已收货(正常)5已收货(异常)6已撤回7待发货8已发货9已退回10确认收款后状态,仅用于Log记录)

-- comment on column vi_purchaseinfo.PlanPrice not supported: 应收金额

-- comment on column vi_purchaseinfo.PurchasePrice not supported: 实付金额

-- comment on column vi_purchaseinfo.TicketType not supported: 开票类型(0 不开票 1 增值税专用发票 2 普通发票 3 invoice)

-- comment on column vi_purchaseinfo.IsPament not supported: 是否付款(0未付款1已付款)

-- comment on column vi_purchaseinfo.PredictTime not supported: 预计到货时间

-- comment on column vi_purchaseinfo.Remark not supported: 备注

