create definer = user_wh@`%` view vi_unsalableinfo as
select `a`.`Id`                                   AS `Id`,
       `a`.`MainPartId`                           AS `MainPartId`,
       `fn_GetMainPartNameById`(`a`.`MainPartId`) AS `MainPartName`,
       `a`.`MaterialId`                           AS `MaterialId`,
       `a`.`MaterialName`                         AS `MaterialName`,
       `a`.`SubmitPerson`                         AS `SubmitPerson`,
       `a`.`SubmitName`                           AS `SubmitName`,
       `a`.`SubmitTime`                           AS `SubmitTime`,
       `a`.`Enable`                               AS `Enable`,
       1                                          AS `SortOrder`
from `whcenter`.`tb_unsalableinfo` `a`
where (`a`.`Deleted` = 0);

-- comment on column vi_unsalableinfo.Id not supported: 主键(UI)

-- comment on column vi_unsalableinfo.MainPartId not supported: 业务所属Id(tb_mainpartinfo.Id)

-- comment on column vi_unsalableinfo.MaterialId not supported: 物料Id

-- comment on column vi_unsalableinfo.MaterialName not supported: 物料名称

-- comment on column vi_unsalableinfo.SubmitPerson not supported: 提交人编码

-- comment on column vi_unsalableinfo.SubmitName not supported: 提交人姓名

-- comment on column vi_unsalableinfo.SubmitTime not supported: 提交时间

-- comment on column vi_unsalableinfo.Enable not supported: 是否启用(0否1是)

