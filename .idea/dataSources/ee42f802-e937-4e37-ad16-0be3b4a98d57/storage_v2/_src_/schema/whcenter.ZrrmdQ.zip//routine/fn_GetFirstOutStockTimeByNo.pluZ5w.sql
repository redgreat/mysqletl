create
    definer = user_wh@`%` function fn_GetFirstOutStockTimeByNo(InNo varchar(50)) returns datetime sql security invoker
BEGIN
DECLARE OutTime datetime;

SELECT a.AuditTime INTO OutTime
FROM tb_outstockinfohis a,
tb_outstockdetailhis b,
tb_outstockno c
WHERE c.DetailId = b.Id
AND b.OutStockId = a.Id
AND c.MaterialNo = InNo
AND a.OutStockType IN ('OT3','OT8')
AND a.Deleted = 0
AND b.Deleted = 0
AND c.Deleted = 0
ORDER BY a.AuditTime DESC
LIMIT 1;


RETURN OutTime;
END;

