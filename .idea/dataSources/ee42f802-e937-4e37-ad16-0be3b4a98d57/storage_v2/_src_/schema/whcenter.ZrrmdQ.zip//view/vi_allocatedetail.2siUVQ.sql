create definer = user_wh@`%` view vi_allocatedetail as
select `a`.`Id`                                                                            AS `Id`,
       `a`.`MainPartId`                                                                    AS `MainPartId`,
       `a`.`ToMainPartId`                                                                  AS `ToMainPartId`,
       `fn_GetMainPartNameById`(`a`.`MainPartId`)                                          AS `MainPartName`,
       `fn_GetMainPartNameById`(`a`.`ToMainPartId`)                                        AS `ToMainPartName`,
       `a`.`CrossMainPart`                                                                 AS `CrossMainPart`,
       `a`.`AllocateNo`                                                                    AS `AllocateNo`,
       `a`.`AllocateType`                                                                  AS `AllocateTypeId`,
       (case `a`.`AllocateType` when 'DB0' then '调拨入库' when 'DB1' then '调拨出库' end) AS `OutStockTypeName`,
       `a`.`WarehouseId`                                                                   AS `WarehouseId`,
       `fn_GetWarehouseNameById`(`a`.`WarehouseId`)                                        AS `WarehouseName`,
       `a`.`ToWarehouseId`                                                                 AS `ToWarehouseId`,
       `fn_GetWarehouseNameById`(`a`.`ToWarehouseId`)                                      AS `ToWarehouseName`,
       `a`.`AllocatePerson`                                                                AS `AllocatePerson`,
       `a`.`AllocateName`                                                                  AS `AllocateName`,
       `a`.`AuditPerson`                                                                   AS `AuditPerson`,
       `a`.`AuditName`                                                                     AS `AuditName`,
       `a`.`AuditState`                                                                    AS `AuditState`,
       `a`.`AuditTime`                                                                     AS `AuditTime`,
       `a`.`IsUrgent`                                                                      AS `IsUrgent`,
       `c`.`LinkMan`                                                                       AS `LinkMan`,
       `c`.`LinkTel`                                                                       AS `LinkTel`,
       `c`.`ProCode`                                                                       AS `ProCode`,
       `fn_GetDistrictNameByCode`(`c`.`ProCode`)                                           AS `ProName`,
       `c`.`CityCode`                                                                      AS `CityCode`,
       `fn_GetDistrictNameByCode`(`c`.`CityCode`)                                          AS `CityName`,
       `c`.`DeliveAddress`                                                                 AS `DeliveAddress`,
       `a`.`PredictTime`                                                                   AS `PredictTime`,
       `b`.`OutStockNo`                                                                    AS `OutStockNo`,
       `a`.`Remark`                                                                        AS `Remark`,
       1                                                                                   AS `SortOrder`
from ((`whcenter`.`tb_allocateinfo` `a` join `whcenter`.`tb_outstockinfo` `b`
       on (((`b`.`OrderId` = `a`.`Id`) and (`b`.`Deleted` = 0)))) left join `whcenter`.`tb_stockdeliveinfo` `c`
      on ((`c`.`StockId` = `a`.`Id`)))
where (`a`.`Deleted` = 0);

-- comment on column vi_allocatedetail.Id not supported: 主键(AC)

-- comment on column vi_allocatedetail.MainPartId not supported: 业务所属Id(tb_mainpartinfo.Id)

-- comment on column vi_allocatedetail.ToMainPartId not supported: 调拨到业务所属Id

-- comment on column vi_allocatedetail.CrossMainPart not supported: 是否跨货主调拨(0否1是)

-- comment on column vi_allocatedetail.AllocateNo not supported: 调拨单号

-- comment on column vi_allocatedetail.AllocateTypeId not supported: 调拨单类型（DB0 调拨入 DB1 调拨出）

-- comment on column vi_allocatedetail.WarehouseId not supported: 所出仓Id(tb_warehouse.Id)

-- comment on column vi_allocatedetail.ToWarehouseId not supported: 所入仓库Id(tb_warehouse.Id)

-- comment on column vi_allocatedetail.AllocatePerson not supported: 下单人Code

-- comment on column vi_allocatedetail.AllocateName not supported: 下单人姓名

-- comment on column vi_allocatedetail.AuditPerson not supported: 审核人Code

-- comment on column vi_allocatedetail.AuditName not supported: 审核人姓名

-- comment on column vi_allocatedetail.AuditState not supported: 单据状态(0未提交1待发货2已发货3已回执4已退回)

-- comment on column vi_allocatedetail.AuditTime not supported: 审核时间

-- comment on column vi_allocatedetail.IsUrgent not supported: 是否加急(0否1是)

-- comment on column vi_allocatedetail.LinkMan not supported: 收货人

-- comment on column vi_allocatedetail.LinkTel not supported: 收货人联系方式

-- comment on column vi_allocatedetail.ProCode not supported: 省份Code

-- comment on column vi_allocatedetail.CityCode not supported: 城市Code

-- comment on column vi_allocatedetail.DeliveAddress not supported: 收货地址

-- comment on column vi_allocatedetail.PredictTime not supported: 预计发货时间

-- comment on column vi_allocatedetail.OutStockNo not supported: 出库单No

-- comment on column vi_allocatedetail.Remark not supported: 备注

