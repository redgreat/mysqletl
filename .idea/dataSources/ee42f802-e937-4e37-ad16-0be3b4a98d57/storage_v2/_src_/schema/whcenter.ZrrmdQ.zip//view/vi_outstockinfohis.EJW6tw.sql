create definer = user_wh@`%` view vi_outstockinfohis as
select `a`.`Id`                                                                           AS `Id`,
       `a`.`MainPartId`                                                                   AS `MainPartId`,
       `a`.`ToMainPartId`                                                                 AS `ToMainPartId`,
       `fn_GetMainPartNameById`(`a`.`MainPartId`)                                         AS `MainPartName`,
       `fn_GetMainPartNameById`(`a`.`ToMainPartId`)                                       AS `ToMainPartName`,
       `a`.`OrderId`                                                                      AS `OrderId`,
       `a`.`OrderNo`                                                                      AS `OrderNo`,
       `a`.`OutStockNo`                                                                   AS `OutStockNo`,
       `a`.`OutStockType`                                                                 AS `OutStockType`,
       `fn_GetStockTypeById`(`a`.`OutStockType`)                                          AS `OutStockTypeName`,
       `a`.`WarehouseId`                                                                  AS `WarehouseId`,
       `a`.`WarehouseName`                                                                AS `WarehouseName`,
       `a`.`ParentWarehouseId`                                                            AS `ParentWarehouseId`,
       ifnull(`fn_GetWholeWarehouseNameById`(`a`.`WarehouseId`), `a`.`WarehouseName`)     AS `ConcatWarehouseName`,
       `a`.`ToWarehouseId`                                                                AS `ToWarehouseId`,
       `a`.`ToWarehouseName`                                                              AS `ToWarehouseName`,
       ifnull(`fn_GetWholeWarehouseNameById`(`a`.`ToWarehouseId`), `a`.`ToWarehouseName`) AS `ToConcatWarehouseName`,
       `a`.`ToParentWarehouseId`                                                          AS `ToParentWarehouseId`,
       `a`.`OutStockPerson`                                                               AS `OutStockPerson`,
       `a`.`OutStockName`                                                                 AS `OutStockName`,
       `a`.`AuditState`                                                                   AS `AuditState`,
       `a`.`AuditPerson`                                                                  AS `AuditPerson`,
       `a`.`AuditName`                                                                    AS `AuditName`,
       `a`.`AuditTime`                                                                    AS `AuditTime`,
       `b`.`LinkMan`                                                                      AS `LinkMan`,
       `b`.`LinkTel`                                                                      AS `LinkTel`,
       concat(`fn_GetDistrictNameByCode`(`b`.`ProCode`), `fn_GetDistrictNameByCode`(`b`.`CityCode`),
              `b`.`DeliveAddress`)                                                        AS `DeliveAddress`,
       `a`.`CustSettleId`                                                                 AS `CustSettleId`,
       `a`.`CustSettleName`                                                               AS `CustSettleName`,
       `a`.`IsReceive`                                                                    AS `IsReceive`,
       `a`.`IsUrgent`                                                                     AS `IsUrgent`,
       `a`.`Remark`                                                                       AS `Remark`,
       `a`.`InRelated`                                                                    AS `InRelated`,
       `a`.`CreatedAt`                                                                    AS `CreatedAt`,
       1                                                                                  AS `SortOrder`
from (`whcenter`.`tb_outstockinfohis` `a` left join `whcenter`.`tb_stockdeliveinfo` `b`
      on (((`b`.`StockId` = `a`.`Id`) and (`b`.`Deleted` = 0))))
where (`a`.`Deleted` = 0);

-- comment on column vi_outstockinfohis.Id not supported: 主键(OT)

-- comment on column vi_outstockinfohis.MainPartId not supported: 业务所属Id(tb_mainpartinfo.Id)

-- comment on column vi_outstockinfohis.ToMainPartId not supported: 调拨到业务所属Id

-- comment on column vi_outstockinfohis.OrderId not supported: 订单Id/调拨单Id

-- comment on column vi_outstockinfohis.OrderNo not supported: 订单编码/调拨单编码

-- comment on column vi_outstockinfohis.OutStockNo not supported: 出库单No

-- comment on column vi_outstockinfohis.OutStockType not supported: 出库类型(OT0 采购出库  OT1 迁移出库 OT2 调拨出库 OT3 批发出库 OT4 更换出库 OT5 组装出库 OT6 拆装出库 OT7修改出库 OT8 零售出库 OT9物资损耗出库 OT10 采购换货出库 OT11 生产退货出库 OT12 货主交易出库 OT13 代管出库 OT14 推广出库 OT15 货主变更出库 OT16 迁移更换出库)

-- comment on column vi_outstockinfohis.WarehouseId not supported: 所出仓库Id(tb_warehouse.Id)

-- comment on column vi_outstockinfohis.WarehouseName not supported: 所出仓库名称

-- comment on column vi_outstockinfohis.ParentWarehouseId not supported: 上级仓库Id(tb_warehouse.Id)

-- comment on column vi_outstockinfohis.ToWarehouseId not supported: 所入仓库Id(tb_warehouse.Id)

-- comment on column vi_outstockinfohis.ToWarehouseName not supported: 所入仓库名称

-- comment on column vi_outstockinfohis.ToParentWarehouseId not supported: 到上级仓库Id(tb_warehouse.Id)

-- comment on column vi_outstockinfohis.OutStockPerson not supported: 下单人Code

-- comment on column vi_outstockinfohis.OutStockName not supported: 下单人姓名

-- comment on column vi_outstockinfohis.AuditState not supported: 单据状态(0待发货1备货中2待审核3已发货4已回执)

-- comment on column vi_outstockinfohis.AuditPerson not supported: 审核人Code

-- comment on column vi_outstockinfohis.AuditName not supported: 审核人姓名

-- comment on column vi_outstockinfohis.AuditTime not supported: 审核时间

-- comment on column vi_outstockinfohis.LinkMan not supported: 收货人

-- comment on column vi_outstockinfohis.LinkTel not supported: 收货人联系方式

-- comment on column vi_outstockinfohis.CustSettleId not supported: 结算单位Id

-- comment on column vi_outstockinfohis.CustSettleName not supported: 结算单位名称

-- comment on column vi_outstockinfohis.IsReceive not supported: 是否确认应收(0否1是)

-- comment on column vi_outstockinfohis.IsUrgent not supported: 是否加急(0否1是)

-- comment on column vi_outstockinfohis.Remark not supported: 备注

-- comment on column vi_outstockinfohis.InRelated not supported: 对应换货单关系Id

