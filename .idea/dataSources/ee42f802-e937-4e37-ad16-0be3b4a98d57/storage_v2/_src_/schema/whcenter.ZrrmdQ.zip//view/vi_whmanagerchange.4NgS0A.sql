create definer = user_wh@`%` view vi_whmanagerchange as
select `b`.`Id`                                          AS `Id`,
       `b`.`WarehouseId`                                 AS `WarehouseId`,
       `a`.`MainPartId`                                  AS `MainPartId`,
       `a`.`Name`                                        AS `WarehouseName`,
       `a`.`Mode`                                        AS `Mode`,
       `b`.`ManagerType`                                 AS `ManagerType`,
       `fn_GetWholeWarehouseNameById`(`b`.`WarehouseId`) AS `ConcatWarehouseName`,
       `b`.`UserId`                                      AS `UserId`,
       `b`.`LoginName`                                   AS `LoginName`,
       `b`.`UserName`                                    AS `UserName`,
       `b`.`UserTel`                                     AS `UserTel`
from (`whcenter`.`tb_warehouse` `a` join `whcenter`.`tb_whmanager` `b` on ((`a`.`Id` = `b`.`WarehouseId`)))
where ((`a`.`Mode` in (0, 1, 2)) and (`a`.`LevelCode` = 2) and (`a`.`Enable` = 1) and (`a`.`Deleted` = 0) and
       (`b`.`Deleted` = 0));

-- comment on column vi_whmanagerchange.Id not supported: 主键

-- comment on column vi_whmanagerchange.WarehouseId not supported: 仓库Id(tb_warehouse.Id)

-- comment on column vi_whmanagerchange.MainPartId not supported: 业务所属Id(tb_mainpartinfo.Id)

-- comment on column vi_whmanagerchange.WarehouseName not supported: 仓库名称

-- comment on column vi_whmanagerchange.Mode not supported: 经营模式(0普通仓1优工仓2门店仓3数据仓4租赁仓5自营仓6客户仓)

-- comment on column vi_whmanagerchange.ManagerType not supported: 管理人员类型(0仓库负责人1盘点管理员2 售后仓默认管理人员)

-- comment on column vi_whmanagerchange.UserId not supported: 用户Id

-- comment on column vi_whmanagerchange.LoginName not supported: 管理人员Code

-- comment on column vi_whmanagerchange.UserName not supported: 管理人员名称

-- comment on column vi_whmanagerchange.UserTel not supported: 负责人联系方式

