create
    definer = user_wh@`%` function fn_GetChackManagerIdByWarehouseId(InWarehouseId char(12)) returns char(36)
    sql security invoker
BEGIN
DECLARE OutManagerId CHAR(36);
SELECT a.UserId INTO OutManagerId
FROM tb_whmanager a
WHERE a.WarehouseId = InWarehouseId
AND a.ManagerType = 1
AND a.Deleted = 0
ORDER BY a.CreatedAt DESC
LIMIT 1;
RETURN OutManagerId;
END;

