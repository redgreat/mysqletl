create definer = user_wh@`%` view vi_synstockinfo as
select `a`.`Id`                                                                    AS `Id`,
       `a`.`MainPartId`                                                            AS `MainPartId`,
       `a`.`OwnerId`                                                               AS `OwnerId`,
       `b`.`ShortName`                                                             AS `OwnerShortName`,
       `FN_GETMAINPARTNAMEBYID`(`a`.`MainPartId`)                                  AS `MainPartName`,
       `a`.`SynStockNo`                                                            AS `SynStockNo`,
       `a`.`SynStockType`                                                          AS `SynStockType`,
       (case `a`.`SynStockType` when 'SC0' then '组装' when 'SC1' then '拆装' end) AS `SynStockTypeName`,
       `a`.`WarehouseId`                                                           AS `WarehouseId`,
       `FN_GETWAREHOUSENAMEBYID`(`a`.`WarehouseId`)                                AS `WarehouseName`,
       `a`.`MaterialId`                                                            AS `MaterialId`,
       `a`.`MaterialName`                                                          AS `MaterialName`,
       `a`.`MaterialType`                                                          AS `MaterialType`,
       `a`.`MaterialTypeCode`                                                      AS `MaterialTypeCode`,
       `a`.`MaterialUnit`                                                          AS `MaterialUnit`,
       `a`.`SynStatus`                                                             AS `SynStatus`,
       `a`.`SubmitPerson`                                                          AS `SubmitPerson`,
       `a`.`SubmitName`                                                            AS `SubmitName`,
       `a`.`SubmitTime`                                                            AS `SubmitTime`,
       1                                                                           AS `SortOrder`
from (`whcenter`.`tb_synstockinfo` `a` left join `whcenter`.`tb_ownerinfo` `b`
      on (((`a`.`OwnerId` = `b`.`Id`) and (`b`.`Deleted` = 0))))
where (`a`.`Deleted` = 0);

-- comment on column vi_synstockinfo.Id not supported: 主键(SS)

-- comment on column vi_synstockinfo.MainPartId not supported: 业务所属Id(tb_mainpartinfo.Id)

-- comment on column vi_synstockinfo.OwnerId not supported: 货主Id

-- comment on column vi_synstockinfo.OwnerShortName not supported: 货主简称

-- comment on column vi_synstockinfo.SynStockNo not supported: 生产单号

-- comment on column vi_synstockinfo.SynStockType not supported: 生产方式(SC0 组装 SC1 拆装)

-- comment on column vi_synstockinfo.WarehouseId not supported: 仓库Id(tb_warehouse.Id)

-- comment on column vi_synstockinfo.MaterialId not supported: 物料部件Id

-- comment on column vi_synstockinfo.MaterialName not supported: 物料部件名称

-- comment on column vi_synstockinfo.MaterialType not supported: 物料类型

-- comment on column vi_synstockinfo.MaterialTypeCode not supported: 物料类型编码

-- comment on column vi_synstockinfo.MaterialUnit not supported: 物料单位

-- comment on column vi_synstockinfo.SynStatus not supported: 组装单据状态(0未提交1已提交)

-- comment on column vi_synstockinfo.SubmitPerson not supported: 提交人

-- comment on column vi_synstockinfo.SubmitName not supported: 提交人姓名

-- comment on column vi_synstockinfo.SubmitTime not supported: 提交时间

