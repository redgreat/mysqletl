create
    definer = user_wh@`%` function fn_GetDefaultManagerCodeByWarehouseId(InWarehouseId char(12)) returns varchar(50)
    sql security invoker
BEGIN
DECLARE OutManagerCode varchar(50);
SELECT a.LoginName INTO OutManagerCode
FROM tb_whmanager a
WHERE a.WarehouseId = InWarehouseId
AND a.ManagerType = 0
AND a.IsDefault = 1
AND a.Deleted = 0
ORDER BY a.CreatedAt DESC
LIMIT 1;

RETURN OutManagerCode;
END;

