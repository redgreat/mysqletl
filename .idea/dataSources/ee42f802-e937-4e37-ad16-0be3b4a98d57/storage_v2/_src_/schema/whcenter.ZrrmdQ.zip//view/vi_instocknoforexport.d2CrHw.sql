create definer = user_wh@`%` view vi_instocknoforexport as
select `c`.`Id`                                                                       AS `Id`,
       `b`.`Id`                                                                       AS `DetailId`,
       `a`.`MainPartId`                                                               AS `MainPartId`,
       `a`.`FromMainPartId`                                                           AS `FromMainPartId`,
       `fn_GetMainPartNameById`(`a`.`MainPartId`)                                     AS `MainPartName`,
       `fn_GetMainPartNameById`(`a`.`FromMainPartId`)                                 AS `FromMainPartName`,
       `c`.`OwnerId`                                                                  AS `OwnerId`,
       `fn_GetOwnerNameById`(`c`.`OwnerId`)                                           AS `OwnerName`,
       `a`.`WarehouseId`                                                              AS `WarehouseId`,
       `a`.`WarehouseName`                                                            AS `WarehouseName`,
       ifnull(`fn_GetWholeWarehouseNameById`(`a`.`WarehouseId`), `a`.`WarehouseName`) AS `ConcatWarehouseName`,
       `a`.`ParentWarehouseId`                                                        AS `ParentWarehouseId`,
       `fn_GetWarehouseNameById`(`a`.`ParentWarehouseId`)                             AS `ParentWarehouseName`,
       ifnull(`b`.`SupplierId`, `a`.`FromWarehouseId`)                                AS `FromWarehouseId`,
       ifnull(`fn_GetSupplierNameById`(`b`.`SupplierId`), `a`.`FromWarehouseName`)    AS `FromWarehouseName`,
       `a`.`FromParentWarehouseId`                                                    AS `FromParentWarehouseId`,
       `fn_GetWarehouseNameById`(`a`.`FromParentWarehouseId`)                         AS `FromParentWarehouseName`,
       `a`.`InStockNo`                                                                AS `InStockNo`,
       `a`.`InStockType`                                                              AS `InStockType`,
       `fn_GetStockTypeById`(`a`.`InStockType`)                                       AS `InStockTypeName`,
       `b`.`MaterialId`                                                               AS `MaterialId`,
       `b`.`MaterialName`                                                             AS `MaterialName`,
       `b`.`MaterialType`                                                             AS `MaterialType`,
       `c`.`MaterialNo`                                                               AS `MaterialNo`,
       0                                                                              AS `StockStatus`,
       1                                                                              AS `SortOrder`
from ((`whcenter`.`tb_instockinfo` `a` join `whcenter`.`tb_instockdetail` `b`
       on (((`b`.`InStockId` = `a`.`Id`) and (`b`.`Deleted` = 0)))) join `whcenter`.`tb_instockno` `c`
      on (((`c`.`DetailId` = `b`.`Id`) and (`c`.`Deleted` = 0))))
where (`a`.`Deleted` = 0);

-- comment on column vi_instocknoforexport.Id not supported: 自增主键

-- comment on column vi_instocknoforexport.DetailId not supported: 主键(ID)

-- comment on column vi_instocknoforexport.MainPartId not supported: 业务所属Id(tb_mainpartinfo.Id)

-- comment on column vi_instocknoforexport.FromMainPartId not supported: 调拨源业务所属Id

-- comment on column vi_instocknoforexport.OwnerId not supported: 货主Id(tb_ownerinfo.Id)

-- comment on column vi_instocknoforexport.WarehouseId not supported: 所入仓库Id(tb_warehouse.Id)

-- comment on column vi_instocknoforexport.WarehouseName not supported: 所入仓库名称

-- comment on column vi_instocknoforexport.ParentWarehouseId not supported: 上级仓库Id(tb_warehouse.Id)

-- comment on column vi_instocknoforexport.FromParentWarehouseId not supported: 到上级仓库Id(tb_warehouse.Id)

-- comment on column vi_instocknoforexport.InStockNo not supported: 入库单编码

-- comment on column vi_instocknoforexport.InStockType not supported: 入库单类型(IN0 采购入库 IN1 迁移入库 IN2 调拨入库 IN3 退货入库 IN4 更换入库 IN5 组装入库 IN6 拆装入库 IN7 修改入库 IN8 采购换货入库 IN9 生产入库 IN10 货主交易入库 IN11 代管入库 IN12 推广入库 IN13 货主变更入库 IN14 迁移更换入库)

-- comment on column vi_instocknoforexport.MaterialId not supported: 物料Id

-- comment on column vi_instocknoforexport.MaterialName not supported: 物料名称

-- comment on column vi_instocknoforexport.MaterialType not supported: 物料类型

