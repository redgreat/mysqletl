create definer = user_wh@`%` view vi_purchasedetail as
select `a`.`Id`                        AS `Id`,
       `a`.`PurchaseId`                AS `PurchaseId`,
       `a`.`SupplierId`                AS `SupplierId`,
       `b`.`ShortName`                 AS `SupplierName`,
       `a`.`MaterialId`                AS `MaterialId`,
       `a`.`MaterialName`              AS `MaterialName`,
       `a`.`MaterialType`              AS `MaterialType`,
       `a`.`MaterialTypeCode`          AS `MaterialTypeCode`,
       `a`.`MaterialUnit`              AS `MaterialUnit`,
       `a`.`PurchaseNum`               AS `PurchaseNum`,
       `a`.`SurplusNum`                AS `SurplusNum`,
       `a`.`StockPrice`                AS `StockPrice`,
       `a`.`IsCodeSingle`              AS `IsCodeSingle`,
       `a`.`TaxPoint`                  AS `TaxPoint`,
       `a`.`TicketType`                AS `TicketType`,
       (case `a`.`TicketType`
            when 0 then '不开票'
            when 1 then '增值税专用发票'
            when 2 then '增值税普通发票'
            when 3 then 'invoice' end) AS `TicketTypeName`,
       1                               AS `SortOrder`
from (`whcenter`.`tb_purchasedetail` `a` left join `whcenter`.`tb_supplier` `b`
      on (((`b`.`Id` = `a`.`SupplierId`) and (`b`.`Deleted` = 0))))
where (`a`.`Deleted` = 0);

-- comment on column vi_purchasedetail.Id not supported: 主键(‘PD’)

-- comment on column vi_purchasedetail.PurchaseId not supported: 采购单Id(tb_purchaseinfo.Id)

-- comment on column vi_purchasedetail.SupplierId not supported: 供应商Id(tb_supplier.Id)

-- comment on column vi_purchasedetail.SupplierName not supported: 供应商简称

-- comment on column vi_purchasedetail.MaterialId not supported: 物料Id

-- comment on column vi_purchasedetail.MaterialName not supported: 物料名称

-- comment on column vi_purchasedetail.MaterialType not supported: 物料类型

-- comment on column vi_purchasedetail.MaterialTypeCode not supported: 物料类型Code

-- comment on column vi_purchasedetail.MaterialUnit not supported: 物料单位

-- comment on column vi_purchasedetail.PurchaseNum not supported: 采购单总数量

-- comment on column vi_purchasedetail.SurplusNum not supported: 剩余数量

-- comment on column vi_purchasedetail.StockPrice not supported: 建议采购价

-- comment on column vi_purchasedetail.IsCodeSingle not supported: 是否独立编码(0非独立编码1独立编码)

-- comment on column vi_purchasedetail.TaxPoint not supported: 开票税点

-- comment on column vi_purchasedetail.TicketType not supported: 开票类型(0不开票1增值税专用发票2普通发票)

