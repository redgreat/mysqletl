create definer = user_wh@`%` view vi_allocatebatchdetail as
select `b`.`Id`                                          AS `Id`,
       `a`.`MainPartId`                                  AS `MainPartId`,
       `fn_GetMainPartNameById`(`a`.`MainPartId`)        AS `MainPartName`,
       `a`.`BatchNo`                                     AS `BatchNo`,
       `a`.`BatchType`                                   AS `BatchType`,
       `a`.`WarehouseId`                                 AS `WarehouseId`,
       `fn_GetWholeWarehouseNameById`(`a`.`WarehouseId`) AS `WarehouseName`,
       `a`.`AuditState`                                  AS `AuditState`,
       `a`.`AllocatePerson`                              AS `AllocatePerson`,
       `a`.`AllocateName`                                AS `AllocateName`,
       `a`.`AuditPerson`                                 AS `AuditPerson`,
       `a`.`AuditName`                                   AS `AuditName`,
       `a`.`IsUrgent`                                    AS `IsUrgent`,
       `b`.`LinkMan`                                     AS `LinkMan`,
       `b`.`LinkTel`                                     AS `LinkTel`,
       `b`.`DeliveAddress`                               AS `DeliveAddress`,
       `a`.`PredictTime`                                 AS `PredictTime`,
       `a`.`Remark`                                      AS `Remark`
from (`whcenter`.`tb_allocatebatchinfo` `a` left join `whcenter`.`tb_stockdeliveinfo` `b`
      on (((`b`.`StockId` = `a`.`Id`) and (`b`.`Deleted` = 0) and (`a`.`Deleted` = 0))));

-- comment on column vi_allocatebatchdetail.Id not supported: 自增主键

-- comment on column vi_allocatebatchdetail.MainPartId not supported: 业务所属Id(tb_mainpartinfo.Id)

-- comment on column vi_allocatebatchdetail.BatchNo not supported: 调拨单号

-- comment on column vi_allocatebatchdetail.BatchType not supported: 批量调拨类型（DB0 调拨入 DB1 调拨出）

-- comment on column vi_allocatebatchdetail.WarehouseId not supported: 调拨入仓Id(tb_warehouse.Id)

-- comment on column vi_allocatebatchdetail.AuditState not supported: 单据状态(0已退回1待发货2备货中3待审核4已发货)

-- comment on column vi_allocatebatchdetail.AllocatePerson not supported: 下单人Code

-- comment on column vi_allocatebatchdetail.AllocateName not supported: 下单人姓名

-- comment on column vi_allocatebatchdetail.AuditPerson not supported: 审核人Code

-- comment on column vi_allocatebatchdetail.AuditName not supported: 审核人姓名

-- comment on column vi_allocatebatchdetail.IsUrgent not supported: 是否加急(0否1是)

-- comment on column vi_allocatebatchdetail.LinkMan not supported: 收货人

-- comment on column vi_allocatebatchdetail.LinkTel not supported: 收货人联系方式

-- comment on column vi_allocatebatchdetail.DeliveAddress not supported: 收货地址

-- comment on column vi_allocatebatchdetail.PredictTime not supported: 预计发货时间

-- comment on column vi_allocatebatchdetail.Remark not supported: 备注

