create definer = user_wh@`%` view vi_allocatematerial as
select `a`.`Id`               AS `Id`,
       `a`.`AllocateId`       AS `AllocateId`,
       `a`.`MaterialId`       AS `MaterialId`,
       `a`.`MaterialName`     AS `MaterialName`,
       `a`.`MaterialType`     AS `MaterialType`,
       `a`.`MaterialTypeCode` AS `MaterialTypeCode`,
       `a`.`MaterialUnit`     AS `MaterialUnit`,
       `a`.`AllocateNum`      AS `AllocateNum`,
       `a`.`IsCodeSingle`     AS `IsCodeSingle`,
       1                      AS `SortOrder`
from `whcenter`.`tb_allocatedetail` `a`
where (`a`.`Deleted` = 0);

-- comment on column vi_allocatematerial.Id not supported: 主键(AD)

-- comment on column vi_allocatematerial.AllocateId not supported: 调拨主单Id(tb_allocateinfo.Id)

-- comment on column vi_allocatematerial.MaterialId not supported: 物料Id

-- comment on column vi_allocatematerial.MaterialName not supported: 物料名称

-- comment on column vi_allocatematerial.MaterialType not supported: 物料类型

-- comment on column vi_allocatematerial.MaterialTypeCode not supported: 物料类型Code

-- comment on column vi_allocatematerial.MaterialUnit not supported: 物料单位

-- comment on column vi_allocatematerial.AllocateNum not supported: 调拨数量

-- comment on column vi_allocatematerial.IsCodeSingle not supported: 是否独立编码(0否1是)

