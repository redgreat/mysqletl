create
    definer = user_wh@`%` function fn_GetDefaultManagerByWarehouseId(InWarehouseId char(12)) returns varchar(50)
    sql security invoker
BEGIN
DECLARE OutManagerName varchar(50);
SELECT a.UserName INTO OutManagerName
FROM tb_whmanager a
WHERE a.WarehouseId = InWarehouseId
AND a.ManagerType = 0
AND a.IsDefault = 1
AND a.Deleted = 0
ORDER BY a.CreatedAt DESC
LIMIT 1;

RETURN OutManagerName;
END;

