create definer = user_wh@`%` view vi_customerconfiginfo as
select `a`.`Id`                                   AS `Id`,
       `a`.`MainPartId`                           AS `MainPartId`,
       `fn_GetMainPartNameById`(`a`.`MainPartId`) AS `MainPartName`,
       `a`.`CustomerId`                           AS `CustomerId`,
       `a`.`CustomerName`                         AS `CustomerName`,
       `a`.`CustomerRules`                        AS `CustomerRules`,
       `a`.`CreatedById`                          AS `CreatedById`,
       `a`.`CreatedAt`                            AS `CreatedAt`,
       `a`.`UpdatedById`                          AS `UpdatedById`,
       `a`.`UpdatedAt`                            AS `UpdatedAt`,
       `a`.`DeletedById`                          AS `DeletedById`,
       `a`.`DeletedAt`                            AS `DeletedAt`,
       `a`.`Deleted`                              AS `Deleted`
from `whcenter`.`tb_customerconfiginfo` `a`
where (`a`.`Deleted` = 0);

-- comment on column vi_customerconfiginfo.Id not supported: 自增主键

-- comment on column vi_customerconfiginfo.MainPartId not supported: 业务所属Id(tb_mainpartinfo.Id)

-- comment on column vi_customerconfiginfo.CustomerId not supported: 客户Id

-- comment on column vi_customerconfiginfo.CustomerName not supported: 客户名称

-- comment on column vi_customerconfiginfo.CustomerRules not supported: (0禁止修改1有特殊规则)

