create
    definer = user_wh@`%` function fn_GetDisableTimeByWarehouseId(InWarehsoueId char(12)) returns datetime
    sql security invoker
BEGIN
 DECLARE OutCloseTime datetime;

  SELECT a.AuditTime INTO OutCloseTime
  FROM tb_auditlog a
  WHERE a.StockId = InWarehsoueId
    AND a.AuditType = 4
    AND a.AuditState = 0
    AND a.Deleted = 0
  ORDER BY a.AuditTime DESC
  LIMIT 1;

RETURN OutCloseTime;
END;

