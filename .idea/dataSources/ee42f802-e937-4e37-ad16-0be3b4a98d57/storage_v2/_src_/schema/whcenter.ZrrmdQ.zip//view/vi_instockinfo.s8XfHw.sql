create definer = user_wh@`%` view vi_instockinfo as
select `a`.`Id`                                                                               AS `Id`,
       `a`.`MainPartId`                                                                       AS `MainPartId`,
       `a`.`FromMainPartId`                                                                   AS `FromMainPartId`,
       `fn_GetMainPartNameById`(`a`.`MainPartId`)                                             AS `MainPartName`,
       `fn_GetMainPartNameById`(`a`.`FromMainPartId`)                                         AS `FromMainPartName`,
       `a`.`OrderId`                                                                          AS `OrderId`,
       `a`.`OrderNo`                                                                          AS `OrderNo`,
       `a`.`InStockNo`                                                                        AS `InStockNo`,
       `a`.`InStockType`                                                                      AS `InStockType`,
       `fn_GetStockTypeById`(`a`.`InStockType`)                                               AS `InStockTypeName`,
       `a`.`WarehouseId`                                                                      AS `WarehouseId`,
       `a`.`WarehouseName`                                                                    AS `WarehouseName`,
       ifnull(`fn_GetWholeWarehouseNameById`(`a`.`WarehouseId`), `a`.`WarehouseName`)         AS `ConcatWarehouseName`,
       `a`.`ParentWarehouseId`                                                                AS `ParentWarehouseId`,
       `a`.`FromWarehouseId`                                                                  AS `FromWarehouseId`,
       `a`.`FromWarehouseName`                                                                AS `FromWarehouseName`,
       `a`.`FromParentWarehouseId`                                                            AS `FromParentWarehouseId`,
       ifnull(`fn_GetWholeWarehouseNameById`(`a`.`FromWarehouseId`),
              `a`.`FromWarehouseName`)                                                        AS `ConcatFromWarehouseName`,
       `a`.`InStockPerson`                                                                    AS `InStockPerson`,
       `a`.`InStockName`                                                                      AS `InStockName`,
       `a`.`AuditState`                                                                       AS `AuditState`,
       `a`.`AuditPerson`                                                                      AS `AuditPerson`,
       `a`.`AuditName`                                                                        AS `AuditName`,
       `a`.`AuditTime`                                                                        AS `AuditTime`,
       `a`.`CustSettleId`                                                                     AS `CustSettleId`,
       `a`.`CustSettleName`                                                                   AS `CustSettleName`,
       `a`.`Remark`                                                                           AS `Remark`,
       `a`.`OutRelated`                                                                       AS `OutRelated`,
       `a`.`CreatedAt`                                                                        AS `CreatedAt`,
       1                                                                                      AS `SortOrder`
from `whcenter`.`tb_instockinfo` `a`
where (`a`.`Deleted` = 0);

-- comment on column vi_instockinfo.Id not supported: 主键(IN)

-- comment on column vi_instockinfo.MainPartId not supported: 业务所属Id(tb_mainpartinfo.Id)

-- comment on column vi_instockinfo.FromMainPartId not supported: 调拨源业务所属Id

-- comment on column vi_instockinfo.OrderId not supported: 订单Id/调拨单Id

-- comment on column vi_instockinfo.OrderNo not supported: 订单编码/调拨单编码

-- comment on column vi_instockinfo.InStockNo not supported: 入库单编码

-- comment on column vi_instockinfo.InStockType not supported: 入库单类型(IN0 采购入库 IN1 迁移入库 IN2 调拨入库 IN3 退货入库 IN4 更换入库 IN5 组装入库 IN6 拆装入库 IN7 修改入库 IN8 采购换货入库 IN9 生产入库 IN10 货主交易入库 IN11 代管入库 IN12 推广入库 IN13 货主变更入库 IN14 迁移更换入库)

-- comment on column vi_instockinfo.WarehouseId not supported: 所入仓库Id(tb_warehouse.Id)

-- comment on column vi_instockinfo.WarehouseName not supported: 所入仓库名称

-- comment on column vi_instockinfo.ParentWarehouseId not supported: 上级仓库Id(tb_warehouse.Id)

-- comment on column vi_instockinfo.FromWarehouseId not supported: 所出仓库Id(tb_warehouse.Id)

-- comment on column vi_instockinfo.FromWarehouseName not supported: 所出仓库名称

-- comment on column vi_instockinfo.FromParentWarehouseId not supported: 到上级仓库Id(tb_warehouse.Id)

-- comment on column vi_instockinfo.InStockPerson not supported: 下单人Code

-- comment on column vi_instockinfo.InStockName not supported: 下单人姓名

-- comment on column vi_instockinfo.AuditState not supported: 单据状态(0待收货1收货中2已收货)

-- comment on column vi_instockinfo.AuditPerson not supported: 审核人Code

-- comment on column vi_instockinfo.AuditName not supported: 审核人姓名

-- comment on column vi_instockinfo.AuditTime not supported: 审核时间

-- comment on column vi_instockinfo.CustSettleId not supported: 结算单位Id

-- comment on column vi_instockinfo.CustSettleName not supported: 结算单位名称

-- comment on column vi_instockinfo.Remark not supported: 备注

-- comment on column vi_instockinfo.OutRelated not supported: 对应换货单关系Id

