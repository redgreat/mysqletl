create definer = user_wh@`%` view vi_stockinfoextra as
select `fn_GetStockMaxId`()                       AS `Id`,
       `c`.`MainPartId`                           AS `MainPartId`,
       `fn_GetMainPartNameById`(`c`.`MainPartId`) AS `MainPartName`,
       `c`.`Id`                                   AS `WarehouseId`,
       `c`.`Name`                                 AS `WarehouseName`,
       `c`.`Type`                                 AS `Type`,
       '实体仓'                                   AS `实体仓`,
       `c`.`Mode`                                 AS `Mode`,
       (case `a`.`Mode`
            when 0 then '普通仓'
            when 1 then '优工仓'
            when 2 then '门店仓'
            when 3 then '数据仓'
            when 4 then '租赁仓' end)             AS `ModeName`,
       NULL                                       AS `NULL`,
       NULL                                       AS `My_exp_NULL`,
       `b`.`MaterialType`                         AS `MaterialType`,
       `b`.`MaterialId`                           AS `MaterialId`,
       `b`.`MaterialName`                         AS `MaterialName`,
       `b`.`IsCodeSingle`                         AS `IsCodeSingle`,
       if((`d`.`Id` is null), '否', '是')         AS `IsUnSalable`,
       0                                          AS `StockNum`,
       0                                          AS `RealityNum`,
       1                                          AS `LevelCode`,
       1                                          AS `SortOrder`
from (((`whcenter`.`tb_warehouse` `a` left join `whcenter`.`tb_stockinfo` `b`
        on (((`b`.`WarehouseId` = `a`.`Id`) and (`b`.`Deleted` = 0)))) left join `whcenter`.`tb_warehouse` `c`
       on (((`c`.`Id` = `a`.`ParentId`) and (`c`.`Deleted` = 0)))) left join `whcenter`.`tb_unsalableinfo` `d`
      on (((`d`.`MaterialId` = `b`.`MaterialId`) and (`d`.`MainPartId` = `c`.`MainPartId`) and (`d`.`Deleted` = 0) and
           (`d`.`Enable` = 1))))
where ((`a`.`LevelCode` = 2) and (`c`.`LevelCode` = 1) and (`b`.`MaterialId` is not null) and exists(select 1
                                                                                                     from `whcenter`.`tb_stockinfo` `d`
                                                                                                     where ((`d`.`WarehouseId` = `c`.`Id`) and (`d`.`Deleted` = 0))) is false);

-- comment on column vi_stockinfoextra.MainPartId not supported: 业务所属Id(tb_mainpartinfo.Id)

-- comment on column vi_stockinfoextra.WarehouseId not supported: 主键Id(WH)

-- comment on column vi_stockinfoextra.WarehouseName not supported: 仓库名称

-- comment on column vi_stockinfoextra.Type not supported: 仓库属性(0虚拟仓1实体仓)

-- comment on column vi_stockinfoextra.Mode not supported: 经营模式(0普通仓1优工仓2门店仓3数据仓4租赁仓5自营仓6客户仓)

-- comment on column vi_stockinfoextra.MaterialType not supported: 物料类型名称

-- comment on column vi_stockinfoextra.MaterialId not supported: 物料Id

-- comment on column vi_stockinfoextra.MaterialName not supported: 物料名称

-- comment on column vi_stockinfoextra.IsCodeSingle not supported: 是否独立编码(0否1是)

