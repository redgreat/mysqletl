create definer = user_wh@`%` view vi_stockwarningconfig as
select `tdetai`.`Id`                                      AS `Id`,
       `tdetai`.`StockWarringId`                          AS `StockWarringId`,
       `tconfig`.`MainPartId`                             AS `MainPartId`,
       `fn_GetMainPartNameById`(`tconfig`.`MainPartId`)   AS `MainPartName`,
       `tconfig`.`WHLevelCode`                            AS `WHLevelCode`,
       `tconfig`.`WHMode`                                 AS `WHMode`,
       `tconfig`.`WarehouseId`                            AS `WarehouseId`,
       `fn_GetWarehouseNameById`(`tconfig`.`WarehouseId`) AS `WarehouseName`,
       `tconfig`.`MaterialType`                           AS `MaterialType`,
       `tconfig`.`MaterialName`                           AS `MaterialName`,
       `tdetai`.`LimitType`                               AS `LimitType`,
       `tdetai`.`UpperLimitValueType`                     AS `UpperLimitValueType`,
       `tdetai`.`UpperLimitValue`                         AS `UpperLimitValue`,
       `tdetai`.`LowerLimitValueType`                     AS `LowerLimitValueType`,
       `tdetai`.`LowerLimitValue`                         AS `LowerLimitValue`,
       `tconfig`.`Priority`                               AS `Priority`
from (`whcenter`.`tb_stockwarningconfig` `tconfig` join `whcenter`.`tb_stockwarningconfigdetail` `tdetai`)
where ((`tconfig`.`Deleted` = 0) and (`tdetai`.`Deleted` = 0) and (`tconfig`.`Id` = `tdetai`.`StockWarringId`));

-- comment on column vi_stockwarningconfig.Id not supported: 自增主键

-- comment on column vi_stockwarningconfig.StockWarringId not supported: 库存预警配置表Id(tb_stockwarningconfig.Id)

-- comment on column vi_stockwarningconfig.MainPartId not supported: 业务所属Id

-- comment on column vi_stockwarningconfig.WHLevelCode not supported: 仓库等级

-- comment on column vi_stockwarningconfig.WarehouseId not supported: 一级仓Id

-- comment on column vi_stockwarningconfig.MaterialType not supported: 物料类型

-- comment on column vi_stockwarningconfig.MaterialName not supported: 物料名称

-- comment on column vi_stockwarningconfig.LimitType not supported: 预警类型(0上月出库量为01上月出库量不为0)

-- comment on column vi_stockwarningconfig.UpperLimitValueType not supported: 上限值类型(0无1数值2百分比)

-- comment on column vi_stockwarningconfig.UpperLimitValue not supported: 上限值数量

-- comment on column vi_stockwarningconfig.LowerLimitValueType not supported: 下限值类型(0无1数值2百分比)

-- comment on column vi_stockwarningconfig.LowerLimitValue not supported: 下限值数量

-- comment on column vi_stockwarningconfig.Priority not supported: 优先级

