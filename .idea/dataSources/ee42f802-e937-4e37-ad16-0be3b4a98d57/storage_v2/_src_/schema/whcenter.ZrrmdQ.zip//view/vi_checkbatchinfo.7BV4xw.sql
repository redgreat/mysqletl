create definer = user_wh@`%` view vi_checkbatchinfo as
select `a`.`Id`           AS `Id`,
       `a`.`BatchNo`      AS `BatchNo`,
       `a`.`SubmitPerson` AS `SubmitPerson`,
       `a`.`SubmitName`   AS `SubmitName`,
       `a`.`SubmitTime`   AS `SubmitTime`,
       `a`.`StartTime`    AS `StartTime`,
       `a`.`EndTime`      AS `EndTime`,
       `a`.`BatchStatus`  AS `BatchStatus`,
       `a`.`IsAutoStart`  AS `IsAutoStart`,
       `a`.`IsAutoEnd`    AS `IsAutoEnd`,
       1                  AS `SortOrder`
from `whcenter`.`tb_checkbatchinfo` `a`
where (`a`.`Deleted` = 0);

-- comment on column vi_checkbatchinfo.Id not supported: 主键(BT)

-- comment on column vi_checkbatchinfo.BatchNo not supported: 批次编号

-- comment on column vi_checkbatchinfo.SubmitPerson not supported: 提交人Code

-- comment on column vi_checkbatchinfo.SubmitName not supported: 提交人姓名

-- comment on column vi_checkbatchinfo.SubmitTime not supported: 提交时间

-- comment on column vi_checkbatchinfo.StartTime not supported: 开始时间

-- comment on column vi_checkbatchinfo.EndTime not supported: 盘点结束时间

-- comment on column vi_checkbatchinfo.BatchStatus not supported: 状态(0待处理1进行中2盘点中3待提交4已结束)

-- comment on column vi_checkbatchinfo.IsAutoStart not supported: 是否自动开始(0否1是)

-- comment on column vi_checkbatchinfo.IsAutoEnd not supported: 是否自动结束(0否1是)

