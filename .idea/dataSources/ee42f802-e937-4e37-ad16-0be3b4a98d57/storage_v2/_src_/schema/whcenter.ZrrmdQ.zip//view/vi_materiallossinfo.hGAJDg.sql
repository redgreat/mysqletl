create definer = user_wh@`%` view vi_materiallossinfo as
select `a`.`Id`                                           AS `Id`,
       `a`.`MainPartId`                                   AS `MainPartId`,
       `fn_GetMainPartNameById`(`a`.`MainPartId`)         AS `MainPartName`,
       `a`.`LossNo`                                       AS `LossNo`,
       `a`.`LossType`                                     AS `LossType`,
       (case `a`.`LossType` when 'ML0' then '损耗' end)   AS `LossTypeName`,
       `a`.`WarehouseId`                                  AS `WarehouseId`,
       `fn_GetWarehouseNameById`(`a`.`WarehouseId`)       AS `WarehouseName`,
       `fn_GetWholeWarehouseNameById`(`a`.`WarehouseId`)  AS `ConcatWarehouseName`,
       `a`.`ParentWarehouseId`                            AS `ParentWarehouseId`,
       `fn_GetWarehouseNameById`(`a`.`ParentWarehouseId`) AS `ParentWarehouseName`,
       `a`.`ToWarehouseId`                                AS `ToWarehouseId`,
       `a`.`ToWarehouseName`                              AS `ToWarehouseName`,
       `a`.`LossPerson`                                   AS `LossPerson`,
       `a`.`LossName`                                     AS `LossName`,
       `a`.`AuditPerson`                                  AS `AuditPerson`,
       `a`.`AuditName`                                    AS `AuditName`,
       `a`.`AuditTime`                                    AS `AuditTime`,
       `a`.`AuditState`                                   AS `AuditState`,
       `a`.`LossReasonCode`                               AS `LossReasonCode`,
       `a`.`LossReasonName`                               AS `LossReasonName`,
       `a`.`Remark`                                       AS `Remark`,
       1                                                  AS `SortOrder`,
       `a`.`CreatedById`                                  AS `CreatedById`,
       `a`.`CreatedAt`                                    AS `CreatedAt`,
       `a`.`UpdatedById`                                  AS `UpdatedById`,
       `a`.`UpdatedAt`                                    AS `UpdatedAt`,
       `a`.`DeletedById`                                  AS `DeletedById`,
       `a`.`DeletedAt`                                    AS `DeletedAt`,
       `a`.`Deleted`                                      AS `Deleted`
from `whcenter`.`tb_materiallossinfo` `a`;

-- comment on column vi_materiallossinfo.Id not supported: 主键(ML)

-- comment on column vi_materiallossinfo.MainPartId not supported: 业务所属Id(tb_mainpartinfo.Id)

-- comment on column vi_materiallossinfo.LossNo not supported: 损耗单号

-- comment on column vi_materiallossinfo.LossType not supported: 损耗单类型（ML01 物资损耗）

-- comment on column vi_materiallossinfo.WarehouseId not supported: 所出仓Id(tb_warehouse.Id)

-- comment on column vi_materiallossinfo.ParentWarehouseId not supported: 所出上级仓库Id(tb_warehouse.Id)

-- comment on column vi_materiallossinfo.ToWarehouseId not supported: 所入位置Id(data_dictionary.Id)

-- comment on column vi_materiallossinfo.ToWarehouseName not supported: 所入位置名称(data_dictionary.Name)

-- comment on column vi_materiallossinfo.LossPerson not supported: 下单人Code

-- comment on column vi_materiallossinfo.LossName not supported: 下单人姓名

-- comment on column vi_materiallossinfo.AuditPerson not supported: 审核人Code

-- comment on column vi_materiallossinfo.AuditName not supported: 审核人姓名

-- comment on column vi_materiallossinfo.AuditTime not supported: 审核时间

-- comment on column vi_materiallossinfo.AuditState not supported: 单据状态(0待审核1待发货2已发货3未通过4已退回)

-- comment on column vi_materiallossinfo.LossReasonCode not supported: 出库原因Code(basic_dictionary.Code)

-- comment on column vi_materiallossinfo.LossReasonName not supported: 出库原因名称(basic_dictionary.Name)

-- comment on column vi_materiallossinfo.Remark not supported: 备注

