create definer = user_wh@`%` view vi_materialcusttrace as
select `a`.`Id`                                   AS `Id`,
       `a`.`MaterialNo`                           AS `MaterialNo`,
       `a`.`StockStatus`                          AS `StockStatus`,
       `a`.`MaterialId`                           AS `MaterialId`,
       `a`.`MaterialName`                         AS `MaterialName`,
       `a`.`MaterialType`                         AS `MaterialType`,
       `a`.`MaterialTypeCode`                     AS `MaterialTypeCode`,
       `a`.`StockLocationId`                      AS `StockLocationId`,
       `a`.`StockLocationName`                    AS `StockLocationName`,
       `a`.`LastStockId`                          AS `LastStockId`,
       `a`.`LastStockNo`                          AS `LastStockNo`,
       `a`.`LastDetailId`                         AS `LastDetailId`,
       `a`.`LastStockType`                        AS `LastStockType`,
       `fn_GetStockTypeById`(`a`.`LastStockType`) AS `LastStockTypeName`,
       `a`.`CustSettleId`                         AS `CustSettleId`,
       `a`.`CustSettleName`                       AS `CustSettleName`,
       `a`.`LastAuditTime`                        AS `AuditTime`,
       1                                          AS `SortOrder`
from (`whcenter`.`tb_materialcust` `a` left join `whcenter`.`tb_unsalableinfo` `b`
      on (((`b`.`MaterialId` = `a`.`MaterialId`) and (`b`.`Enable` = 1) and (`b`.`Deleted` = 0))))
where (`a`.`Deleted` = 0);

-- comment on column vi_materialcusttrace.Id not supported: 自增主键

-- comment on column vi_materialcusttrace.MaterialNo not supported: 物料编码

-- comment on column vi_materialcusttrace.StockStatus not supported: 设备在库状态(0未加装1已加装2已拆装)

-- comment on column vi_materialcusttrace.MaterialId not supported: 物料类型Id

-- comment on column vi_materialcusttrace.MaterialName not supported: 物料名称

-- comment on column vi_materialcusttrace.MaterialType not supported: 物料类型

-- comment on column vi_materialcusttrace.MaterialTypeCode not supported: 物料类型Code

-- comment on column vi_materialcusttrace.StockLocationId not supported: 所在位置Id(仓库Id/门店Id)

-- comment on column vi_materialcusttrace.StockLocationName not supported: 所在位置名称(仓库名称/门店名称)

-- comment on column vi_materialcusttrace.LastStockId not supported: 最后一次出入库Id

-- comment on column vi_materialcusttrace.LastStockNo not supported: 最后一次出入库编码

-- comment on column vi_materialcusttrace.LastDetailId not supported: 最后一次出入库明细Id

-- comment on column vi_materialcusttrace.LastStockType not supported: 最后一次出入库类型

-- comment on column vi_materialcusttrace.CustSettleId not supported: 结算单位Id

-- comment on column vi_materialcusttrace.CustSettleName not supported: 结算单位名称

-- comment on column vi_materialcusttrace.AuditTime not supported: 最后一次审核时间

