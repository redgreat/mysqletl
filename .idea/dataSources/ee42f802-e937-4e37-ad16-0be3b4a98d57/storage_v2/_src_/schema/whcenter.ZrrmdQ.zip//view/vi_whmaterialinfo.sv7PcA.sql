create definer = user_wh@`%` view vi_whmaterialinfo as
select `b`.`Id`                                   AS `Id`,
       `a`.`MainPartId`                           AS `MainPartId`,
       `fn_GetMainPartNameById`(`a`.`MainPartId`) AS `MainPartName`,
       `a`.`Id`                                   AS `WarehouseId`,
       `a`.`Name`                                 AS `WarehouseName`,
       `b`.`MaterialId`                           AS `MaterialId`,
       `b`.`MaterialName`                         AS `MaterialName`,
       `b`.`MaterialType`                         AS `MaterialType`,
       `b`.`MaterialTypeCode`                     AS `MaterialTypeCode`,
       `b`.`Enable`                               AS `Enable`,
       `b`.`CreatedById`                          AS `CreatedById`,
       `b`.`CreatedAt`                            AS `CreatedAt`,
       `b`.`UpdatedById`                          AS `UpdatedById`,
       `b`.`UpdatedAt`                            AS `UpdatedAt`,
       `b`.`DeletedById`                          AS `DeletedById`,
       `b`.`DeletedAt`                            AS `DeletedAt`,
       `b`.`Deleted`                              AS `Deleted`
from (`whcenter`.`tb_warehouse` `a` join `whcenter`.`tb_whmaterialinfo` `b` on ((`b`.`WarehouseId` = `a`.`Id`)))
where (`a`.`Deleted` = 0);

-- comment on column vi_whmaterialinfo.Id not supported: 自增主键

-- comment on column vi_whmaterialinfo.MainPartId not supported: 业务所属Id(tb_mainpartinfo.Id)

-- comment on column vi_whmaterialinfo.WarehouseId not supported: 主键Id(WH)

-- comment on column vi_whmaterialinfo.WarehouseName not supported: 仓库名称

-- comment on column vi_whmaterialinfo.MaterialId not supported: 物料Id

-- comment on column vi_whmaterialinfo.MaterialName not supported: 物料名称

-- comment on column vi_whmaterialinfo.MaterialType not supported: 物料类型

-- comment on column vi_whmaterialinfo.MaterialTypeCode not supported: 物料类型Code

-- comment on column vi_whmaterialinfo.Enable not supported: 是否开启(0关闭1开启)

