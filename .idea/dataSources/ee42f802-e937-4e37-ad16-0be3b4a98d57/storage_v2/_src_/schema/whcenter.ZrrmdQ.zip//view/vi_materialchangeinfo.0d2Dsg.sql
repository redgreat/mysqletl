create definer = user_wh@`%` view vi_materialchangeinfo as
select `a`.`Id`                                          AS `Id`,
       `a`.`StockType`                                   AS `StockType`,
       (case `a`.`StockType` when 1 then '采购换货' end) AS `StockTypeName`,
       `a`.`MainpartId`                                  AS `MainpartId`,
       `fn_GetMainPartNameById`(`a`.`MainpartId`)        AS `MainpartName`,
       `a`.`MaterialId`                                  AS `MaterialId`,
       `a`.`MaterialName`                                AS `MaterialName`,
       `a`.`MaterialType`                                AS `MaterialType`,
       `a`.`MaterialTypeCode`                            AS `MaterialTypeCode`,
       `a`.`IsModify`                                    AS `IsModify`,
       `a`.`RuleType`                                    AS `RuleType`,
       `a`.`MaterialNameConcat`                          AS `MaterialNameConcat`,
       `a`.`Enable`                                      AS `Enable`
from `whcenter`.`tb_materialchangeinfo` `a`
where (`a`.`Deleted` = 0);

-- comment on column vi_materialchangeinfo.Id not supported: 主键('MC')

-- comment on column vi_materialchangeinfo.StockType not supported: 适用模块类型(1采购换货2型号变更规则)

-- comment on column vi_materialchangeinfo.MainpartId not supported: 业务所属Id

-- comment on column vi_materialchangeinfo.MaterialId not supported: 物料Id

-- comment on column vi_materialchangeinfo.MaterialName not supported: 物料名称

-- comment on column vi_materialchangeinfo.MaterialType not supported: 物料类型名称

-- comment on column vi_materialchangeinfo.MaterialTypeCode not supported: 物料类型Code

-- comment on column vi_materialchangeinfo.IsModify not supported: 是否允许修改(0否1是)

-- comment on column vi_materialchangeinfo.RuleType not supported: 规则类型(0仅可修改为1禁止修改为)

-- comment on column vi_materialchangeinfo.MaterialNameConcat not supported: 替换物料集合

-- comment on column vi_materialchangeinfo.Enable not supported: 是否启用(0关闭1开启)

