create definer = user_wh@`%` view vi_outstockdetailforexport as
select `b`.`Id`                                                                           AS `Id`,
       `a`.`MainPartId`                                                                   AS `MainPartId`,
       `a`.`ToMainPartId`                                                                 AS `ToMainPartId`,
       `fn_GetMainPartNameById`(`a`.`MainPartId`)                                         AS `MainPartName`,
       `fn_GetMainPartNameById`(`a`.`ToMainPartId`)                                       AS `ToMainPartName`,
       `a`.`Id`                                                                           AS `OutStockId`,
       `a`.`OutStockNo`                                                                   AS `OutStockNo`,
       `a`.`OrderId`                                                                      AS `OrderId`,
       `a`.`OrderNo`                                                                      AS `OrderNo`,
       `a`.`OutStockPerson`                                                               AS `OutStockPerson`,
       `a`.`OutStockName`                                                                 AS `OutStockName`,
       `a`.`AuditState`                                                                   AS `AuditState`,
       `a`.`AuditPerson`                                                                  AS `AuditPerson`,
       `a`.`AuditName`                                                                    AS `AuditName`,
       `a`.`AuditTime`                                                                    AS `AuditTime`,
       `d`.`PredictTime`                                                                  AS `PredictTime`,
       `b`.`GoodsId`                                                                      AS `GoodsId`,
       `b`.`GoodsName`                                                                    AS `GoodsName`,
       `a`.`IsUrgent`                                                                     AS `IsUrgent`,
       `a`.`OutStockType`                                                                 AS `OutStockType`,
       `fn_GetStockTypeById`(`a`.`OutStockType`)                                          AS `OutStockTypeName`,
       `a`.`WarehouseId`                                                                  AS `WarehouseId`,
       `a`.`WarehouseName`                                                                AS `WarehouseName`,
       `a`.`ParentWarehouseId`                                                            AS `ParentWarehouseId`,
       `fn_GetWarehouseNameById`(`a`.`ParentWarehouseId`)                                 AS `ParentWarehouseName`,
       `fn_GetWholeWarehouseNameById`(`a`.`WarehouseId`)                                  AS `ConcatWarehosueName`,
       `a`.`ToWarehouseId`                                                                AS `ToWarehouseId`,
       `a`.`ToWarehouseName`                                                              AS `ToWarehouseName`,
       `a`.`ToParentWarehouseId`                                                          AS `ToParentWarehouseId`,
       `fn_GetWarehouseNameById`(`a`.`ToParentWarehouseId`)                               AS `ToParentWarehouseName`,
       ifnull(`fn_GetWholeWarehouseNameById`(`a`.`ToWarehouseId`), `a`.`ToWarehouseName`) AS `ConcatToWarehosueName`,
       `b`.`MaterialId`                                                                   AS `MaterialId`,
       `b`.`MaterialName`                                                                 AS `MaterialName`,
       `b`.`MaterialType`                                                                 AS `MaterialType`,
       `b`.`MaterialTypeCode`                                                             AS `MaterialTypeCode`,
       `b`.`MaterialUnit`                                                                 AS `MaterialUnit`,
       `b`.`ReservoirCode`                                                                AS `ReservoirCode`,
       `b`.`OutStockNum`                                                                  AS `OutStockNum`,
       `b`.`OutStockedNum`                                                                AS `OutStockedNum`,
       `b`.`OutStockPrice`                                                                AS `OutStockPrice`,
       `b`.`IsCodeSingle`                                                                 AS `IsCodeSingle`,
       `c`.`LinkMan`                                                                      AS `LinkMan`,
       `c`.`LinkTel`                                                                      AS `LinkTel`,
       `c`.`ProCode`                                                                      AS `ProCode`,
       `fn_GetDistrictNameByCode`(`c`.`ProCode`)                                          AS `ProName`,
       `c`.`CityCode`                                                                     AS `CityCode`,
       `fn_GetDistrictNameByCode`(`c`.`CityCode`)                                         AS `CityName`,
       concat(`fn_GetDistrictNameByCode`(`c`.`ProCode`), `fn_GetDistrictNameByCode`(`c`.`CityCode`),
              `c`.`DeliveAddress`)                                                        AS `DeliveAddress`,
       `a`.`Remark`                                                                       AS `Remark`,
       `fn_GetPackageTypeById`(`a`.`Id`)                                                  AS `PackageType`,
       1                                                                                  AS `SortOrder`
from (((`whcenter`.`tb_outstockinfo` `a` join `whcenter`.`tb_outstockdetail` `b`
        on (((`a`.`Id` = `b`.`OutStockId`) and (`b`.`Deleted` = 0)))) left join `whcenter`.`tb_stockdeliveinfo` `c`
       on (((`c`.`StockId` = `a`.`Id`) and (`c`.`Deleted` = 0)))) left join `whcenter`.`tb_allocateinfo` `d`
      on (((`d`.`Id` = `a`.`OrderId`) and (`d`.`Deleted` = 0))))
where (`a`.`Deleted` = 0);

-- comment on column vi_outstockdetailforexport.Id not supported: 主键(OD)

-- comment on column vi_outstockdetailforexport.MainPartId not supported: 业务所属Id(tb_mainpartinfo.Id)

-- comment on column vi_outstockdetailforexport.ToMainPartId not supported: 调拨到业务所属Id

-- comment on column vi_outstockdetailforexport.OutStockId not supported: 主键(OT)

-- comment on column vi_outstockdetailforexport.OutStockNo not supported: 出库单No

-- comment on column vi_outstockdetailforexport.OrderId not supported: 订单Id/调拨单Id

-- comment on column vi_outstockdetailforexport.OrderNo not supported: 订单编码/调拨单编码

-- comment on column vi_outstockdetailforexport.OutStockPerson not supported: 下单人Code

-- comment on column vi_outstockdetailforexport.OutStockName not supported: 下单人姓名

-- comment on column vi_outstockdetailforexport.AuditState not supported: 单据状态(0待发货1备货中2待审核3已发货4已回执)

-- comment on column vi_outstockdetailforexport.AuditPerson not supported: 审核人Code

-- comment on column vi_outstockdetailforexport.AuditName not supported: 审核人姓名

-- comment on column vi_outstockdetailforexport.AuditTime not supported: 审核时间

-- comment on column vi_outstockdetailforexport.PredictTime not supported: 预计发货时间

-- comment on column vi_outstockdetailforexport.GoodsId not supported: 订单出货商品Id

-- comment on column vi_outstockdetailforexport.GoodsName not supported: 订单出货商品名称

-- comment on column vi_outstockdetailforexport.IsUrgent not supported: 是否加急(0否1是)

-- comment on column vi_outstockdetailforexport.OutStockType not supported: 出库类型(OT0 采购出库  OT1 迁移出库 OT2 调拨出库 OT3 批发出库 OT4 更换出库 OT5 组装出库 OT6 拆装出库 OT7修改出库 OT8 零售出库 OT9物资损耗出库 OT10 采购换货出库 OT11 生产退货出库 OT12 货主交易出库 OT13 代管出库 OT14 推广出库 OT15 货主变更出库 OT16 迁移更换出库)

-- comment on column vi_outstockdetailforexport.WarehouseId not supported: 所出仓库Id(tb_warehouse.Id)

-- comment on column vi_outstockdetailforexport.WarehouseName not supported: 所出仓库名称

-- comment on column vi_outstockdetailforexport.ParentWarehouseId not supported: 上级仓库Id(tb_warehouse.Id)

-- comment on column vi_outstockdetailforexport.ToWarehouseId not supported: 所入仓库Id(tb_warehouse.Id)

-- comment on column vi_outstockdetailforexport.ToWarehouseName not supported: 所入仓库名称

-- comment on column vi_outstockdetailforexport.ToParentWarehouseId not supported: 到上级仓库Id(tb_warehouse.Id)

-- comment on column vi_outstockdetailforexport.MaterialId not supported: 物料Id

-- comment on column vi_outstockdetailforexport.MaterialName not supported: 物料名称

-- comment on column vi_outstockdetailforexport.MaterialType not supported: 物料类型

-- comment on column vi_outstockdetailforexport.MaterialTypeCode not supported: 物料类型Code

-- comment on column vi_outstockdetailforexport.MaterialUnit not supported: 物料单位

-- comment on column vi_outstockdetailforexport.ReservoirCode not supported: 库区Id(tb_whreservoir.Code)

-- comment on column vi_outstockdetailforexport.OutStockNum not supported: 应出库数量

-- comment on column vi_outstockdetailforexport.OutStockedNum not supported: 已出库数量

-- comment on column vi_outstockdetailforexport.OutStockPrice not supported: 出库价格

-- comment on column vi_outstockdetailforexport.IsCodeSingle not supported: 是否独立编码(0否1是)

-- comment on column vi_outstockdetailforexport.LinkMan not supported: 收货人

-- comment on column vi_outstockdetailforexport.LinkTel not supported: 收货人联系方式

-- comment on column vi_outstockdetailforexport.ProCode not supported: 省份Code

-- comment on column vi_outstockdetailforexport.CityCode not supported: 城市Code

-- comment on column vi_outstockdetailforexport.Remark not supported: 备注

