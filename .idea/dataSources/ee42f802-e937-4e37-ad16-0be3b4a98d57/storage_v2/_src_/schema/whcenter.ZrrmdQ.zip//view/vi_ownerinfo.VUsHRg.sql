create definer = user_wh@`%` view vi_ownerinfo as
select `a`.`Id`                                   AS `Id`,
       `a`.`MainPartId`                           AS `MainPartId`,
       `fn_GetMainPartNameById`(`a`.`MainPartId`) AS `MainPartName`,
       `a`.`OwnerMainPartId`                      AS `OwnerMainPartId`,
       `a`.`Name`                                 AS `Name`,
       `a`.`ShortName`                            AS `ShortName`,
       `a`.`IsPurchase`                           AS `IsPurchase`,
       `a`.`OwnerType`                            AS `OwnerType`,
       `a`.`Enable`                               AS `Enable`,
       `a`.`CreatedById`                          AS `CreatedById`,
       `a`.`CreatedAt`                            AS `CreatedAt`,
       `a`.`UpdatedById`                          AS `UpdatedById`,
       `a`.`UpdatedAt`                            AS `UpdatedAt`,
       `a`.`DeletedById`                          AS `DeletedById`,
       `a`.`DeletedAt`                            AS `DeletedAt`,
       `a`.`Deleted`                              AS `Deleted`
from `whcenter`.`tb_ownerinfo` `a`
where (`a`.`Deleted` = 0);

-- comment on column vi_ownerinfo.Id not supported: 主键('ON')

-- comment on column vi_ownerinfo.MainPartId not supported: 业务所属Id

-- comment on column vi_ownerinfo.OwnerMainPartId not supported: 货主Id(取自客户中心我方签约主体)

-- comment on column vi_ownerinfo.Name not supported: 货主名称

-- comment on column vi_ownerinfo.ShortName not supported: 货主简称

-- comment on column vi_ownerinfo.IsPurchase not supported: 是否可用于采购/库存管理(0不可以1可以)

-- comment on column vi_ownerinfo.OwnerType not supported: 货主类型(0我方货主1代管货主)

-- comment on column vi_ownerinfo.Enable not supported: 状态(0关闭1开启)

