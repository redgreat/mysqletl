create definer = user_wh@`%` view vi_test as
select '这是个测试视图！' AS `Name`;

