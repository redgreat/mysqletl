create definer = user_wh@`%` view vi_warehouse as
select `a`.`Id`                                                        AS `Id`,
       `a`.`MainPartId`                                                AS `MainPartId`,
       `FN_GETMAINPARTNAMEBYID`(`a`.`MainPartId`)                      AS `MainPartName`,
       `a`.`Name`                                                      AS `WarehouseName`,
       `a`.`Type`                                                      AS `Type`,
       (case `a`.`Type` when 0 then '虚拟仓' when 1 then '实体仓' end) AS `TypeName`,
       `a`.`ParentId`                                                  AS `ParentId`,
       `FN_GETWAREHOUSENAMEBYID`(`a`.`ParentId`)                       AS `ParentWarehouseName`,
       `a`.`Mode`                                                      AS `Mode`,
       `FN_GETWAREHOUSMODEBYCODE`(`a`.`Mode`)                          AS `ModeName`,
       `a`.`LevelCode`                                                 AS `LevelCode`,
       `a`.`Enable`                                                    AS `Enable`,
       `a`.`IsWaitTransfer`                                            AS `IsWaitTransfer`,
       `a`.`IsReceipt`                                                 AS `IsReceipt`,
       `a`.`IsAllowTrans`                                              AS `IsAllowTrans`,
       `FN_GETDEFAULTMANAGERCODEBYWAREHOUSEID`(`a`.`Id`)               AS `DefaultManagerCode`,
       `FN_GETDEFAULTMANAGERBYWAREHOUSEID`(`a`.`Id`)                   AS `DefaultManager`,
       `fn_GetCheckManagerIdByWarehouseId`(`a`.`Id`)                   AS `CheckManagerId`,
       `FN_GETCHeCKMANAGERCODEBYWAREHOUSEID`(`a`.`Id`)                 AS `CheckManagerCode`,
       `FN_GETCHeCKMANAGERBYWAREHOUSEID`(`a`.`Id`)                     AS `CheckManager`,
       `b`.`ProCode`                                                   AS `ProCode`,
       `FN_GETDISTRICTNAMEBYCODE`(`b`.`ProCode`)                       AS `ProName`,
       `b`.`CityCode`                                                  AS `CityCode`,
       `FN_GETDISTRICTNAMEBYCODE`(`b`.`CityCode`)                      AS `CityName`,
       `b`.`DeliveAddress`                                             AS `DeliveAddress`,
       `a`.`CustId`                                                    AS `CustId`,
       `a`.`CustName`                                                  AS `CustName`,
       `a`.`CustStoreId`                                               AS `CustStoreId`,
       `a`.`CustStoreCode`                                             AS `CustStoreCode`,
       `a`.`CustStoreName`                                             AS `CustStoreName`,
       `a`.`IsMultiCheck`                                              AS `IsMultiCheck`,
       `a`.`Remark`                                                    AS `Remark`,
       1                                                               AS `SortOrder`
from (`whcenter`.`tb_warehouse` `a` left join `whcenter`.`tb_whaddress` `b`
      on (((`b`.`WarehouseId` = `a`.`Id`) and (`b`.`AddressType` = 0) and (`b`.`Deleted` = 0) and
           (`b`.`IsDefault` = 1))))
where (`a`.`Deleted` = 0);

-- comment on column vi_warehouse.Id not supported: 主键Id(WH)

-- comment on column vi_warehouse.MainPartId not supported: 业务所属Id(tb_mainpartinfo.Id)

-- comment on column vi_warehouse.WarehouseName not supported: 仓库名称

-- comment on column vi_warehouse.Type not supported: 仓库属性(0虚拟仓1实体仓)

-- comment on column vi_warehouse.ParentId not supported: 上级仓Id(tb_warehouse.Id)

-- comment on column vi_warehouse.Mode not supported: 经营模式(0普通仓1优工仓2门店仓3数据仓4租赁仓5自营仓6客户仓)

-- comment on column vi_warehouse.LevelCode not supported: 仓库等级(1一级仓2二级仓)

-- comment on column vi_warehouse.Enable not supported: 开启状态(0关闭1开启)

-- comment on column vi_warehouse.IsWaitTransfer not supported: 是否等待迁移(0否1是)

-- comment on column vi_warehouse.IsReceipt not supported: 是否电子回执(0否1是)

-- comment on column vi_warehouse.IsAllowTrans not supported: 是否允许调入(0否1是)

-- comment on column vi_warehouse.ProCode not supported: 省份Code

-- comment on column vi_warehouse.CityCode not supported: 城市Code

-- comment on column vi_warehouse.DeliveAddress not supported: 详细地址

-- comment on column vi_warehouse.CustId not supported: 客户Id

-- comment on column vi_warehouse.CustName not supported: 客户名称

-- comment on column vi_warehouse.CustStoreId not supported: 门店Id

-- comment on column vi_warehouse.CustStoreCode not supported: 门店Code

-- comment on column vi_warehouse.CustStoreName not supported: 门店名称

-- comment on column vi_warehouse.IsMultiCheck not supported: 是否多人盘点(0否1是)

-- comment on column vi_warehouse.Remark not supported: 备注

