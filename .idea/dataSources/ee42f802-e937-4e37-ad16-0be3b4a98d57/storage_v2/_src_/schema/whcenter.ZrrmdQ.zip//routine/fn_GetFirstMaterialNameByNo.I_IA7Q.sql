create
    definer = user_wh@`%` function fn_GetFirstMaterialNameByNo(InNo varchar(50)) returns varchar(50)
    sql security invoker
BEGIN
DECLARE OutName varchar(50);

SELECT b.MaterialName INTO OutName
FROM tb_instockinfohis a,
tb_instockdetailhis b,
tb_instockno c
WHERE c.DetailId = b.Id
AND b.InStockId = a.Id
AND c.MaterialNo = InNo
AND a.InStockType IN ('IN0','IN1')
AND a.Deleted = 0
AND b.Deleted = 0
AND c.Deleted = 0
ORDER BY a.AuditTime DESC
LIMIT 1;

RETURN OutName;
END;

