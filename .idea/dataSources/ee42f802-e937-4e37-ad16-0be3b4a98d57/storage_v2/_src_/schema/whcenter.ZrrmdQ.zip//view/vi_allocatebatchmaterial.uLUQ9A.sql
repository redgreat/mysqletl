create definer = user_wh@`%` view vi_allocatebatchmaterial as
select `a`.`Id`               AS `Id`,
       `a`.`AllocateBatchId`  AS `AllocateBatchId`,
       `a`.`MaterialId`       AS `MaterialId`,
       `a`.`MaterialName`     AS `MaterialName`,
       `a`.`MaterialType`     AS `MaterialType`,
       `a`.`MaterialTypeCode` AS `MaterialTypeCode`,
       `a`.`MaterialUnit`     AS `MaterialUnit`,
       `a`.`AllocateNum`      AS `AllocateNum`,
       `a`.`IsCodeSingle`     AS `IsCodeSingle`
from `whcenter`.`tb_allocatebatchdetail` `a`
where (`a`.`Deleted` = 0);

-- comment on column vi_allocatebatchmaterial.Id not supported: 主键(BD)

-- comment on column vi_allocatebatchmaterial.AllocateBatchId not supported: 调拨主单Id(tb_allocateinfo.Id)

-- comment on column vi_allocatebatchmaterial.MaterialId not supported: 物料Id

-- comment on column vi_allocatebatchmaterial.MaterialName not supported: 物料名称

-- comment on column vi_allocatebatchmaterial.MaterialType not supported: 物料类型

-- comment on column vi_allocatebatchmaterial.MaterialTypeCode not supported: 物料类型Code

-- comment on column vi_allocatebatchmaterial.MaterialUnit not supported: 物料单位

-- comment on column vi_allocatebatchmaterial.AllocateNum not supported: 调拨数量

-- comment on column vi_allocatebatchmaterial.IsCodeSingle not supported: 是否独立编码(0否1是)

