create definer = user_wh@`%` view vi_stockinfoforzcp as
select ifnull(`b`.`ParentId`, `b`.`Id`)                                                    AS `WarehouseId`,
       if((`b`.`ParentId` is null), `b`.`Name`, `fn_GetWarehouseNameById`(`b`.`ParentId`)) AS `WarehouseName`,
       `a`.`MaterialId`                                                                    AS `MaterialId`,
       `a`.`MaterialName`                                                                  AS `MaterialName`,
       `a`.`MaterialType`                                                                  AS `MaterialType`,
       sum(`a`.`RealityNum`)                                                               AS `RealityNum`
from (`whcenter`.`tb_stockinfo` `a` join `whcenter`.`tb_warehouse` `b` on ((`a`.`WarehouseId` = `b`.`Id`)))
where ((`a`.`Deleted` = 0) and (`b`.`Deleted` = 0))
group by ifnull(`b`.`ParentId`, `b`.`Id`),
         if((`b`.`ParentId` is null), `b`.`Name`, `fn_GetWarehouseNameById`(`b`.`ParentId`)), `a`.`MaterialId`;

-- comment on column vi_stockinfoforzcp.MaterialId not supported: 物料Id

-- comment on column vi_stockinfoforzcp.MaterialName not supported: 物料名称

-- comment on column vi_stockinfoforzcp.MaterialType not supported: 物料类型名称

