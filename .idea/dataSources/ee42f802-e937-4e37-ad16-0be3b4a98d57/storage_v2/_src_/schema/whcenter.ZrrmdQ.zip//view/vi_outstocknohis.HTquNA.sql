create definer = user_wh@`%` view vi_outstocknohis as
select `c`.`Id`                                            AS `Id`,
       `b`.`Id`                                            AS `DetailId`,
       `a`.`MainPartId`                                    AS `MainPartId`,
       `a`.`ToMainPartId`                                  AS `ToMainPartId`,
       `fn_GetMainPartNameById`(`a`.`MainPartId`)          AS `MainPartName`,
       `fn_GetMainPartNameById`(`a`.`ToMainPartId`)        AS `ToMainPartName`,
       `a`.`WarehouseId`                                   AS `WarehouseId`,
       `fn_GetWholeWarehouseNameById`(`a`.`WarehouseId`)   AS `ConcatWarehouseName`,
       `a`.`ParentWarehouseId`                             AS `ParentWarehouseId`,
       `fn_GetWarehouseNameById`(`a`.`ParentWarehouseId`)  AS `ParentWarehouseName`,
       `a`.`ToWarehouseId`                                 AS `ToWarehouseId`,
       `fn_GetWholeWarehouseNameById`(`a`.`ToWarehouseId`) AS `ConcatToWarehouseName`,
       `a`.`ToParentWarehouseId`                           AS `ToParentWarehouseId`,
       `fn_GetWarehouseNameById`(`a`.`ToWarehouseId`)      AS `ToParentWarehouseName`,
       `a`.`OutStockNo`                                    AS `OutStockNo`,
       `a`.`OutStockType`                                  AS `OutStockType`,
       `fn_GetStockTypeById`(`a`.`OutStockType`)           AS `OutStockTypeName`,
       `b`.`MaterialId`                                    AS `MaterialId`,
       `b`.`MaterialName`                                  AS `MaterialName`,
       `b`.`MaterialType`                                  AS `MaterialType`,
       `c`.`MaterialNo`                                    AS `MaterialNo`,
       0                                                   AS `StockStatus`,
       1                                                   AS `SortOrder`
from ((`whcenter`.`tb_outstockinfohis` `a` join `whcenter`.`tb_outstockdetailhis` `b`
       on (((`b`.`OutStockId` = `a`.`Id`) and (`b`.`Deleted` = 0)))) join `whcenter`.`tb_outstockno` `c`
      on (((`c`.`DetailId` = `b`.`Id`) and (`c`.`Deleted` = 0))))
where (`a`.`Deleted` = 0);

-- comment on column vi_outstocknohis.Id not supported: 自增主键

-- comment on column vi_outstocknohis.DetailId not supported: 主键(OD)

-- comment on column vi_outstocknohis.MainPartId not supported: 业务所属Id(tb_mainpartinfo.Id)

-- comment on column vi_outstocknohis.ToMainPartId not supported: 调拨到业务所属Id

-- comment on column vi_outstocknohis.WarehouseId not supported: 所出仓库Id(tb_warehouse.Id)

-- comment on column vi_outstocknohis.ParentWarehouseId not supported: 上级仓库Id(tb_warehouse.Id)

-- comment on column vi_outstocknohis.ToWarehouseId not supported: 所入仓库Id(tb_warehouse.Id)

-- comment on column vi_outstocknohis.ToParentWarehouseId not supported: 到上级仓库Id(tb_warehouse.Id)

-- comment on column vi_outstocknohis.OutStockNo not supported: 出库单No

-- comment on column vi_outstocknohis.OutStockType not supported: 出库类型(OT0 采购出库  OT1 迁移出库 OT2 调拨出库 OT3 批发出库 OT4 更换出库 OT5 组装出库 OT6 拆装出库 OT7修改出库 OT8 零售出库 OT9物资损耗出库 OT10 采购换货出库 OT11 生产退货出库 OT12 货主交易出库 OT13 代管出库 OT14 推广出库 OT15 货主变更出库 OT16 迁移更换出库)

-- comment on column vi_outstocknohis.MaterialId not supported: 物料Id

-- comment on column vi_outstocknohis.MaterialName not supported: 物料名称

-- comment on column vi_outstocknohis.MaterialType not supported: 物料类型

-- comment on column vi_outstocknohis.MaterialNo not supported: 物料编码

