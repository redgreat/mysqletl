create definer = user_wh@`%` view vi_whdepartinfo as
select `a`.`Id`           AS `Id`,
       `a`.`WarehouseId`  AS `WarehouseId`,
       `b`.`Name`         AS `WarehouseName`,
       `a`.`WHDepartId`   AS `WHDepartId`,
       `a`.`WHDepartName` AS `WHDepartName`,
       `a`.`CreatedById`  AS `CreatedById`,
       `a`.`CreatedAt`    AS `CreatedAt`,
       `a`.`UpdatedById`  AS `UpdatedById`,
       `a`.`UpdatedAt`    AS `UpdatedAt`
from (`whcenter`.`tb_whdepartinfo` `a` join `whcenter`.`tb_warehouse` `b`)
where ((`b`.`Id` = `a`.`WarehouseId`) and (`a`.`Deleted` = 0) and (`b`.`Deleted` = 0));

-- comment on column vi_whdepartinfo.Id not supported: 自增序列

-- comment on column vi_whdepartinfo.WarehouseId not supported: 仓库Id(tb_warehouse.Id)

-- comment on column vi_whdepartinfo.WarehouseName not supported: 仓库名称

-- comment on column vi_whdepartinfo.WHDepartId not supported: 部门区域Id

-- comment on column vi_whdepartinfo.WHDepartName not supported: 部门区域名称

