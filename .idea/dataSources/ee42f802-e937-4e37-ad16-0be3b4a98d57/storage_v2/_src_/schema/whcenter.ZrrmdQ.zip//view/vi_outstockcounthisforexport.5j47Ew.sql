create definer = user_wh@`%` view vi_outstockcounthisforexport as
select ifnull(ifnull(`d`.`Id`, `c`.`Id`), `a`.`Id`)         AS `Id`,
       `a`.`MainPartId`                                     AS `MainPartId`,
       `a`.`ToMainPartId`                                   AS `ToMainPartId`,
       `fn_GetMainPartNameById`(`a`.`MainPartId`)           AS `MainPartName`,
       `fn_GetMainPartNameById`(`a`.`ToMainPartId`)         AS `ToMainPartName`,
       `a`.`OrderId`                                        AS `OrderId`,
       `a`.`OrderNo`                                        AS `OrderNo`,
       `a`.`OutStockNo`                                     AS `OutStockNo`,
       `a`.`OutStockType`                                   AS `OutStockType`,
       `fn_GetStockTypeById`(`a`.`OutStockType`)            AS `OutStockTypeName`,
       `a`.`WarehouseId`                                    AS `WarehouseId`,
       `a`.`WarehouseName`                                  AS `WarehouseName`,
       `a`.`ParentWarehouseId`                              AS `ParentWarehouseId`,
       `fn_GetWarehouseNameById`(`a`.`ParentWarehouseId`)   AS `ParentWarehouseName`,
       `a`.`ToWarehouseId`                                  AS `ToWarehouseId`,
       `a`.`ToWarehouseName`                                AS `ToWarehouseName`,
       `a`.`ToParentWarehouseId`                            AS `ToParentWarehouseId`,
       `fn_GetWarehouseNameById`(`a`.`ToParentWarehouseId`) AS `ToParentWarehouseName`,
       `a`.`IsReceive`                                      AS `IsReceive`,
       `a`.`InRelated`                                      AS `InRelated`,
       `c`.`LinkMan`                                        AS `LinkMan`,
       `c`.`LinkTel`                                        AS `LinkTel`,
       `c`.`ProCode`                                        AS `ProCode`,
       `fn_GetDistrictNameByCode`(`c`.`ProCode`)            AS `ProName`,
       `c`.`CityCode`                                       AS `CityCode`,
       `fn_GetDistrictNameByCode`(`c`.`CityCode`)           AS `CityName`,
       `c`.`DeliveAddress`                                  AS `DeliveAddress`,
       `a`.`OutStockPerson`                                 AS `OutStockPerson`,
       `a`.`OutStockName`                                   AS `OutStockName`,
       `fn_GetWirelessNumById`(`a`.`Id`, 0)                 AS `LineCount`,
       `fn_GetWirelessNumById`(`a`.`Id`, 1)                 AS `WirelessCount`,
       `a`.`IsUrgent`                                       AS `IsUrgent`,
       `a`.`AuditState`                                     AS `AuditState`,
       `a`.`AuditPerson`                                    AS `AuditPerson`,
       `a`.`AuditName`                                      AS `AuditName`,
       `a`.`AuditTime`                                      AS `AuditTime`,
       `d`.`ExpressName`                                    AS `ExpressName`,
       `d`.`ExpressNo`                                      AS `ExpressNo`,
       `d`.`ExpressPrice`                                   AS `ExpressPrice`,
       `d`.`ExpressWeight`                                  AS `ExpressWeight`,
       `d`.`Remark`                                         AS `Remark`
from ((`whcenter`.`tb_outstockinfohis` `a` left join `whcenter`.`tb_stockdeliveinfo` `c`
       on (((`c`.`StockId` = `a`.`Id`) and (`c`.`Deleted` = 0)))) left join `whcenter`.`tb_expressinfo` `d`
      on (((`d`.`StockId` = `a`.`Id`) and (`d`.`Deleted` = 0))))
where (`a`.`Deleted` = 0);

-- comment on column vi_outstockcounthisforexport.MainPartId not supported: 业务所属Id(tb_mainpartinfo.Id)

-- comment on column vi_outstockcounthisforexport.ToMainPartId not supported: 调拨到业务所属Id

-- comment on column vi_outstockcounthisforexport.OrderId not supported: 订单Id/调拨单Id

-- comment on column vi_outstockcounthisforexport.OrderNo not supported: 订单编码/调拨单编码

-- comment on column vi_outstockcounthisforexport.OutStockNo not supported: 出库单No

-- comment on column vi_outstockcounthisforexport.OutStockType not supported: 出库类型(OT0 采购出库  OT1 迁移出库 OT2 调拨出库 OT3 批发出库 OT4 更换出库 OT5 组装出库 OT6 拆装出库 OT7修改出库 OT8 零售出库 OT9物资损耗出库 OT10 采购换货出库 OT11 生产退货出库 OT12 货主交易出库 OT13 代管出库 OT14 推广出库 OT15 货主变更出库 OT16 迁移更换出库)

-- comment on column vi_outstockcounthisforexport.WarehouseId not supported: 所出仓库Id(tb_warehouse.Id)

-- comment on column vi_outstockcounthisforexport.WarehouseName not supported: 所出仓库名称

-- comment on column vi_outstockcounthisforexport.ParentWarehouseId not supported: 上级仓库Id(tb_warehouse.Id)

-- comment on column vi_outstockcounthisforexport.ToWarehouseId not supported: 所入仓库Id(tb_warehouse.Id)

-- comment on column vi_outstockcounthisforexport.ToWarehouseName not supported: 所入仓库名称

-- comment on column vi_outstockcounthisforexport.ToParentWarehouseId not supported: 到上级仓库Id(tb_warehouse.Id)

-- comment on column vi_outstockcounthisforexport.IsReceive not supported: 是否确认应收(0否1是)

-- comment on column vi_outstockcounthisforexport.InRelated not supported: 对应换货单关系Id

-- comment on column vi_outstockcounthisforexport.LinkMan not supported: 收货人

-- comment on column vi_outstockcounthisforexport.LinkTel not supported: 收货人联系方式

-- comment on column vi_outstockcounthisforexport.ProCode not supported: 省份Code

-- comment on column vi_outstockcounthisforexport.CityCode not supported: 城市Code

-- comment on column vi_outstockcounthisforexport.DeliveAddress not supported: 收货地址

-- comment on column vi_outstockcounthisforexport.OutStockPerson not supported: 下单人Code

-- comment on column vi_outstockcounthisforexport.OutStockName not supported: 下单人姓名

-- comment on column vi_outstockcounthisforexport.IsUrgent not supported: 是否加急(0否1是)

-- comment on column vi_outstockcounthisforexport.AuditState not supported: 单据状态(0待发货1备货中2待审核3已发货4已回执)

-- comment on column vi_outstockcounthisforexport.AuditPerson not supported: 审核人Code

-- comment on column vi_outstockcounthisforexport.AuditName not supported: 审核人姓名

-- comment on column vi_outstockcounthisforexport.AuditTime not supported: 审核时间

-- comment on column vi_outstockcounthisforexport.ExpressNo not supported: 物流单号

-- comment on column vi_outstockcounthisforexport.ExpressPrice not supported: 物流费用

-- comment on column vi_outstockcounthisforexport.ExpressWeight not supported: 重量

-- comment on column vi_outstockcounthisforexport.Remark not supported: 备注

