create definer = user_wh@`%` view vi_ownersettlerulesinfo as
select `b`.`Id`              AS `Id`,
       `b`.`OwnerId`         AS `OwnerId`,
       `b`.`SaleOwnerId`     AS `SaleOwnerId`,
       `a`.`Name`            AS `SaleOwnerName`,
       `b`.`SettleRulesId`   AS `SettleRulesId`,
       `b`.`SettleRulesName` AS `SettleRulesName`,
       `b`.`SaleType`        AS `SaleType`,
       `b`.`CreatedById`     AS `CreatedById`,
       `b`.`CreatedAt`       AS `CreatedAt`,
       `b`.`UpdatedById`     AS `UpdatedById`,
       `b`.`UpdatedAt`       AS `UpdatedAt`
from (`whcenter`.`tb_ownerinfo` `a` join `whcenter`.`tb_ownersettlerulesinfo` `b`)
where ((`a`.`Id` = `b`.`SaleOwnerId`) and (`a`.`Deleted` = 0) and (`b`.`Deleted` = 0));

-- comment on column vi_ownersettlerulesinfo.Id not supported: 主键('OS')

-- comment on column vi_ownersettlerulesinfo.OwnerId not supported: 货主主表Id(tb_ownerinfo.Id)

-- comment on column vi_ownersettlerulesinfo.SaleOwnerId not supported: 销售货主Id

-- comment on column vi_ownersettlerulesinfo.SaleOwnerName not supported: 货主名称

-- comment on column vi_ownersettlerulesinfo.SettleRulesId not supported: 内部结算规则表Id(tb_settlerulesinfo.Id)

-- comment on column vi_ownersettlerulesinfo.SettleRulesName not supported: 内部结算规则名称

-- comment on column vi_ownersettlerulesinfo.SaleType not supported: 内部结算类型(0销售1售后)

