create definer = user_wh@`%` view vi_checkresultforexport as
select `c`.`Id`                                                                 AS `Id`,
       `a`.`Id`                                                                 AS `BatchId`,
       `a`.`BatchNo`                                                            AS `BatchNo`,
       `b`.`CheckNo`                                                            AS `CheckNo`,
       `f`.`Name`                                                               AS `OwnerName`,
       `c`.`MaterialId`                                                         AS `MaterialId`,
       `c`.`MaterialName`                                                       AS `MaterialName`,
       `c`.`MaterialNo`                                                         AS `MaterialNo`,
       `fn_GetWarehouseNameById`(if((`d`.`LevelCode` = 1), `d`.`Id`, `e`.`Id`)) AS `WarehouseName`,
       `fn_GetWarehouseNameById`(if((`d`.`LevelCode` = 2), `d`.`Id`, NULL))     AS `SecondWarehouseName`,
       `b`.`CheckPerson`                                                        AS `CheckPerson`,
       `b`.`CheckName`                                                          AS `CheckName`
from (((((`whcenter`.`tb_checkbatchinfo` `a` join `whcenter`.`tb_checkstockinfo` `b`
          on (((`b`.`BatchId` = `a`.`Id`) and (`b`.`Deleted` = 0)))) join `whcenter`.`tb_checkresult` `c`
         on (((`c`.`CheckStockId` = `b`.`Id`) and (`c`.`IsScan` = 1) and
              (`c`.`Deleted` = 0)))) left join `whcenter`.`tb_warehouse` `d`
        on (((`d`.`Id` = `b`.`WarehouseId`) and (`d`.`Deleted` = 0)))) left join `whcenter`.`tb_warehouse` `e`
       on (((`e`.`Id` = `d`.`ParentId`) and (`e`.`Deleted` = 0)))) left join `whcenter`.`tb_ownerinfo` `f`
      on (((`f`.`Id` = `c`.`OwnerId`) and (`f`.`Deleted` = 0))))
where (`a`.`Deleted` = 0);

-- comment on column vi_checkresultforexport.Id not supported: 自增主键

-- comment on column vi_checkresultforexport.BatchId not supported: 主键(BT)

-- comment on column vi_checkresultforexport.BatchNo not supported: 批次编号

-- comment on column vi_checkresultforexport.CheckNo not supported: 盘点单号

-- comment on column vi_checkresultforexport.OwnerName not supported: 货主名称

-- comment on column vi_checkresultforexport.MaterialId not supported: 物料Id

-- comment on column vi_checkresultforexport.MaterialName not supported: 物料名称

-- comment on column vi_checkresultforexport.MaterialNo not supported: 物料编码

-- comment on column vi_checkresultforexport.CheckPerson not supported: 任务发起人Code

-- comment on column vi_checkresultforexport.CheckName not supported: 任务发起人姓名

