create definer = user_wh@`%` view vi_checkstockinfo as
select `a`.`Id`                                                                 AS `Id`,
       `a`.`MainPartId`                                                         AS `MainPartId`,
       `FN_GETMAINPARTNAMEBYID`(`a`.`MainPartId`)                               AS `MainPartName`,
       `a`.`BatchId`                                                            AS `BatchId`,
       `a`.`BatchNo`                                                            AS `BatchNo`,
       `a`.`CheckNo`                                                            AS `CheckNo`,
       `a`.`OriginCheckId`                                                      AS `OriginCheckId`,
       `a`.`OriginCheckNo`                                                      AS `OriginCheckNo`,
       `a`.`CheckType`                                                          AS `CheckType`,
       (case `a`.`CheckType` when 0 then '常规盘点' when 1 then '盘损盘点' end) AS `CheckTypeName`,
       `a`.`CheckPersonId`                                                      AS `CheckPersonId`,
       `a`.`CheckPerson`                                                        AS `CheckPerson`,
       `a`.`CheckName`                                                          AS `CheckName`,
       `a`.`WarehouseId`                                                        AS `WarehouseId`,
       `FN_GETWHOLEWAREHOUSENAMEBYID`(`a`.`WarehouseId`)                        AS `WarehosueName`,
       `a`.`ParentWarehouseId`                                                  AS `ParentWarehouseId`,
       `FN_GETWAREHOUSENAMEBYID`(`a`.`ParentWarehouseId`)                       AS `ParentWarehouseName`,
       `a`.`WHType`                                                             AS `WHType`,
       (case `a`.`WHType` when 0 then '虚拟仓' when 1 then '实体仓' end)        AS `WHTypeName`,
       `a`.`WHMode`                                                             AS `WHMode`,
       (case `a`.`WHMode`
            when 0 then '普通仓'
            when 1 then '优工仓'
            when 2 then '门店仓'
            when 3 then '数据仓'
            when 4 then '租赁仓'
            when 5 then '自营仓'
            when 6 then '客户仓' end)                                           AS `ModeName`,
       `a`.`WHManeger`                                                          AS `WHManeger`,
       `a`.`WHManagerName`                                                      AS `WHManagerName`,
       `a`.`ApplyTime`                                                          AS `ApplyTime`,
       `a`.`ExpectEndTime`                                                      AS `ExpectEndTime`,
       `a`.`CheckState`                                                         AS `CheckState`,
       `a`.`StartTime`                                                          AS `StartTime`,
       `a`.`EndTime`                                                            AS `EndTime`,
       `a`.`OtherCheckPerson`                                                   AS `OtherCheckPerson`,
       `a`.`Remark`                                                             AS `Remark`,
       `a`.`CreatePerson`                                                       AS `CreatePerson`,
       `a`.`CreateName`                                                         AS `CreateName`,
       1                                                                        AS `SortOrder`
from `whcenter`.`tb_checkstockinfo` `a`
where (`a`.`Deleted` = 0);

-- comment on column vi_checkstockinfo.Id not supported: 主键(CS)

-- comment on column vi_checkstockinfo.MainPartId not supported: 业务所属Id

-- comment on column vi_checkstockinfo.BatchId not supported: 盘点批次单Id(tb_checkbatchinfo.Id)

-- comment on column vi_checkstockinfo.BatchNo not supported: 盘点批次单No

-- comment on column vi_checkstockinfo.CheckNo not supported: 盘点单号

-- comment on column vi_checkstockinfo.OriginCheckId not supported: 原盘点单Id

-- comment on column vi_checkstockinfo.OriginCheckNo not supported: 原盘点单号

-- comment on column vi_checkstockinfo.CheckType not supported: 盘点类型(0常规盘点1盘损盘点)

-- comment on column vi_checkstockinfo.CheckPersonId not supported: 任务发起人Id

-- comment on column vi_checkstockinfo.CheckPerson not supported: 任务发起人Code

-- comment on column vi_checkstockinfo.CheckName not supported: 任务发起人姓名

-- comment on column vi_checkstockinfo.WarehouseId not supported: 盘点仓库Id

-- comment on column vi_checkstockinfo.ParentWarehouseId not supported: 上级仓库Id

-- comment on column vi_checkstockinfo.WHType not supported: 仓库属性(0虚拟仓1实体仓)

-- comment on column vi_checkstockinfo.WHMode not supported: 仓库经营模式(0普通仓1优工仓2门店仓3数据仓4租赁仓)

-- comment on column vi_checkstockinfo.WHManeger not supported: 仓库负责人Code

-- comment on column vi_checkstockinfo.WHManagerName not supported: 仓库负责人姓名

-- comment on column vi_checkstockinfo.ApplyTime not supported: 任务发起时间

-- comment on column vi_checkstockinfo.ExpectEndTime not supported: 预计结束时间(盘点截至时间)

-- comment on column vi_checkstockinfo.CheckState not supported: 单据状态(0待处理1盘点中2待仓储确认盘点结果3结束(正常)4已关闭5提交等待计算结果6结束(异常))

-- comment on column vi_checkstockinfo.StartTime not supported: 盘点开始时间

-- comment on column vi_checkstockinfo.EndTime not supported: 盘点结束时间

-- comment on column vi_checkstockinfo.OtherCheckPerson not supported: 其他盘点人

-- comment on column vi_checkstockinfo.Remark not supported: 盘点备注

-- comment on column vi_checkstockinfo.CreatePerson not supported: 创建人Code

-- comment on column vi_checkstockinfo.CreateName not supported: 创建人姓名

