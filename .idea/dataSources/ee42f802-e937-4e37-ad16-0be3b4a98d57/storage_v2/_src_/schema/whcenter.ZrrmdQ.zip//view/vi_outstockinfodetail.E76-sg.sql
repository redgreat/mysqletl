create definer = user_wh@`%` view vi_outstockinfodetail as
select `a`.`Id`               AS `Id`,
       `a`.`OutStockId`       AS `OutStockId`,
       `a`.`OrderDetailId`    AS `OrderDetailId`,
       `a`.`OwnerId`          AS `OwnerId`,
       `b`.`ShortName`        AS `OwnerShortName`,
       `b`.`Name`             AS `OwnerName`,
       `a`.`GoodsId`          AS `GoodsId`,
       `a`.`GoodsName`        AS `GoodsName`,
       `a`.`MaterialId`       AS `MaterialId`,
       `a`.`MaterialName`     AS `MaterialName`,
       `a`.`MaterialType`     AS `MaterialType`,
       `a`.`MaterialTypeCode` AS `MaterialTypeCode`,
       `a`.`MaterialUnit`     AS `MaterialUnit`,
       `a`.`ReservoirCode`    AS `ReservoirCode`,
       `a`.`OutStockNum`      AS `OutStockNum`,
       `a`.`OutStockedNum`    AS `OutStockedNum`,
       `a`.`OutStockPrice`    AS `OutStockPrice`,
       `a`.`IsCodeSingle`     AS `IsCodeSingle`,
       1                      AS `SortOrder`
from (`whcenter`.`tb_outstockdetail` `a` left join `whcenter`.`tb_ownerinfo` `b`
      on (((`b`.`Id` = `a`.`OwnerId`) and (`b`.`Deleted` = 0))))
where (`a`.`Deleted` = 0);

-- comment on column vi_outstockinfodetail.Id not supported: 主键(OD)

-- comment on column vi_outstockinfodetail.OutStockId not supported: 出库单Id(tb_outstockinfo.Id)

-- comment on column vi_outstockinfodetail.OrderDetailId not supported: 订单明细Id

-- comment on column vi_outstockinfodetail.OwnerId not supported: 应出货主Id(tb_ownerinfo.Id)

-- comment on column vi_outstockinfodetail.OwnerShortName not supported: 货主简称

-- comment on column vi_outstockinfodetail.OwnerName not supported: 货主名称

-- comment on column vi_outstockinfodetail.GoodsId not supported: 订单出货商品Id

-- comment on column vi_outstockinfodetail.GoodsName not supported: 订单出货商品名称

-- comment on column vi_outstockinfodetail.MaterialId not supported: 物料Id

-- comment on column vi_outstockinfodetail.MaterialName not supported: 物料名称

-- comment on column vi_outstockinfodetail.MaterialType not supported: 物料类型

-- comment on column vi_outstockinfodetail.MaterialTypeCode not supported: 物料类型Code

-- comment on column vi_outstockinfodetail.MaterialUnit not supported: 物料单位

-- comment on column vi_outstockinfodetail.ReservoirCode not supported: 库区Id(tb_whreservoir.Code)

-- comment on column vi_outstockinfodetail.OutStockNum not supported: 应出库数量

-- comment on column vi_outstockinfodetail.OutStockedNum not supported: 已出库数量

-- comment on column vi_outstockinfodetail.OutStockPrice not supported: 出库价格

-- comment on column vi_outstockinfodetail.IsCodeSingle not supported: 是否独立编码(0否1是)

