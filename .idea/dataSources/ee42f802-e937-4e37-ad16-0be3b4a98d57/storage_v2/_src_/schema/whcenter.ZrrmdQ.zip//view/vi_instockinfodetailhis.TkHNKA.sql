create definer = user_wh@`%` view vi_instockinfodetailhis as
select `a`.`Id`               AS `Id`,
       `a`.`InStockId`        AS `InStockId`,
       `a`.`OwnerId`          AS `OwnerId`,
       `c`.`ShortName`        AS `OwnerShortName`,
       `c`.`Name`             AS `OwnerName`,
       `a`.`OrderDetailId`    AS `OrderDetailId`,
       `a`.`GoodsName`        AS `GoodsName`,
       `a`.`MaterialId`       AS `MaterialId`,
       `a`.`MaterialName`     AS `MaterialName`,
       `a`.`MaterialType`     AS `MaterialType`,
       `a`.`MaterialTypeCode` AS `MaterialTypeCode`,
       `a`.`MaterialUnit`     AS `MaterialUnit`,
       `a`.`ReservoirCode`    AS `ReservoirCode`,
       `a`.`SupplierId`       AS `SupplierId`,
       `b`.`ShortName`        AS `SupplierName`,
       `b`.`Name`             AS `SupplierFullName`,
       `a`.`InStockNum`       AS `InStockNum`,
       `a`.`InStockedNum`     AS `InStockedNum`,
       `a`.`InStockSurplus`   AS `InStockSurplus`,
       `a`.`InStockPrice`     AS `InStockPrice`,
       `a`.`IsCodeSingle`     AS `IsCodeSingle`,
       1                      AS `SortOrder`
from ((`whcenter`.`tb_instockdetailhis` `a` left join `whcenter`.`tb_ownerinfo` `c`
       on (((`c`.`Id` = `a`.`OwnerId`) and (`c`.`Deleted` = 0)))) left join `whcenter`.`tb_supplier` `b`
      on (((`b`.`Id` = `a`.`SupplierId`) and (`b`.`Deleted` = 0))))
where (`a`.`Deleted` = 0);

-- comment on column vi_instockinfodetailhis.Id not supported: 主键(ID)

-- comment on column vi_instockinfodetailhis.InStockId not supported: 入库单Id(tb_instockinfohis.Id)

-- comment on column vi_instockinfodetailhis.OwnerId not supported: 应入货主Id(tb_ownerinfo.Id)

-- comment on column vi_instockinfodetailhis.OwnerShortName not supported: 货主简称

-- comment on column vi_instockinfodetailhis.OwnerName not supported: 货主名称

-- comment on column vi_instockinfodetailhis.OrderDetailId not supported: 订单明细Id

-- comment on column vi_instockinfodetailhis.GoodsName not supported: 商品名称

-- comment on column vi_instockinfodetailhis.MaterialId not supported: 物料Id

-- comment on column vi_instockinfodetailhis.MaterialName not supported: 物料名称

-- comment on column vi_instockinfodetailhis.MaterialType not supported: 物料类型

-- comment on column vi_instockinfodetailhis.MaterialTypeCode not supported: 物料类型Code

-- comment on column vi_instockinfodetailhis.MaterialUnit not supported: 物料单位

-- comment on column vi_instockinfodetailhis.ReservoirCode not supported: 库区Code(tb_whreservoir.Code)

-- comment on column vi_instockinfodetailhis.SupplierId not supported: 采购商Id(tb_supplier.Id)

-- comment on column vi_instockinfodetailhis.SupplierName not supported: 供应商简称

-- comment on column vi_instockinfodetailhis.SupplierFullName not supported: 供应商名称

-- comment on column vi_instockinfodetailhis.InStockNum not supported: 应入库数量

-- comment on column vi_instockinfodetailhis.InStockedNum not supported: 已入库数量

-- comment on column vi_instockinfodetailhis.InStockSurplus not supported: 入库单剩余量

-- comment on column vi_instockinfodetailhis.InStockPrice not supported: 入库参考价格

-- comment on column vi_instockinfodetailhis.IsCodeSingle not supported: 是否独立编码(0否1是)

