create definer = user_wh@`%` view vi_allocateinfo as
select `a`.`Id`                                                                    AS `Id`,
       `a`.`MainPartId`                                                            AS `MainPartId`,
       `a`.`ToMainPartId`                                                          AS `ToMainPartId`,
       `fn_GetMainPartNameById`(`a`.`MainPartId`)                                  AS `MainPartName`,
       `fn_GetMainPartNameById`(`a`.`ToMainPartId`)                                AS `ToMainPartName`,
       `fn_GetOwnerShortNameById`(`a`.`ToOwnerId`)                                 AS `ToOwnerShortName`,
       `a`.`CrossMainPart`                                                         AS `CrossMainPart`,
       `a`.`BatchId`                                                               AS `BatchId`,
       `a`.`BatchNo`                                                               AS `BatchNo`,
       `a`.`AllocateNo`                                                            AS `AllocateNo`,
       `a`.`AllocateType`                                                          AS `AllocateTypeId`,
       (case `a`.`AllocateType` when 'DB0' then '调入' when 'DB1' then '调出' end) AS `AllocateTypeName`,
       `a`.`WarehouseId`                                                           AS `WarehouseId`,
       `fn_GetWarehouseNameById`(`a`.`WarehouseId`)                                AS `WarehouseName`,
       `fn_GetWholeWarehouseNameById`(`a`.`WarehouseId`)                           AS `ConcatWarehouseName`,
       `a`.`ParentWarehouseId`                                                     AS `ParentWarehouseId`,
       `a`.`ToWarehouseId`                                                         AS `ToWarehouseId`,
       `fn_GetWarehouseNameById`(`a`.`ToWarehouseId`)                              AS `ToWarehouseName`,
       `fn_GetWholeWarehouseNameById`(`a`.`ToWarehouseId`)                         AS `ToConcatWarehouseName`,
       `a`.`ToParentWarehouseId`                                                   AS `ToParentWarehouseId`,
       `a`.`AllocatePerson`                                                        AS `AllocatePerson`,
       `a`.`AllocateName`                                                          AS `AllocateName`,
       `a`.`AuditPerson`                                                           AS `AuditPerson`,
       `a`.`AuditName`                                                             AS `AuditName`,
       `a`.`IsUrgent`                                                              AS `IsUrgent`,
       `a`.`AuditTime`                                                             AS `AuditTime`,
       `a`.`AuditState`                                                            AS `AuditState`,
       `a`.`PredictTime`                                                           AS `PredictTime`,
       1                                                                           AS `SortOrder`
from `whcenter`.`tb_allocateinfo` `a`
where (`a`.`Deleted` = 0);

-- comment on column vi_allocateinfo.Id not supported: 主键(AC)

-- comment on column vi_allocateinfo.MainPartId not supported: 业务所属Id(tb_mainpartinfo.Id)

-- comment on column vi_allocateinfo.ToMainPartId not supported: 调拨到业务所属Id

-- comment on column vi_allocateinfo.CrossMainPart not supported: 是否跨货主调拨(0否1是)

-- comment on column vi_allocateinfo.BatchId not supported: 批量调拨单Id(tb_allocatebatchinfo.Id)

-- comment on column vi_allocateinfo.BatchNo not supported: 批次调拨单编码(tb_allocatebatchinfo.BatchNo)

-- comment on column vi_allocateinfo.AllocateNo not supported: 调拨单号

-- comment on column vi_allocateinfo.AllocateTypeId not supported: 调拨单类型（DB0 调拨入 DB1 调拨出）

-- comment on column vi_allocateinfo.WarehouseId not supported: 所出仓Id(tb_warehouse.Id)

-- comment on column vi_allocateinfo.ParentWarehouseId not supported: 所出上级仓库Id(tb_warehouse.Id)

-- comment on column vi_allocateinfo.ToWarehouseId not supported: 所入仓库Id(tb_warehouse.Id)

-- comment on column vi_allocateinfo.ToParentWarehouseId not supported: 到上级仓库Id(tb_warehouse.Id)

-- comment on column vi_allocateinfo.AllocatePerson not supported: 下单人Code

-- comment on column vi_allocateinfo.AllocateName not supported: 下单人姓名

-- comment on column vi_allocateinfo.AuditPerson not supported: 审核人Code

-- comment on column vi_allocateinfo.AuditName not supported: 审核人姓名

-- comment on column vi_allocateinfo.IsUrgent not supported: 是否加急(0否1是)

-- comment on column vi_allocateinfo.AuditTime not supported: 审核时间

-- comment on column vi_allocateinfo.AuditState not supported: 单据状态(0未提交1待发货2已发货3已回执4已退回)

-- comment on column vi_allocateinfo.PredictTime not supported: 预计发货时间

