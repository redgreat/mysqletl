create definer = user_wh@`%` view vi_instockdetailhis as
select `b`.`Id`                                                                                       AS `Id`,
       `a`.`MainPartId`                                                                               AS `MainPartId`,
       `a`.`FromMainPartId`                                                                           AS `FromMainPartId`,
       `fn_GetMainPartNameById`(`a`.`MainPartId`)                                                     AS `MainPartName`,
       `fn_GetMainPartNameById`(`a`.`FromMainPartId`)                                                 AS `FromMainPartName`,
       `a`.`Id`                                                                                       AS `InStockId`,
       `a`.`InStockNo`                                                                                AS `InStockNo`,
       `a`.`InStockPerson`                                                                            AS `InStockPerson`,
       `a`.`InStockName`                                                                              AS `InStockName`,
       `a`.`AuditState`                                                                               AS `AuditState`,
       `a`.`AuditPerson`                                                                              AS `AuditPerson`,
       `a`.`AuditName`                                                                                AS `AuditName`,
       `a`.`AuditTime`                                                                                AS `AuditTime`,
       `a`.`InStockType`                                                                              AS `InStockType`,
       `fn_GetStockTypeById`(`a`.`InStockType`)                                                       AS `InStockTypeName`,
       `a`.`WarehouseId`                                                                              AS `WarehouseId`,
       `a`.`WarehouseName`                                                                            AS `WarehouseName`,
       ifnull(`fn_GetWholeWarehouseNameById`(`a`.`WarehouseId`),
              `a`.`WarehouseName`)                                                                    AS `ConcatWarehouseName`,
       `a`.`ParentWarehouseId`                                                                        AS `ParentWarehouseId`,
       `fn_GetWholeWarehouseNameById`(`a`.`ParentWarehouseId`)                                        AS `ParentWarehouseName`,
       ifnull(`b`.`SupplierId`, `a`.`FromWarehouseId`)                                                AS `FromWarehouseId`,
       ifnull(`fn_GetSupplierNameById`(`b`.`SupplierId`),
              `a`.`FromWarehouseName`)                                                                AS `FromWarehouseName`,
       ifnull(ifnull(`fn_GetWholeWarehouseNameById`(`b`.`SupplierId`),
                     `fn_GetWholeWarehouseNameById`(`a`.`FromWarehouseId`)),
              `a`.`FromWarehouseName`)                                                                AS `FromConcatWarehouseName`,
       `a`.`FromParentWarehouseId`                                                                    AS `FromParentWarehouseId`,
       `fn_GetWholeWarehouseNameById`(`a`.`FromParentWarehouseId`)                                    AS `FromParentWarehouseName`,
       `b`.`OwnerId`                                                                                  AS `OwnerId`,
       `fn_GetOwnerShortNameById`(`b`.`OwnerId`)                                                      AS `OwnerShortName`,
       `b`.`MaterialId`                                                                               AS `MaterialId`,
       `b`.`MaterialName`                                                                             AS `MaterialName`,
       `b`.`MaterialType`                                                                             AS `MaterialType`,
       `b`.`MaterialUnit`                                                                             AS `MaterialUnit`,
       `b`.`InStockNum`                                                                               AS `InStockNum`,
       `b`.`InStockedNum`                                                                             AS `InStockedNum`,
       `b`.`InStockPrice`                                                                             AS `InStockPrice`,
       `b`.`InStockSurplus`                                                                           AS `InStockSurplus`,
       `b`.`IsCodeSingle`                                                                             AS `IsCodeSingle`,
       `a`.`Remark`                                                                                   AS `Remark`,
       1                                                                                              AS `SortOrder`
from (`whcenter`.`tb_instockinfohis` `a` join `whcenter`.`tb_instockdetailhis` `b`
      on (((`b`.`InStockId` = `a`.`Id`) and (`b`.`Deleted` = 0))))
where (`a`.`Deleted` = 0);

-- comment on column vi_instockdetailhis.Id not supported: 主键(ID)

-- comment on column vi_instockdetailhis.MainPartId not supported: 业务所属Id(tb_mainpartinfo.Id)

-- comment on column vi_instockdetailhis.FromMainPartId not supported: 调拨源货主Id

-- comment on column vi_instockdetailhis.InStockId not supported: 主键(IN)

-- comment on column vi_instockdetailhis.InStockNo not supported: 入库单编码

-- comment on column vi_instockdetailhis.InStockPerson not supported: 下单人Code

-- comment on column vi_instockdetailhis.InStockName not supported: 下单人姓名

-- comment on column vi_instockdetailhis.AuditState not supported: 单据状态(0待收货1收货中2已收货)

-- comment on column vi_instockdetailhis.AuditPerson not supported: 审核人Code

-- comment on column vi_instockdetailhis.AuditName not supported: 审核人姓名

-- comment on column vi_instockdetailhis.AuditTime not supported: 审核时间

-- comment on column vi_instockdetailhis.InStockType not supported: 入库单类型(IN0 采购入库 IN1 迁移入库 IN2 调拨入库 IN3 退货入库 IN4 更换入库 IN5 组装入库 IN6 拆装入库 IN7 修改入库 IN8 采购换货入库 IN9 生产入库 IN10 货主交易入库 IN11 代管入库 IN12 推广入库 IN13 货主变更入库 IN14 迁移更换入库)

-- comment on column vi_instockdetailhis.WarehouseId not supported: 所入仓库Id(tb_warehouse.Id)

-- comment on column vi_instockdetailhis.WarehouseName not supported: 所入仓库名称

-- comment on column vi_instockdetailhis.ParentWarehouseId not supported: 上级仓库Id(tb_warehouse.Id)

-- comment on column vi_instockdetailhis.FromParentWarehouseId not supported: 到上级仓库Id(tb_warehouse.Id)

-- comment on column vi_instockdetailhis.OwnerId not supported: 应入货主Id(tb_ownerinfo.Id)

-- comment on column vi_instockdetailhis.MaterialId not supported: 物料Id

-- comment on column vi_instockdetailhis.MaterialName not supported: 物料名称

-- comment on column vi_instockdetailhis.MaterialType not supported: 物料类型

-- comment on column vi_instockdetailhis.MaterialUnit not supported: 物料单位

-- comment on column vi_instockdetailhis.InStockNum not supported: 应入库数量

-- comment on column vi_instockdetailhis.InStockedNum not supported: 已入库数量

-- comment on column vi_instockdetailhis.InStockPrice not supported: 入库参考价格

-- comment on column vi_instockdetailhis.InStockSurplus not supported: 入库单剩余量

-- comment on column vi_instockdetailhis.IsCodeSingle not supported: 是否独立编码(0否1是)

-- comment on column vi_instockdetailhis.Remark not supported: 备注

