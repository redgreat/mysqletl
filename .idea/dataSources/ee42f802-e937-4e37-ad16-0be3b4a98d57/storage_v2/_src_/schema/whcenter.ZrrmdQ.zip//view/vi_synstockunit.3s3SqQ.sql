create definer = user_wh@`%` view vi_synstockunit as
select `b`.`Id`                                                                    AS `Id`,
       `b`.`SynStockId`                                                            AS `SynStockId`,
       `a`.`MainPartId`                                                            AS `MainPartId`,
       `fn_GetMainPartNameById`(`a`.`MainPartId`)                                  AS `MainPartName`,
       `a`.`OwnerId`                                                               AS `OwnerId`,
       `d`.`ShortName`                                                             AS `OwnerShortName`,
       `a`.`WarehouseId`                                                           AS `WarehouseId`,
       `fn_GetWarehouseNameById`(`a`.`WarehouseId`)                                AS `WarehouseName`,
       `a`.`SynStockType`                                                          AS `SynStockType`,
       (case `a`.`SynStockType` when 'SC0' then '组装' when 'SC1' then '拆装' end) AS `SynStockTypeName`,
       `a`.`MaterialId`                                                            AS `MaterialId`,
       `a`.`MaterialName`                                                          AS `MaterialName`,
       `a`.`MaterialType`                                                          AS `MaterialType`,
       `a`.`MaterialUnit`                                                          AS `MaterialUnit`,
       `b`.`SyntagmacId`                                                           AS `SyntagmacId`,
       `c`.`Name`                                                                  AS `SyntagmacName`,
       `b`.`SynNum`                                                                AS `SynNum`,
       1                                                                           AS `SortOrder`
from (((`whcenter`.`tb_synstockinfo` `a` join `whcenter`.`tb_synstockunit` `b`
        on (((`a`.`Id` = `b`.`SynStockId`) and (`b`.`Deleted` = 0)))) join `whcenter`.`tb_syntagmaconfig` `c`
       on (((`c`.`Id` = `b`.`SyntagmacId`) and (`c`.`Deleted` = 0)))) left join `whcenter`.`tb_ownerinfo` `d`
      on (((`d`.`Id` = `a`.`OwnerId`) and (`d`.`Deleted` = 0))))
where (`a`.`Deleted` = 0);

-- comment on column vi_synstockunit.Id not supported: 主键(SD)

-- comment on column vi_synstockunit.SynStockId not supported: 库内生产记录主单Id(tb_synstockinfo.Id)

-- comment on column vi_synstockunit.MainPartId not supported: 业务所属Id(tb_mainpartinfo.Id)

-- comment on column vi_synstockunit.OwnerId not supported: 货主Id

-- comment on column vi_synstockunit.OwnerShortName not supported: 货主简称

-- comment on column vi_synstockunit.WarehouseId not supported: 仓库Id(tb_warehouse.Id)

-- comment on column vi_synstockunit.SynStockType not supported: 生产方式(SC0 组装 SC1 拆装)

-- comment on column vi_synstockunit.MaterialId not supported: 物料部件Id

-- comment on column vi_synstockunit.MaterialName not supported: 物料部件名称

-- comment on column vi_synstockunit.MaterialType not supported: 物料类型

-- comment on column vi_synstockunit.MaterialUnit not supported: 物料单位

-- comment on column vi_synstockunit.SyntagmacId not supported: 库内生产组合关系Id(tb_syntagmaconfig.Id)

-- comment on column vi_synstockunit.SyntagmacName not supported: 组合关系名称

-- comment on column vi_synstockunit.SynNum not supported: 组装/拆装数量

