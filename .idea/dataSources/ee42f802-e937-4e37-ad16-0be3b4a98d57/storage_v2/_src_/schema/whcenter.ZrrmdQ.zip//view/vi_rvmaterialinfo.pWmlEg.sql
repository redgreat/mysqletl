create definer = user_wh@`%` view vi_rvmaterialinfo as
select `a`.`Id`                                                                                                      AS `Id`,
       `b`.`MainpartId`                                                                                              AS `MainpartId`,
       `fn_GetMainPartNameById`(`b`.`MainpartId`)                                                                    AS `MainPartName`,
       `b`.`WarehouseId`                                                                                             AS `WarehouseId`,
       `fn_GetWarehouseNameById`(`b`.`WarehouseId`)                                                                  AS `WareHouseName`,
       `b`.`Id`                                                                                                      AS `ReservoirId`,
       `b`.`Name`                                                                                                    AS `ReservoirName`,
       `b`.`Code`                                                                                                    AS `ReservoirCode`,
       `b`.`TypeId`                                                                                                  AS `ReservoirTypeId`,
       (case `b`.`TypeId`
            when 0 then '动销区'
            when 1 then '不动销区'
            when 2 then '滞销区'
            when 3
                then '售后区' end)                                                                                   AS `ReserviorTypeName`,
       `a`.`MaterialId`                                                                                              AS `MaterialId`,
       `a`.`MaterialName`                                                                                            AS `MaterialName`,
       `a`.`MaterialType`                                                                                            AS `MaterialType`,
       `a`.`MaterialTypeCode`                                                                                        AS `MaterialTypeCode`,
       `a`.`IsCodeSingle`                                                                                            AS `IsCodeSingle`,
       `a`.`SubmitPerson`                                                                                            AS `SubmitPerson`,
       `a`.`SubmitName`                                                                                              AS `SubmtName`,
       `a`.`SubmitTime`                                                                                              AS `SubmitTime`,
       `a`.`Enable`                                                                                                  AS `Enable`,
       `a`.`IsWaitTransfer`                                                                                          AS `IsWaitTransfer`,
       1                                                                                                             AS `SortOrder`
from (`whcenter`.`tb_rvmaterialtype` `a` left join `whcenter`.`tb_whreservoir` `b`
      on (((`b`.`Id` = `a`.`ReserviorId`) and (`b`.`Deleted` = 0))))
where (`a`.`Deleted` = 0);

-- comment on column vi_rvmaterialinfo.Id not supported: 主键(RT)

-- comment on column vi_rvmaterialinfo.MainpartId not supported: 业务所属Id(tb_mainpartinfo.Id)

-- comment on column vi_rvmaterialinfo.WarehouseId not supported: 仓库Id(tb_warehouse.Id)

-- comment on column vi_rvmaterialinfo.ReservoirId not supported: 主键(WR)

-- comment on column vi_rvmaterialinfo.ReservoirName not supported: 库区名称

-- comment on column vi_rvmaterialinfo.ReservoirCode not supported: 库区Code

-- comment on column vi_rvmaterialinfo.ReservoirTypeId not supported: 类型Id(0动销区1不动销区2滞销区3售后区)

-- comment on column vi_rvmaterialinfo.MaterialId not supported: 物料Id

-- comment on column vi_rvmaterialinfo.MaterialName not supported: 物料名称

-- comment on column vi_rvmaterialinfo.MaterialType not supported: 物料类型名称

-- comment on column vi_rvmaterialinfo.MaterialTypeCode not supported: 物料Code

-- comment on column vi_rvmaterialinfo.IsCodeSingle not supported: 是否独立编码(0否1是)

-- comment on column vi_rvmaterialinfo.SubmitPerson not supported: 提交人Code

-- comment on column vi_rvmaterialinfo.SubmtName not supported: 提交人姓名

-- comment on column vi_rvmaterialinfo.SubmitTime not supported: 提交时间

-- comment on column vi_rvmaterialinfo.Enable not supported: 是否启用(0关闭1开启)

-- comment on column vi_rvmaterialinfo.IsWaitTransfer not supported: 是否等待迁移(0否1是)

