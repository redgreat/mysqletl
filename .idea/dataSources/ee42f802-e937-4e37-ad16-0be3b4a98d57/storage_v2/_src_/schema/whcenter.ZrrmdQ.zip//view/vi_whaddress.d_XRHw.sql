create definer = user_wh@`%` view vi_whaddress as
select `a`.`Id`                                   AS `Id`,
       `a`.`WarehouseId`                          AS `WarehouseId`,
       `a`.`AddressType`                          AS `AddressType`,
       `a`.`ProCode`                              AS `ProCode`,
       `fn_GetDistrictNameByCode`(`a`.`ProCode`)  AS `ProName`,
       `a`.`CityCode`                             AS `CityCode`,
       `fn_GetDistrictNameByCode`(`a`.`CityCode`) AS `CityName`,
       `a`.`DeliveAddress`                        AS `DeliveAddress`,
       `a`.`LinkMan`                              AS `LinkMan`,
       `a`.`LinkTel`                              AS `LinkTel`,
       `a`.`IsDefault`                            AS `IsDefault`,
       `a`.`Remark`                               AS `Remark`,
       1                                          AS `SortOrder`
from `whcenter`.`tb_whaddress` `a`
where (`a`.`Deleted` = 0);

-- comment on column vi_whaddress.Id not supported: 主键(WD)

-- comment on column vi_whaddress.WarehouseId not supported: 仓库Id/供应商Id(tb_warehouse.Id/tb_supplier)

-- comment on column vi_whaddress.AddressType not supported: 地址类型(0仓库收货地址1供应商收货地址)

-- comment on column vi_whaddress.ProCode not supported: 省份Code

-- comment on column vi_whaddress.CityCode not supported: 城市Code

-- comment on column vi_whaddress.DeliveAddress not supported: 详细地址

-- comment on column vi_whaddress.LinkMan not supported: 联系人姓名

-- comment on column vi_whaddress.LinkTel not supported: 联系电话

-- comment on column vi_whaddress.IsDefault not supported: 是否默认(0否1是)

-- comment on column vi_whaddress.Remark not supported: 备注

