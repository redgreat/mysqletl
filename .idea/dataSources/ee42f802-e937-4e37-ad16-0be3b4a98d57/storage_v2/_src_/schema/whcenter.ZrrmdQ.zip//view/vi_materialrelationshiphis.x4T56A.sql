create definer = user_wh@`%` view vi_materialrelationshiphis as
select `a`.`Id`                     AS `Id`,
       `a`.`DeviceNumber`           AS `DeviceNumber`,
       `a`.`DeviceMaterialId`       AS `DeviceMaterialId`,
       `a`.`DeviceMaterialName`     AS `DeviceMaterialName`,
       `a`.`DeviceMaterialType`     AS `DeviceMaterialType`,
       `a`.`DeviceMaterialTypeCode` AS `DeviceMaterialTypeCode`,
       `b`.`StockLocationId`        AS `DeviceLocationId`,
       `b`.`StockLocationName`      AS `DeviceLocationName`,
       `a`.`SimNumber`              AS `SimNumber`,
       `a`.`SimMaterialId`          AS `SimMaterialId`,
       `a`.`SimMaterialName`        AS `SimMaterialName`,
       `c`.`StockLocationId`        AS `SimLocationId`,
       `c`.`StockLocationName`      AS `SimLocationName`,
       `a`.`FirstSimNumber`         AS `FirstSimNumber`,
       `a`.`RelationState`          AS `RelationState`,
       `a`.`SubmitCode`             AS `SubmitCode`,
       `a`.`SubmitName`             AS `SubmitName`,
       `a`.`SubmitTime`             AS `SubmitTime`,
       `a`.`OperateCode`            AS `OperateCode`,
       `a`.`OperateName`            AS `OperateName`,
       `a`.`OperateTime`            AS `OperateTime`,
       `a`.`InsertTime`             AS `InsertTime`,
       `a`.`DeletedAt`              AS `DeletedAt`,
       `a`.`Deleted`                AS `Deleted`
from ((`whcenter`.`tb_materialrelationshiphis` `a` left join `whcenter`.`tb_materialstock` `b`
       on (((`b`.`MaterialNo` = `a`.`DeviceNumber`) and (`b`.`Deleted` = 0)))) left join `whcenter`.`tb_materialstock` `c`
      on (((`c`.`MaterialNo` = `a`.`SimNumber`) and (`c`.`Deleted` = 0))))
where (`a`.`Deleted` = 0);

-- comment on column vi_materialrelationshiphis.Id not supported: 自增主键

-- comment on column vi_materialrelationshiphis.DeviceNumber not supported: 设备号

-- comment on column vi_materialrelationshiphis.DeviceMaterialId not supported: 设备物料Id

-- comment on column vi_materialrelationshiphis.DeviceMaterialName not supported: 设备物料名称

-- comment on column vi_materialrelationshiphis.DeviceMaterialType not supported: 设备物料类型

-- comment on column vi_materialrelationshiphis.DeviceMaterialTypeCode not supported: 设备物料类型编码

-- comment on column vi_materialrelationshiphis.DeviceLocationId not supported: 所在位置Id(仓库Id/门店Id)

-- comment on column vi_materialrelationshiphis.DeviceLocationName not supported: 所在位置名称(仓库名称/门店名称)

-- comment on column vi_materialrelationshiphis.SimNumber not supported: 流量卡号

-- comment on column vi_materialrelationshiphis.SimMaterialId not supported: 流量卡物料Id

-- comment on column vi_materialrelationshiphis.SimMaterialName not supported: 流量卡物料名称

-- comment on column vi_materialrelationshiphis.SimLocationId not supported: 所在位置Id(仓库Id/门店Id)

-- comment on column vi_materialrelationshiphis.SimLocationName not supported: 所在位置名称(仓库名称/门店名称)

-- comment on column vi_materialrelationshiphis.FirstSimNumber not supported: 首次对应流量卡编码

-- comment on column vi_materialrelationshiphis.RelationState not supported: 状态(1开启2关闭)

-- comment on column vi_materialrelationshiphis.SubmitCode not supported: 提交人Code

-- comment on column vi_materialrelationshiphis.SubmitName not supported: 提交人姓名

-- comment on column vi_materialrelationshiphis.SubmitTime not supported: 提交时间

-- comment on column vi_materialrelationshiphis.OperateCode not supported: 最后一次操作人Code

-- comment on column vi_materialrelationshiphis.OperateName not supported: 最后一次操作人姓名

-- comment on column vi_materialrelationshiphis.OperateTime not supported: 最后一次操作时间

-- comment on column vi_materialrelationshiphis.InsertTime not supported: 数据写入时间

-- comment on column vi_materialrelationshiphis.DeletedAt not supported: 删除时间

