create definer = user_wh@`%` view vi_whmodifylog as
select `a`.`Id`                                 AS `Id`,
       `a`.`WarehouseId`                        AS `WarehouseId`,
       `a`.`WarehouseName`                      AS `WarehouseName`,
       `a`.`ParentWarehouseId`                  AS `ParentWarehouseId`,
       `a`.`ParentWarehouseName`                AS `ParentWarehouseName`,
       `a`.`WHDepartId`                         AS `WHDepartId`,
       `a`.`WHDepartName`                       AS `WHDepartName`,
       `a`.`WHMode`                             AS `WHMode`,
       `fn_GetWarehousModeByCode`(`a`.`WHMode`) AS `WHModeName`,
       `a`.`ModifyType`                         AS `ModifyType`,
       (case `a`.`ModifyType`
            when 1 then '自动建仓'
            when 2 then '新增仓库'
            when 3 then '开启仓库'
            when 4 then '关闭仓库'
            when 5 then '删除仓库' end)         AS `ModifyTypeName`,
       `a`.`ModifyTime`                         AS `ModifyTime`,
       `a`.`ModifyState`                        AS `ModifyState`,
       `a`.`ModifyPerson`                       AS `ModifyPerson`,
       `a`.`ModifyName`                         AS `ModifyName`,
       `a`.`FailReason`                         AS `FailReason`,
       (case `a`.`FailReason`
            when 1 then '不存在区域分仓对应关系'
            when 2 then '货主下二级仓名称重复'
            when 3 then '售后负责人已存在'
            when 4 then '盘库负责人已存在' end) AS `FailReasonName`,
       `a`.`ProcessStatus`                      AS `ProcessStatus`,
       `a`.`EntryType`                          AS `EntryType`,
       (case `a`.`EntryType`
            when 0 then '首次入职'
            when 1 then '同岗二次入职'
            when 3 then '转岗二次入职'
            when 3 then '自有转优工'
            when 4 then '优工转自有'
            when 5 then '岗位/部门异动' end)    AS `EntryTypeName`,
       `a`.`Remark`                             AS `Remark`
from `whcenter`.`tb_whmodifylog` `a`;

-- comment on column vi_whmodifylog.Id not supported: 自增主键

-- comment on column vi_whmodifylog.WarehouseId not supported: 仓库Id(tb_warehouse.Id)

-- comment on column vi_whmodifylog.WarehouseName not supported: 仓库名称

-- comment on column vi_whmodifylog.ParentWarehouseId not supported: 上级仓库Id(tb_warehouse.Id)

-- comment on column vi_whmodifylog.ParentWarehouseName not supported: 上级仓库名称

-- comment on column vi_whmodifylog.WHDepartId not supported: 仓库对应部门区域Id

-- comment on column vi_whmodifylog.WHDepartName not supported: 仓库对应部门区域名称

-- comment on column vi_whmodifylog.WHMode not supported: 一级仓经营模式(0普通仓1优工仓2门店仓3数据仓4租赁仓5自营仓6客户仓)

-- comment on column vi_whmodifylog.ModifyType not supported: 变更类型(1自动建仓2新增仓库3开启仓库4关闭仓库5删除仓库)

-- comment on column vi_whmodifylog.ModifyTime not supported: 变更时间

-- comment on column vi_whmodifylog.ModifyState not supported: 变更状态(0失败1成功)

-- comment on column vi_whmodifylog.ModifyPerson not supported: 操作人Code

-- comment on column vi_whmodifylog.ModifyName not supported: 操作人姓名

-- comment on column vi_whmodifylog.FailReason not supported: 失败原因(1不存在区域分仓对应关系2货主下二级仓名称重复3售后负责人已存在4盘库负责人已存在)

-- comment on column vi_whmodifylog.ProcessStatus not supported: 处理情况(0待处理1已处理)

-- comment on column vi_whmodifylog.EntryType not supported: EHR入职类型(0首次入职1同岗二次入职2转岗二次入职3自有转优工4优工转自有5岗位/部门异动)

-- comment on column vi_whmodifylog.Remark not supported: 备注

