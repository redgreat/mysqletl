create definer = user_wh@`%` view vi_supplier as
select `a`.`Id`                                   AS `Id`,
       `a`.`MainPartId`                           AS `MainPartId`,
       `fn_GetMainPartNameById`(`a`.`MainPartId`) AS `MainPartName`,
       `a`.`OwnerId`                              AS `OwnerId`,
       `fn_GetOwnerShortNameById`(`a`.`OwnerId`)  AS `OwnerShortName`,
       `fn_GetOwnerNameById`(`a`.`OwnerId`)       AS `OwnerName`,
       `a`.`Name`                                 AS `Name`,
       `a`.`ShortName`                            AS `ShortName`,
       `a`.`SupplierType`                         AS `SupplierType`,
       `fn_GetDictionaryNameById`(`a`.`GradeId`)  AS `GradeName`,
       `a`.`CustSettleId`                         AS `CustSettleId`,
       `a`.`CustSettleName`                       AS `CustSettleName`,
       `fn_GetDistrictNameByCode`(`a`.`ProCode`)  AS `ProName`,
       `fn_GetDistrictNameByCode`(`a`.`CityCode`) AS `CityName`,
       `a`.`IsCharge`                             AS `IsCharge`,
       `a`.`Address`                              AS `Address`,
       `a`.`LinkMan`                              AS `LinkMan`,
       `a`.`LinkTel`                              AS `LinkTel`,
       `a`.`CreatedAt`                            AS `CreatedAt`,
       1                                          AS `SortOrder`
from (`whcenter`.`tb_supplier` `a` left join `whcenter`.`tb_whaddress` `b`
      on (((`a`.`Id` = `b`.`WarehouseId`) and (`b`.`Deleted` = 0) and (`b`.`IsDefault` = 1))))
where (`a`.`Deleted` = 0);

-- comment on column vi_supplier.Id not supported: 主键(SP)

-- comment on column vi_supplier.MainPartId not supported: 业务所属Id

-- comment on column vi_supplier.OwnerId not supported: 货主Id

-- comment on column vi_supplier.Name not supported: 供应商名称

-- comment on column vi_supplier.ShortName not supported: 供应商简称

-- comment on column vi_supplier.SupplierType not supported: 供应商类型(0批发商1生产商2代管商)

-- comment on column vi_supplier.CustSettleId not supported: 结算单位Id

-- comment on column vi_supplier.CustSettleName not supported: 结算单位名称

-- comment on column vi_supplier.IsCharge not supported: 是否收费(0否1是)

-- comment on column vi_supplier.Address not supported: 供应商地址

-- comment on column vi_supplier.LinkMan not supported: 供应商联系人

-- comment on column vi_supplier.LinkTel not supported: 供应商联系电话

