create definer = user_wh@`%` view vi_stockageconfig as
select `a`.`Id`                                                                 AS `Id`,
       `a`.`MainPartId`                                                         AS `MainPartId`,
       `fn_GetMainPartNameById`(`a`.`MainPartId`)                               AS `MainPartName`,
       `a`.`WarehouseId`                                                        AS `WarehouseId`,
       `fn_GetWarehouseNameById`(`a`.`WarehouseId`)                             AS `WarehouseName`,
       `a`.`WHType`                                                             AS `WHType`,
       `a`.`MaterialId`                                                         AS `MaterialId`,
       `a`.`MaterialName`                                                       AS `MaterialName`,
       `a`.`MaterialType`                                                       AS `MaterialType`,
       `a`.`MaterialTypeCode`                                                   AS `MaterialTypeCode`,
       `a`.`Priority`                                                           AS `Priority`,
       `a`.`WarnFreq`                                                           AS `WarnFreq`,
       `a`.`WarnPersonType`                                                     AS `WarnPersonType`,
       `a`.`StartTimeType`                                                      AS `StartTimeType`,
       (case `a`.`StartTimeType`
            when 1 then '最近一次变更所在一级仓日期'
            when 2 then '最近一次采购、采购换货或迁移入库的日期'
            when 3 then '最近一次从实体仓调拨出库、退货入库、更换入库的日期' end) AS `StartTimeTypeName`,
       max(if((`b`.`WarnType` = 1), `b`.`WarnValue`, NULL))                     AS `FirstWarnValue`,
       max(if((`b`.`WarnType` = 2), `b`.`WarnValue`, NULL))                     AS `SecondWarnValue`,
       `a`.`CreatedById`                                                        AS `CreatedById`,
       `a`.`CreatedAt`                                                          AS `CreatedAt`,
       `a`.`UpdatedById`                                                        AS `UpdatedById`,
       `a`.`UpdatedAt`                                                          AS `UpdatedAt`,
       `a`.`DeletedById`                                                        AS `DeletedById`,
       `a`.`DeletedAt`                                                          AS `DeletedAt`,
       `a`.`Deleted`                                                            AS `Deleted`
from (`whcenter`.`tb_stockageconfig` `a` join `whcenter`.`tb_stockageconfigdetail` `b`
      on ((`b`.`StockAgeConfigId` = `a`.`Id`)))
where ((`a`.`Deleted` = 0) and (`b`.`Deleted` = 0))
group by `a`.`Id`;

-- comment on column vi_stockageconfig.Id not supported: 主键(SA)

-- comment on column vi_stockageconfig.MainPartId not supported: 业务所属Id

-- comment on column vi_stockageconfig.WarehouseId not supported: 一级仓Id

-- comment on column vi_stockageconfig.WHType not supported: 仓库属性(0虚拟仓1实体仓)

-- comment on column vi_stockageconfig.MaterialId not supported: 物料Id

-- comment on column vi_stockageconfig.MaterialName not supported: 物料名称

-- comment on column vi_stockageconfig.MaterialType not supported: 物料类型

-- comment on column vi_stockageconfig.MaterialTypeCode not supported: 物料类型Code

-- comment on column vi_stockageconfig.Priority not supported: 优先级(1低2高)

-- comment on column vi_stockageconfig.WarnFreq not supported: 提醒频率(1从不2每天3每月1号15号)

-- comment on column vi_stockageconfig.WarnPersonType not supported: 提醒人类型(1仓库全部负责人2仓库所有负责人+所属上级仓默认负责人3仓库所有负责人+所属上级仓全部负责人)

-- comment on column vi_stockageconfig.StartTimeType not supported: 起始日期类型(1最近一次变更所在一级仓的日期2首次采购或迁移入库的日期3最近一次从实体仓调拨出库/退货入库/变更入库的日期)

