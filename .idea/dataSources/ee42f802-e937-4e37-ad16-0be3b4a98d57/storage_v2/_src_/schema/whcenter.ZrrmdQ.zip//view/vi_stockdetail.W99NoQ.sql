create definer = user_wh@`%` view vi_stockdetail as
select `a`.`Id`                                   AS `Id`,
       `a`.`OwnerId`                              AS `OwnerId`,
       `fn_GetOwnerNameById`(`a`.`OwnerId`)       AS `OwnerName`,
       `fn_GetOwnerShortNameById`(`a`.`OwnerId`)  AS `OwnerShortName`,
       `a`.`MaterialNo`                           AS `MaterialNo`,
       `a`.`MaterialId`                           AS `MaterialId`,
       `a`.`MaterialType`                         AS `MaterialType`,
       `a`.`MaterialTypeCode`                     AS `MaterialTypeCode`,
       `a`.`ReservoirCode`                        AS `ReservoirCode`,
       `a`.`StockLocationId`                      AS `StockLocationId`,
       `a`.`StockLocationName`                    AS `StockLocationName`,
       `a`.`LastStockId`                          AS `InStockId`,
       `a`.`LastStockNo`                          AS `InStockNo`,
       `a`.`LastStockType`                        AS `InStockType`,
       `fn_GetStockTypeById`(`a`.`LastStockType`) AS `InStockTypeName`,
       `a`.`IsTransporting`                       AS `IsTransporting`,
       `a`.`StockStatus`                          AS `StockStatus`,
       `fn_GetStockAgeByNo`(`a`.`MaterialNo`)     AS `StockAge`,
       `a`.`StockAgeStatus`                       AS `StockAgeStatus`,
       1                                          AS `SortOrder`
from `whcenter`.`tb_materialstock` `a`
where (`a`.`Deleted` = 0);

-- comment on column vi_stockdetail.Id not supported: 自增主键

-- comment on column vi_stockdetail.OwnerId not supported: 货主Id(tb_ownerinfo.Id)

-- comment on column vi_stockdetail.MaterialNo not supported: 物料编码

-- comment on column vi_stockdetail.MaterialId not supported: 物料类型Id

-- comment on column vi_stockdetail.MaterialType not supported: 物料类型

-- comment on column vi_stockdetail.MaterialTypeCode not supported: 物料类型Code

-- comment on column vi_stockdetail.ReservoirCode not supported: 库区Code(tb_whreservoir.Code)

-- comment on column vi_stockdetail.StockLocationId not supported: 所在位置Id(仓库Id/门店Id)

-- comment on column vi_stockdetail.StockLocationName not supported: 所在位置名称(仓库名称/门店名称)

-- comment on column vi_stockdetail.InStockId not supported: 最后一次出入库单Id

-- comment on column vi_stockdetail.InStockNo not supported: 最后一次出入库编码

-- comment on column vi_stockdetail.InStockType not supported: 最后一次出入库类型

-- comment on column vi_stockdetail.IsTransporting not supported: 是否在途(0已签收1在途)

-- comment on column vi_stockdetail.StockStatus not supported: 设备在库状态(0未加装1已加装2已拆装)

-- comment on column vi_stockdetail.StockAgeStatus not supported: 库龄预警状态(0未预警1一级预警2二级预警)

