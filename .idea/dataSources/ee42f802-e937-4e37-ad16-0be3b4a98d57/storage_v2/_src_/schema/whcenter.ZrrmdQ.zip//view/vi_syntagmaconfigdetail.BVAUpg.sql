create definer = user_wh@`%` view vi_syntagmaconfigdetail as
select `b`.`Id`               AS `Id`,
       `b`.`SynConfigId`      AS `SynConfigId`,
       `a`.`Name`             AS `SynName`,
       `a`.`MaterialId`       AS `SynMaterialId`,
       `a`.`MaterialName`     AS `SynMaterialName`,
       `a`.`MaterialUnit`     AS `SynMaterialUnit`,
       `b`.`MaterialId`       AS `MaterialId`,
       `b`.`MaterialName`     AS `MaterialName`,
       `b`.`MaterialType`     AS `MaterialType`,
       `b`.`MaterialTypeCode` AS `MaterialTypeCode`,
       `b`.`MaterialUnit`     AS `MaterialUnit`,
       `b`.`SynNum`           AS `SynNum`,
       `a`.`Enable`           AS `Enable`,
       1                      AS `SortOrder`
from (`whcenter`.`tb_syntagmaconfig` `a` join `whcenter`.`tb_syntagmaconfigdetail` `b`)
where ((`b`.`SynConfigId` = `a`.`Id`) and (`a`.`Deleted` = 0) and (`b`.`Deleted` = 0));

-- comment on column vi_syntagmaconfigdetail.Id not supported: 自增主键

-- comment on column vi_syntagmaconfigdetail.SynConfigId not supported: 生产规则Id(tb_syntagmaconfig.Id)

-- comment on column vi_syntagmaconfigdetail.SynName not supported: 组合关系名称

-- comment on column vi_syntagmaconfigdetail.SynMaterialId not supported: 物料部件Id

-- comment on column vi_syntagmaconfigdetail.SynMaterialName not supported: 物料部件名称

-- comment on column vi_syntagmaconfigdetail.SynMaterialUnit not supported: 物料单位

-- comment on column vi_syntagmaconfigdetail.MaterialId not supported: 物料零件Id

-- comment on column vi_syntagmaconfigdetail.MaterialName not supported: 物料零件名称

-- comment on column vi_syntagmaconfigdetail.MaterialType not supported: 物料零件类型

-- comment on column vi_syntagmaconfigdetail.MaterialTypeCode not supported: 物料零件Code

-- comment on column vi_syntagmaconfigdetail.MaterialUnit not supported: 物料单位

-- comment on column vi_syntagmaconfigdetail.SynNum not supported: 零件个数

-- comment on column vi_syntagmaconfigdetail.Enable not supported: 开启状态(0关闭1开启)

