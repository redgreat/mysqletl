create definer = user_wh@`%` view vi_warehouseforexport as
select `a`.`Id`                                                        AS `Id`,
       `a`.`CustId`                                                    AS `CustId`,
       `a`.`CustName`                                                  AS `CustName`,
       `a`.`CustStoreId`                                               AS `CustStoreId`,
       `a`.`CustStoreCode`                                             AS `CustStoreCode`,
       `a`.`CustStoreName`                                             AS `CustStoreName`,
       `a`.`MainPartId`                                                AS `MainPartId`,
       `fn_GetMainPartNameById`(`a`.`MainPartId`)                      AS `MainPartName`,
       `a`.`Name`                                                      AS `WarehouseName`,
       `a`.`Type`                                                      AS `Type`,
       (case `a`.`Type` when 0 then '虚拟仓' when 1 then '实体仓' end) AS `TypeName`,
       `a`.`ParentId`                                                  AS `ParentId`,
       `fn_GetWarehouseNameById`(`a`.`ParentId`)                       AS `ParentWarehouseName`,
       `a`.`Mode`                                                      AS `Mode`,
       `fn_GetWarehousModeByCode`(`a`.`Mode`)                          AS `ModeName`,
       `a`.`LevelCode`                                                 AS `LevelCode`,
       `a`.`Enable`                                                    AS `Enable`,
       `a`.`IsWaitTransfer`                                            AS `IsWaitTransfer`,
       `a`.`IsReceipt`                                                 AS `IsReceipt`,
       `a`.`IsAllowTrans`                                              AS `IsAllowTrans`,
       `fn_GetDefaultManagerByWarehouseId`(`a`.`Id`)                   AS `DefaultManager`,
       `fn_GetDefaultManagerCodeByWarehouseId`(`a`.`Id`)               AS `DefaultManagerCode`,
       `fn_GetCheckManagerByWarehouseId`(`a`.`Id`)                     AS `CheckManager`,
       `fn_GetCheckManagerCodeByWarehouseId`(`a`.`Id`)                 AS `CheckManagerCode`,
       `b`.`ProCode`                                                   AS `ProCode`,
       `fn_GetDistrictNameByCode`(`b`.`ProCode`)                       AS `ProName`,
       `b`.`CityCode`                                                  AS `CityCode`,
       `fn_GetDistrictNameByCode`(`b`.`CityCode`)                      AS `CityName`,
       `b`.`DeliveAddress`                                             AS `DeliveAddress`,
       `a`.`Remark`                                                    AS `Remark`,
       `a`.`CreatedAt`                                                 AS `CreatedAt`,
       `fn_GetDisableTimeByWarehouseId`(`a`.`Id`)                      AS `CloseTime`,
       `fn_GetIsStockNullByWarehouseId`(`a`.`Id`)                      AS `IsStockNull`,
       1                                                               AS `SortOrder`
from (`whcenter`.`tb_warehouse` `a` left join `whcenter`.`tb_whaddress` `b`
      on (((`b`.`WarehouseId` = `a`.`Id`) and (`b`.`AddressType` = 0) and (`b`.`Deleted` = 0) and
           (`b`.`IsDefault` = 1))))
where (`a`.`Deleted` = 0);

-- comment on column vi_warehouseforexport.Id not supported: 主键Id(WH)

-- comment on column vi_warehouseforexport.CustId not supported: 客户Id

-- comment on column vi_warehouseforexport.CustName not supported: 客户名称

-- comment on column vi_warehouseforexport.CustStoreId not supported: 门店Id

-- comment on column vi_warehouseforexport.CustStoreCode not supported: 门店Code

-- comment on column vi_warehouseforexport.CustStoreName not supported: 门店名称

-- comment on column vi_warehouseforexport.MainPartId not supported: 业务所属Id(tb_mainpartinfo.Id)

-- comment on column vi_warehouseforexport.WarehouseName not supported: 仓库名称

-- comment on column vi_warehouseforexport.Type not supported: 仓库属性(0虚拟仓1实体仓)

-- comment on column vi_warehouseforexport.ParentId not supported: 上级仓Id(tb_warehouse.Id)

-- comment on column vi_warehouseforexport.Mode not supported: 经营模式(0普通仓1优工仓2门店仓3数据仓4租赁仓5自营仓6客户仓)

-- comment on column vi_warehouseforexport.LevelCode not supported: 仓库等级(1一级仓2二级仓)

-- comment on column vi_warehouseforexport.Enable not supported: 开启状态(0关闭1开启)

-- comment on column vi_warehouseforexport.IsWaitTransfer not supported: 是否等待迁移(0否1是)

-- comment on column vi_warehouseforexport.IsReceipt not supported: 是否电子回执(0否1是)

-- comment on column vi_warehouseforexport.IsAllowTrans not supported: 是否允许调入(0否1是)

-- comment on column vi_warehouseforexport.ProCode not supported: 省份Code

-- comment on column vi_warehouseforexport.CityCode not supported: 城市Code

-- comment on column vi_warehouseforexport.DeliveAddress not supported: 详细地址

-- comment on column vi_warehouseforexport.Remark not supported: 备注

-- comment on column vi_warehouseforexport.CreatedAt not supported: 信息录入时间

