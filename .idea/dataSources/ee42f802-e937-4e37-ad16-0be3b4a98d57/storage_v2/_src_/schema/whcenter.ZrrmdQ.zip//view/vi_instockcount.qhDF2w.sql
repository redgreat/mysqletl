create definer = user_wh@`%` view vi_instockcount as
select `b`.`Id`                    AS `Id`,
       `a`.`MainPartId`            AS `MainPartId`,
       `a`.`FromMainPartId`        AS `FromMainPartId`,
       `a`.`InStockNo`             AS `InStockNo`,
       `a`.`OrderNo`               AS `OrderNo`,
       `a`.`InStockType`           AS `InStockType`,
       `a`.`WarehouseId`           AS `WarehouseId`,
       `a`.`WarehouseName`         AS `WarehouseName`,
       `a`.`ParentWarehouseId`     AS `ParentWarehouseId`,
       `a`.`FromWarehouseId`       AS `FromWarehouseId`,
       `a`.`FromWarehouseName`     AS `FromWarehouseName`,
       `a`.`FromParentWarehouseId` AS `FromParentWarehouseId`,
       `a`.`InStockPerson`         AS `InStockPerson`,
       `a`.`InStockName`           AS `InStockName`,
       `a`.`AuditState`            AS `AuditState`,
       `a`.`AuditPerson`           AS `AuditPerson`,
       `a`.`AuditName`             AS `AuditName`,
       `a`.`AuditTime`             AS `AuditTime`,
       `a`.`OutRelated`            AS `OutRelated`,
       `b`.`MaterialId`            AS `MaterialId`,
       `b`.`MaterialName`          AS `MaterialName`,
       `b`.`MaterialType`          AS `MaterialType`,
       `b`.`MaterialTypeCode`      AS `MaterialTypeCode`,
       `b`.`InStockNum`            AS `InStockNum`,
       `b`.`InStockedNum`          AS `InStockedNum`,
       `b`.`IsCodeSingle`          AS `IsCodeSingle`
from (`whcenter`.`tb_instockinfo` `a` join `whcenter`.`tb_instockdetail` `b`)
where ((`b`.`InStockId` = `a`.`Id`) and (`a`.`Deleted` = 0) and (`b`.`Deleted` = 0));

-- comment on column vi_instockcount.Id not supported: 主键(ID)

-- comment on column vi_instockcount.MainPartId not supported: 业务所属Id(tb_mainpartinfo.Id)

-- comment on column vi_instockcount.FromMainPartId not supported: 调拨源业务所属Id

-- comment on column vi_instockcount.InStockNo not supported: 入库单编码

-- comment on column vi_instockcount.OrderNo not supported: 订单编码/调拨单编码

-- comment on column vi_instockcount.InStockType not supported: 入库单类型(IN0 采购入库 IN1 迁移入库 IN2 调拨入库 IN3 退货入库 IN4 更换入库 IN5 组装入库 IN6 拆装入库 IN7 修改入库 IN8 采购换货入库 IN9 生产入库 IN10 货主交易入库 IN11 代管入库 IN12 推广入库 IN13 货主变更入库 IN14 迁移更换入库)

-- comment on column vi_instockcount.WarehouseId not supported: 所入仓库Id(tb_warehouse.Id)

-- comment on column vi_instockcount.WarehouseName not supported: 所入仓库名称

-- comment on column vi_instockcount.ParentWarehouseId not supported: 上级仓库Id(tb_warehouse.Id)

-- comment on column vi_instockcount.FromWarehouseId not supported: 所出仓库Id(tb_warehouse.Id)

-- comment on column vi_instockcount.FromWarehouseName not supported: 所出仓库名称

-- comment on column vi_instockcount.FromParentWarehouseId not supported: 到上级仓库Id(tb_warehouse.Id)

-- comment on column vi_instockcount.InStockPerson not supported: 下单人Code

-- comment on column vi_instockcount.InStockName not supported: 下单人姓名

-- comment on column vi_instockcount.AuditState not supported: 单据状态(0待收货1收货中2已收货)

-- comment on column vi_instockcount.AuditPerson not supported: 审核人Code

-- comment on column vi_instockcount.AuditName not supported: 审核人姓名

-- comment on column vi_instockcount.AuditTime not supported: 审核时间

-- comment on column vi_instockcount.OutRelated not supported: 对应换货单关系Id

-- comment on column vi_instockcount.MaterialId not supported: 物料Id

-- comment on column vi_instockcount.MaterialName not supported: 物料名称

-- comment on column vi_instockcount.MaterialType not supported: 物料类型

-- comment on column vi_instockcount.MaterialTypeCode not supported: 物料类型Code

-- comment on column vi_instockcount.InStockNum not supported: 应入库数量

-- comment on column vi_instockcount.InStockedNum not supported: 已入库数量

-- comment on column vi_instockcount.IsCodeSingle not supported: 是否独立编码(0否1是)

