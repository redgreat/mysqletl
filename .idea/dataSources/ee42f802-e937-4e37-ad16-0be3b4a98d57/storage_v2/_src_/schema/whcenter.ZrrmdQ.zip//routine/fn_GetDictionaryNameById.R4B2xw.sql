create
    definer = user_wh@`%` function fn_GetDictionaryNameById(InId char(12)) returns varchar(50) sql security invoker
BEGIN
   
   DECLARE Result VARCHAR(50);
   
   SELECT NAME
     INTO Result
     FROM basic_datadictionary
    WHERE Id=InId;
   
   RETURN IFNULL(Result,'');
	
END;

