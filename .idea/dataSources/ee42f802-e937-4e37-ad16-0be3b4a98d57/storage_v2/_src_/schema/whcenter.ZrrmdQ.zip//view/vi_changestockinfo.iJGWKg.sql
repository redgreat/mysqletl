create definer = user_wh@`%` view vi_changestockinfo as
select `a`.`Id`                                                                               AS `Id`,
       `a`.`MainPartId`                                                                       AS `MainPartId`,
       `fn_GetMainPartNameById`(`a`.`MainPartId`)                                             AS `MainPartName`,
       `a`.`WarehouseId`                                                                      AS `WarehouseId`,
       ifnull(`fn_GetWarehouseNameById`(`a`.`WarehouseId`), `a`.`WarehouseName`)              AS `WarehouseName`,
       ifnull(`fn_GetWholeWarehouseNameById`(`a`.`WarehouseId`), `a`.`WarehouseName`)         AS `ConcatWarehouseName`,
       `a`.`ParentWarehouseId`                                                                AS `ParentWarehouseId`,
       `a`.`ChangeStockType`                                                                  AS `ChangeStockType`,
       (case `a`.`ChangeStockType` when 'CH0' then '型号变更' when 'CH1' then '状态变更' end) AS `ChangeStockTypeName`,
       `a`.`MaterialNo`                                                                       AS `MaterialNo`,
       `a`.`MaterialType`                                                                     AS `MaterialType`,
       `a`.`OMaterialId`                                                                      AS `OMaterialId`,
       `a`.`OMaterialName`                                                                    AS `OMaterialName`,
       `a`.`NMaterialId`                                                                      AS `NMaterialId`,
       `a`.`NMaterialName`                                                                    AS `NMaterialName`,
       `a`.`OMaterialState`                                                                   AS `OMaterialState`,
       `a`.`NMaterialState`                                                                   AS `NMaterialState`,
       `a`.`ChangeStatus`                                                                     AS `ChangeStatus`,
       `a`.`SubmitPerson`                                                                     AS `SubmitPerson`,
       `a`.`SubmitName`                                                                       AS `SubmitName`,
       `a`.`SubmitTime`                                                                       AS `SubmitTime`,
       `a`.`AuditPerson`                                                                      AS `AuditPerson`,
       `a`.`AuditName`                                                                        AS `AuditName`,
       `a`.`AuditTime`                                                                        AS `AuditTime`,
       `a`.`CustomerId`                                                                       AS `CustomerId`,
       `a`.`CustomerName`                                                                     AS `CustomerName`,
       `a`.`IsRules`                                                                          AS `IsRules`,
       `a`.`RuleTips`                                                                         AS `RuleTips`,
       `a`.`Remark`                                                                           AS `Remark`,
       `a`.`ReasonId`                                                                         AS `ReasonId`,
       `fn_GetDictionaryNameById`(`a`.`ReasonId`)                                             AS `Reason`,
       `a`.`OtherReason`                                                                      AS `OtherReason`,
       1                                                                                      AS `SortOrder`
from `whcenter`.`tb_changestockinfo` `a`
where (`a`.`Deleted` = 0);

-- comment on column vi_changestockinfo.Id not supported: 主键(CH)

-- comment on column vi_changestockinfo.MainPartId not supported: 业务所属Id(tb_mainpartinfo.Id)

-- comment on column vi_changestockinfo.WarehouseId not supported: 所属仓库Id(tb_warehouse.Id)

-- comment on column vi_changestockinfo.ParentWarehouseId not supported: 所属仓库上级仓Id(tb_warehouse.Id)

-- comment on column vi_changestockinfo.ChangeStockType not supported: 更换类型(CH0 型号变更 CH1 状态变更)

-- comment on column vi_changestockinfo.MaterialNo not supported: 设备编码

-- comment on column vi_changestockinfo.MaterialType not supported: 设备物料类型

-- comment on column vi_changestockinfo.OMaterialId not supported: 原物料Id

-- comment on column vi_changestockinfo.OMaterialName not supported: 原物料名称

-- comment on column vi_changestockinfo.NMaterialId not supported: 新物料Id

-- comment on column vi_changestockinfo.NMaterialName not supported: 新物料名称

-- comment on column vi_changestockinfo.OMaterialState not supported: 原物料状态(0未加装1已加装2已拆装)

-- comment on column vi_changestockinfo.NMaterialState not supported: 新物料状态(0未加装1已加装2已拆装)

-- comment on column vi_changestockinfo.ChangeStatus not supported: 提交状态(0未提交1已提交2待审核3已驳回)

-- comment on column vi_changestockinfo.SubmitPerson not supported: 提交人Code

-- comment on column vi_changestockinfo.SubmitName not supported: 提交人姓名

-- comment on column vi_changestockinfo.SubmitTime not supported: 提交时间

-- comment on column vi_changestockinfo.AuditPerson not supported: 审核人Code

-- comment on column vi_changestockinfo.AuditName not supported: 审核人姓名

-- comment on column vi_changestockinfo.AuditTime not supported: 审核时间

-- comment on column vi_changestockinfo.CustomerId not supported: 客户Id

-- comment on column vi_changestockinfo.CustomerName not supported: 客户名称

-- comment on column vi_changestockinfo.IsRules not supported: 符合规则(0否1是)

-- comment on column vi_changestockinfo.RuleTips not supported: 规则提示

-- comment on column vi_changestockinfo.Remark not supported: 备注

-- comment on column vi_changestockinfo.ReasonId not supported: 变更原因(basic_datadictionary.Id)

-- comment on column vi_changestockinfo.OtherReason not supported: 其他原因

