create definer = user_wh@`%` view vi_whreservoir as
select `a`.`Id`                                                                                                      AS `Id`,
       `a`.`MainpartId`                                                                                              AS `MainpartId`,
       `fn_GetMainPartNameById`(`a`.`MainpartId`)                                                                    AS `MainPartName`,
       `a`.`WarehouseId`                                                                                             AS `WarehouseId`,
       `fn_GetWarehouseNameById`(`a`.`WarehouseId`)                                                                  AS `WarehouseName`,
       `a`.`Code`                                                                                                    AS `Code`,
       `a`.`Name`                                                                                                    AS `Name`,
       `a`.`TypeId`                                                                                                  AS `TypeId`,
       (case `a`.`TypeId`
            when 0 then '动销区'
            when 1 then '不动销区'
            when 2 then '滞销区'
            when 3
                then '售后区' end)                                                                                   AS `TypeName`,
       `a`.`SubmitPerson`                                                                                            AS `SubmitPerson`,
       `a`.`SubmitName`                                                                                              AS `SubmitName`,
       `a`.`SubmitTime`                                                                                              AS `SubmitTime`,
       `a`.`Enable`                                                                                                  AS `Enable`,
       (case `a`.`Enable` when 0 then '关闭' when 1 then '开启' end)                                                 AS `RvStatus`,
       1                                                                                                             AS `SortOrder`
from `whcenter`.`tb_whreservoir` `a`
where (`a`.`Deleted` = 0);

-- comment on column vi_whreservoir.Id not supported: 主键(WR)

-- comment on column vi_whreservoir.MainpartId not supported: 业务所属Id(tb_mainpartinfo.Id)

-- comment on column vi_whreservoir.WarehouseId not supported: 仓库Id(tb_warehouse.Id)

-- comment on column vi_whreservoir.Code not supported: 库区Code

-- comment on column vi_whreservoir.Name not supported: 库区名称

-- comment on column vi_whreservoir.TypeId not supported: 类型Id(0动销区1不动销区2滞销区3售后区)

-- comment on column vi_whreservoir.SubmitPerson not supported: 提交人Code

-- comment on column vi_whreservoir.SubmitName not supported: 提交人姓名

-- comment on column vi_whreservoir.SubmitTime not supported: 提交时间

-- comment on column vi_whreservoir.Enable not supported: 可用状态(0关闭1开启)

