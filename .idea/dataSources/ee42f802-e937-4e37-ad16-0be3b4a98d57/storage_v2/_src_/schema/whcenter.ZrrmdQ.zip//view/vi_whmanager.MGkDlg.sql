create definer = user_wh@`%` view vi_whmanager as
select `a`.`Id`                                                                     AS `Id`,
       `a`.`WarehouseId`                                                            AS `WarehouseId`,
       `a`.`UserId`                                                                 AS `UserId`,
       `a`.`LoginName`                                                              AS `LoginName`,
       `a`.`UserName`                                                               AS `UserName`,
       `a`.`UserTel`                                                                AS `UserTel`,
       (case max(ifnull(`a`.`IsDefault`, 0)) when 0 then '否' when 1 then '是' end) AS `IsDefaultManager`,
       (case max(if((`a`.`ManagerType` = 1), 1, 0)) when 1 then '是' else '否' end) AS `IsCheckManeger`,
       (case max(if((`a`.`ManagerType` = 2), 1, 0)) when 1 then '是' else '否' end) AS `IsServiceManeger`,
       1                                                                            AS `SortOrder`
from `whcenter`.`tb_whmanager` `a`
where (`a`.`Deleted` = 0)
group by `a`.`WarehouseId`, `a`.`UserId`, `a`.`LoginName`, `a`.`UserName`, `a`.`UserTel`;

-- comment on column vi_whmanager.Id not supported: 主键

-- comment on column vi_whmanager.WarehouseId not supported: 仓库Id(tb_warehouse.Id)

-- comment on column vi_whmanager.UserId not supported: 用户Id

-- comment on column vi_whmanager.LoginName not supported: 管理人员Code

-- comment on column vi_whmanager.UserName not supported: 管理人员名称

-- comment on column vi_whmanager.UserTel not supported: 负责人联系方式

