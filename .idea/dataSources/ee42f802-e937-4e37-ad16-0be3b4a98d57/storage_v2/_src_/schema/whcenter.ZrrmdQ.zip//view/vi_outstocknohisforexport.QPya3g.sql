create definer = user_wh@`%` view vi_outstocknohisforexport as
select `c`.`Id`                                                                      AS `Id`,
       `a`.`MainPartId`                                                              AS `MainPartId`,
       `a`.`ToMainPartId`                                                            AS `ToMainPartId`,
       `fn_GetMainPartNameById`(`a`.`MainPartId`)                                    AS `MainPartName`,
       `fn_GetMainPartNameById`(`a`.`ToMainPartId`)                                  AS `ToMainPartName`,
       `c`.`OwnerId`                                                                 AS `OwnerId`,
       `fn_GetOwnerNameById`(`c`.`OwnerId`)                                          AS `OwnerName`,
       `a`.`Id`                                                                      AS `OutStockId`,
       `b`.`Id`                                                                      AS `OutStockDetailId`,
       `a`.`OutStockNo`                                                              AS `OutStockNo`,
       `a`.`OutStockType`                                                            AS `OutStockType`,
       `fn_GetStockTypeById`(`a`.`OutStockType`)                                     AS `OutStockTypeName`,
       `a`.`WarehouseId`                                                             AS `WarehouseId`,
       ifnull(`fn_GetWarehouseNameById`(`a`.`WarehouseId`), `a`.`WarehouseName`)     AS `WarehouseName`,
       `a`.`ParentWarehouseId`                                                       AS `ParentWarehouseId`,
       `fn_GetWarehouseNameById`(`a`.`ParentWarehouseId`)                            AS `ParentWarehouseName`,
       `a`.`ToWarehouseId`                                                           AS `ToWarehouseId`,
       ifnull(`fn_GetWarehouseNameById`(`a`.`ToWarehouseId`), `a`.`ToWarehouseName`) AS `ToWarehouseName`,
       `a`.`ToParentWarehouseId`                                                     AS `ToParentWarehouseId`,
       `fn_GetWarehouseNameById`(`a`.`ToParentWarehouseId`)                          AS `ToParentWarehouseName`,
       `b`.`MaterialId`                                                              AS `MaterialId`,
       `b`.`MaterialName`                                                            AS `MaterialName`,
       `b`.`MaterialType`                                                            AS `MaterialType`,
       `c`.`MaterialNo`                                                              AS `MaterialNo`,
       '已加装'                                                                      AS `StockStatus`,
       1                                                                             AS `SortOrder`
from ((`whcenter`.`tb_outstockinfohis` `a` join `whcenter`.`tb_outstockdetailhis` `b`) join `whcenter`.`tb_outstockno` `c`)
where ((`a`.`Id` = `b`.`OutStockId`) and (`c`.`DetailId` = `b`.`Id`) and (`a`.`Deleted` = 0) and (`b`.`Deleted` = 0) and
       (`c`.`Deleted` = 0));

-- comment on column vi_outstocknohisforexport.Id not supported: 自增主键

-- comment on column vi_outstocknohisforexport.MainPartId not supported: 业务所属Id(tb_mainpartinfo.Id)

-- comment on column vi_outstocknohisforexport.ToMainPartId not supported: 调拨到业务所属Id

-- comment on column vi_outstocknohisforexport.OwnerId not supported: 货主Id(tb_ownerinfo.Id)

-- comment on column vi_outstocknohisforexport.OutStockId not supported: 主键(OT)

-- comment on column vi_outstocknohisforexport.OutStockDetailId not supported: 主键(OD)

-- comment on column vi_outstocknohisforexport.OutStockNo not supported: 出库单No

-- comment on column vi_outstocknohisforexport.OutStockType not supported: 出库类型(OT0 采购出库  OT1 迁移出库 OT2 调拨出库 OT3 批发出库 OT4 更换出库 OT5 组装出库 OT6 拆装出库 OT7修改出库 OT8 零售出库 OT9物资损耗出库 OT10 采购换货出库 OT11 生产退货出库 OT12 货主交易出库 OT13 代管出库 OT14 推广出库 OT15 货主变更出库 OT16 迁移更换出库)

-- comment on column vi_outstocknohisforexport.WarehouseId not supported: 所出仓库Id(tb_warehouse.Id)

-- comment on column vi_outstocknohisforexport.ParentWarehouseId not supported: 上级仓库Id(tb_warehouse.Id)

-- comment on column vi_outstocknohisforexport.ToWarehouseId not supported: 所入仓库Id(tb_warehouse.Id)

-- comment on column vi_outstocknohisforexport.ToParentWarehouseId not supported: 到上级仓库Id(tb_warehouse.Id)

-- comment on column vi_outstocknohisforexport.MaterialId not supported: 物料Id

-- comment on column vi_outstocknohisforexport.MaterialName not supported: 物料名称

-- comment on column vi_outstocknohisforexport.MaterialType not supported: 物料类型

-- comment on column vi_outstocknohisforexport.MaterialNo not supported: 物料编码

