create definer = user_wh@`%` view vi_planorderinfo as
select `a`.`Id`                                     AS `Id`,
       `a`.`MainPartId`                             AS `MainPartId`,
       `fn_GetMainPartNameById`(`a`.`MainPartId`)   AS `MainPartName`,
       `a`.`PlanNo`                                 AS `PlanNo`,
       '采购订货'                                   AS `PlanType`,
       `a`.`WarehouseId`                            AS `WarehouseId`,
       `fn_GetWarehouseNameById`(`a`.`WarehouseId`) AS `WarehouseName`,
       `a`.`PlanPerson`                             AS `PlanPerson`,
       `a`.`PlanName`                               AS `PlanName`,
       `a`.`AuditPerson`                            AS `AuditPerson`,
       `a`.`AuditName`                              AS `AuditName`,
       `a`.`AuditTime`                              AS `AuditTime`,
       `a`.`AuditState`                             AS `AuditState`,
       `a`.`Remark`                                 AS `Remark`,
       1                                            AS `SortOrder`
from `whcenter`.`tb_planorderinfo` `a`
where (`a`.`Deleted` = 0);

-- comment on column vi_planorderinfo.Id not supported: 主键Id(PO)

-- comment on column vi_planorderinfo.MainPartId not supported: 业务所属Id(tb_mainpartinfo.Id)

-- comment on column vi_planorderinfo.PlanNo not supported: 申请单号

-- comment on column vi_planorderinfo.WarehouseId not supported: 仓库Id

-- comment on column vi_planorderinfo.PlanPerson not supported: 下单人Code

-- comment on column vi_planorderinfo.PlanName not supported: 下单人姓名

-- comment on column vi_planorderinfo.AuditPerson not supported: 审核人Code

-- comment on column vi_planorderinfo.AuditName not supported: 审核人姓名

-- comment on column vi_planorderinfo.AuditTime not supported: 审核时间

-- comment on column vi_planorderinfo.AuditState not supported: 单据状态(0未提交1待审核2已通过3未通过)

-- comment on column vi_planorderinfo.Remark not supported: 备注

