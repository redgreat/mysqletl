create definer = user_wh@`%` view vi_instockinfodetail as
select `a`.`Id`               AS `Id`,
       `a`.`InStockId`        AS `InStockId`,
       `a`.`OwnerId`          AS `OwnerId`,
       `c`.`ShortName`        AS `OwnerShortName`,
       `c`.`Name`             AS `OwnerName`,
       `a`.`OrderDetailId`    AS `OrderDetailId`,
       `a`.`GoodsName`        AS `GoodsName`,
       `a`.`MaterialId`       AS `MaterialId`,
       `a`.`MaterialName`     AS `MaterialName`,
       `a`.`MaterialType`     AS `MaterialType`,
       `a`.`MaterialTypeCode` AS `MaterialTypeCode`,
       `a`.`MaterialUnit`     AS `MaterialUnit`,
       `a`.`ReservoirCode`    AS `ReservoirCode`,
       `a`.`SupplierId`       AS `SupplierId`,
       `b`.`ShortName`        AS `SupplierName`,
       `b`.`Name`             AS `SupplierFullName`,
       `a`.`InStockNum`       AS `InStockNum`,
       `a`.`InStockedNum`     AS `InStockedNum`,
       `a`.`InStockSurplus`   AS `InStockSurplus`,
       `a`.`InStockPrice`     AS `InStockPrice`,
       `a`.`IsCodeSingle`     AS `IsCodeSingle`,
       1                      AS `SortOrder`
from ((`whcenter`.`tb_instockdetail` `a` left join `whcenter`.`tb_ownerinfo` `c`
       on (((`c`.`Id` = `a`.`OwnerId`) and (`c`.`Deleted` = 0)))) left join `whcenter`.`tb_supplier` `b`
      on (((`b`.`Id` = `a`.`SupplierId`) and (`b`.`Deleted` = 0))))
where (`a`.`Deleted` = 0);

-- comment on column vi_instockinfodetail.Id not supported: 主键(ID)

-- comment on column vi_instockinfodetail.InStockId not supported: 入库单Id(tb_instockinfo.Id)

-- comment on column vi_instockinfodetail.OwnerId not supported: 应入货主Id(tb_ownerinfo.Id)

-- comment on column vi_instockinfodetail.OwnerShortName not supported: 货主简称

-- comment on column vi_instockinfodetail.OwnerName not supported: 货主名称

-- comment on column vi_instockinfodetail.OrderDetailId not supported: 订单明细Id

-- comment on column vi_instockinfodetail.GoodsName not supported: 商品名称

-- comment on column vi_instockinfodetail.MaterialId not supported: 物料Id

-- comment on column vi_instockinfodetail.MaterialName not supported: 物料名称

-- comment on column vi_instockinfodetail.MaterialType not supported: 物料类型

-- comment on column vi_instockinfodetail.MaterialTypeCode not supported: 物料类型Code

-- comment on column vi_instockinfodetail.MaterialUnit not supported: 物料单位

-- comment on column vi_instockinfodetail.ReservoirCode not supported: 库区Code(tb_whreservoir.Code)

-- comment on column vi_instockinfodetail.SupplierId not supported: 采购商Id(tb_supplier.Id)

-- comment on column vi_instockinfodetail.SupplierName not supported: 供应商简称

-- comment on column vi_instockinfodetail.SupplierFullName not supported: 供应商名称

-- comment on column vi_instockinfodetail.InStockNum not supported: 应入库数量

-- comment on column vi_instockinfodetail.InStockedNum not supported: 已入库数量

-- comment on column vi_instockinfodetail.InStockSurplus not supported: 入库单剩余量

-- comment on column vi_instockinfodetail.InStockPrice not supported: 入库参考价

-- comment on column vi_instockinfodetail.IsCodeSingle not supported: 是否独立编码(0否1是)

