create definer = user_wh@`%` view vi_wharea as
select `a`.`Id`                                   AS `Id`,
       `a`.`WarehouseId`                          AS `WarehouseId`,
       `a`.`IsDefault`                            AS `IsDefault`,
       `a`.`ProCode`                              AS `ProCode`,
       `fn_GetDistrictNameByCode`(`a`.`ProCode`)  AS `ProName`,
       `a`.`CityCode`                             AS `CityCode`,
       `fn_GetDistrictNameByCode`(`a`.`CityCode`) AS `CityName`,
       1                                          AS `SortOrder`
from `whcenter`.`tb_wharea` `a`
where (`a`.`Deleted` = 0);

-- comment on column vi_wharea.Id not supported: 主键(WA)

-- comment on column vi_wharea.WarehouseId not supported: 仓库Id(tb_warehouse.Id)

-- comment on column vi_wharea.IsDefault not supported: 是否默认(0否1是)

-- comment on column vi_wharea.ProCode not supported: 省份Code

-- comment on column vi_wharea.CityCode not supported: 城市Code

