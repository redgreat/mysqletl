create definer = user_wh@`%` view vi_materialstocktrace as
select `a`.`Id`                                                                               AS `Id`,
       `a`.`OwnerId`                                                                          AS `OwnerId`,
       `fn_GetOwnerShortNameById`(`a`.`OwnerId`)                                              AS `OwnerShortName`,
       `a`.`MaterialNo`                                                                       AS `MaterialNo`,
       `a`.`StockStatus`                                                                      AS `StockStatus`,
       `a`.`MaterialId`                                                                       AS `MaterialId`,
       `a`.`MaterialName`                                                                     AS `MaterialName`,
       `a`.`MaterialType`                                                                     AS `MaterialType`,
       `a`.`MaterialTypeCode`                                                                 AS `MaterialTypeCode`,
       `a`.`StockLocationId`                                                                  AS `StockLocationId`,
       `a`.`StockLocationName`                                                                AS `StockLocationName`,
       ifnull(`fn_GetWholeWarehouseNameById`(`a`.`StockLocationId`),
              `a`.`StockLocationName`)                                                        AS `ConcatStockLocationName`,
       `a`.`ParentWarehouseId`                                                                AS `ParentWarehouseId`,
       `a`.`ReservoirCode`                                                                    AS `ReservoirCode`,
       `a`.`LastStockId`                                                                      AS `LastStockId`,
       `a`.`LastStockNo`                                                                      AS `LastStockNo`,
       `a`.`LastDetailId`                                                                     AS `LastDetailId`,
       `a`.`LastStockType`                                                                    AS `LastStockType`,
       `fn_GetStockTypeById`(`a`.`LastStockType`)                                             AS `LastStockTypeName`,
       `a`.`CustSettleId`                                                                     AS `CustSettleId`,
       `a`.`CustSettleName`                                                                   AS `CustSettleName`,
       `a`.`IsTransporting`                                                                   AS `IsTransporting`,
       if((`b`.`Id` is null), 0, 1)                                                           AS `IsUnsalable`,
       `a`.`LastAuditTime`                                                                    AS `AuditTime`,
       `fn_GetStockAgeByNo`(`a`.`MaterialNo`)                                                 AS `StockAge`,
       `a`.`StockAgeStatus`                                                                   AS `StockAgeStatus`,
       1                                                                                      AS `SortOrder`
from (`whcenter`.`tb_materialstock` `a` left join `whcenter`.`tb_unsalableinfo` `b`
      on (((`b`.`MaterialId` = `a`.`MaterialId`) and (`b`.`Enable` = 1) and (`b`.`Deleted` = 0))))
where (`a`.`Deleted` = 0);

-- comment on column vi_materialstocktrace.Id not supported: 自增主键

-- comment on column vi_materialstocktrace.OwnerId not supported: 货主Id(tb_ownerinfo.Id)

-- comment on column vi_materialstocktrace.MaterialNo not supported: 物料编码

-- comment on column vi_materialstocktrace.StockStatus not supported: 设备在库状态(0未加装1已加装2已拆装)

-- comment on column vi_materialstocktrace.MaterialId not supported: 物料类型Id

-- comment on column vi_materialstocktrace.MaterialName not supported: 物料名称

-- comment on column vi_materialstocktrace.MaterialType not supported: 物料类型

-- comment on column vi_materialstocktrace.MaterialTypeCode not supported: 物料类型Code

-- comment on column vi_materialstocktrace.StockLocationId not supported: 所在位置Id(仓库Id/门店Id)

-- comment on column vi_materialstocktrace.StockLocationName not supported: 所在位置名称(仓库名称/门店名称)

-- comment on column vi_materialstocktrace.ParentWarehouseId not supported: 上级仓库Id

-- comment on column vi_materialstocktrace.ReservoirCode not supported: 库区Code(tb_whreservoir.Code)

-- comment on column vi_materialstocktrace.LastStockId not supported: 最后一次出入库单Id

-- comment on column vi_materialstocktrace.LastStockNo not supported: 最后一次出入库编码

-- comment on column vi_materialstocktrace.LastDetailId not supported: 最后一次出入库明细Id

-- comment on column vi_materialstocktrace.LastStockType not supported: 最后一次出入库类型

-- comment on column vi_materialstocktrace.CustSettleId not supported: 结算单位Id

-- comment on column vi_materialstocktrace.CustSettleName not supported: 结算单位名称

-- comment on column vi_materialstocktrace.IsTransporting not supported: 是否在途(0已签收1在途)

-- comment on column vi_materialstocktrace.AuditTime not supported: 最后一次审核时间

-- comment on column vi_materialstocktrace.StockAgeStatus not supported: 库龄预警状态(0未预警1一级预警2二级预警)

