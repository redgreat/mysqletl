create definer = user_wh@`%` view vi_allocatebatchinfo as
select `a`.`Id`                                                                 AS `Id`,
       `a`.`MainPartId`                                                         AS `MainPartId`,
       `fn_GetMainPartNameById`(`a`.`MainPartId`)                               AS `MainPartName`,
       `a`.`BatchNo`                                                            AS `BatchNo`,
       `a`.`BatchType`                                                          AS `BatchType`,
       (case `a`.`BatchType` when 'DB0' then '调入' when 'DB1' then '调出' end) AS `BatchTypeName`,
       `a`.`WarehouseId`                                                        AS `WarehouseId`,
       `fn_GetWarehouseNameById`(`a`.`WarehouseId`)                             AS `WarehouseName`,
       `a`.`ParentWarehouseId`                                                  AS `ParentWarehouseId`,
       `fn_GetWholeWarehouseNameById`(`a`.`WarehouseId`)                        AS `ConcatWarehouseName`,
       `a`.`AllocatePerson`                                                     AS `AllocatePerson`,
       `a`.`AllocateName`                                                       AS `AllocateName`,
       `a`.`AuditPerson`                                                        AS `AuditPerson`,
       `a`.`AuditName`                                                          AS `AuditName`,
       `a`.`IsUrgent`                                                           AS `IsUrgent`,
       `a`.`AuditTime`                                                          AS `AuditTime`,
       `a`.`AuditState`                                                         AS `AuditState`,
       `a`.`PredictTime`                                                        AS `PredictTime`,
       `a`.`Remark`                                                             AS `Remark`
from `whcenter`.`tb_allocatebatchinfo` `a`
where (`a`.`Deleted` = 0);

-- comment on column vi_allocatebatchinfo.Id not supported: 主键(AB)

-- comment on column vi_allocatebatchinfo.MainPartId not supported: 业务所属Id(tb_mainpartinfo.Id)

-- comment on column vi_allocatebatchinfo.BatchNo not supported: 调拨单号

-- comment on column vi_allocatebatchinfo.BatchType not supported: 批量调拨类型（DB0 调拨入 DB1 调拨出）

-- comment on column vi_allocatebatchinfo.WarehouseId not supported: 调拨入仓Id(tb_warehouse.Id)

-- comment on column vi_allocatebatchinfo.ParentWarehouseId not supported: 调拨入上级仓库Id(tb_warehouse.Id)

-- comment on column vi_allocatebatchinfo.AllocatePerson not supported: 下单人Code

-- comment on column vi_allocatebatchinfo.AllocateName not supported: 下单人姓名

-- comment on column vi_allocatebatchinfo.AuditPerson not supported: 审核人Code

-- comment on column vi_allocatebatchinfo.AuditName not supported: 审核人姓名

-- comment on column vi_allocatebatchinfo.IsUrgent not supported: 是否加急(0否1是)

-- comment on column vi_allocatebatchinfo.AuditTime not supported: 审核时间

-- comment on column vi_allocatebatchinfo.AuditState not supported: 单据状态(0已退回1待发货2备货中3待审核4已发货)

-- comment on column vi_allocatebatchinfo.PredictTime not supported: 预计发货时间

-- comment on column vi_allocatebatchinfo.Remark not supported: 备注

