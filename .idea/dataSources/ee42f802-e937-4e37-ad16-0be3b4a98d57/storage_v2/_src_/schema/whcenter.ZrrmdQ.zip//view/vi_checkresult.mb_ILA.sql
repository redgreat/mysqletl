create definer = user_wh@`%` view vi_checkresult as
select `c`.`Id`                                                                                  AS `Id`,
       `a`.`CheckNo`                                                                             AS `CheckNo`,
       `a`.`Id`                                                                                  AS `CheckStockId`,
       `b`.`Id`                                                                                  AS `CheckDetailId`,
       `a`.`WarehouseId`                                                                         AS `WarehouseId`,
       `fn_GetWarehouseNameById`(`a`.`WarehouseId`)                                              AS `WarehosueName`,
       `a`.`ParentWarehouseId`                                                                   AS `ParentWarehouseId`,
       `fn_GetWarehouseNameById`(`a`.`ParentWarehouseId`)                                        AS `ParentWarehouseName`,
       `a`.`CheckPerson`                                                                         AS `CheckPerson`,
       `a`.`CheckName`                                                                           AS `CheckName`,
       `a`.`WHManeger`                                                                           AS `WHManeger`,
       `a`.`WHManagerName`                                                                       AS `WHManagerName`,
       `a`.`ApplyTime`                                                                           AS `ApplyTime`,
       `a`.`ExpectEndTime`                                                                       AS `ExpectEndTime`,
       `a`.`StartTime`                                                                           AS `StartTime`,
       `a`.`EndTime`                                                                             AS `EndTime`,
       `b`.`MaterialId`                                                                          AS `MaterialId`,
       `b`.`MaterialName`                                                                        AS `MaterialName`,
       `b`.`MaterialType`                                                                        AS `MaterialType`,
       `b`.`IsCodeSingle`                                                                        AS `IsCodeSingle`,
       `c`.`Result`                                                                              AS `Result`,
       abs((ifnull(`b`.`ResultNum`, 0) - ifnull(`b`.`CheckNum`, 0)))                             AS `LossNum`,
       `c`.`ReviseState`                                                                         AS `ReviseState`,
       (case `c`.`Result`
            when 0 then '未分析'
            when 1 then '正常'
            when 2 then '盘损'
            when 3 then '盘盈'
            when 4 then '出库'
            when 5 then '在途'
            when 7 then '正常' end)                                                              AS `ResultName`,
       `c`.`MaterialNo`                                                                          AS `MaterialNo`,
       `c`.`ProfitLocationId`                                                                    AS `ProfitLocationId`,
       ifnull(`fn_GetWholeWarehouseNameById`(`c`.`ProfitLocationId`),
              `c`.`ProfitLocationName`)                                                          AS `ProfitLocationName`,
       if((`c`.`Result` = 3), if((`a`.`MainPartId` = `c`.`ProfitMainpartId`), '无', '有'), NULL) AS `MainPartWarror`,
       `c`.`InsertTime`                                                                          AS `InsertTime`,
       `c`.`Deleted`                                                                             AS `Deleted`,
       1                                                                                         AS `SortOrder`
from ((`whcenter`.`tb_checkstockinfo` `a` left join `whcenter`.`tb_checkstockdetail` `b`
       on (((`b`.`CheckStockId` = `a`.`Id`) and (`b`.`Deleted` = 0)))) left join `whcenter`.`tb_checkresult` `c`
      on (((`c`.`CheckDetailId` = `b`.`Id`) and (`c`.`Deleted` = 0))))
where (`a`.`Deleted` = 0);

-- comment on column vi_checkresult.Id not supported: 自增主键

-- comment on column vi_checkresult.CheckNo not supported: 盘点单号

-- comment on column vi_checkresult.CheckStockId not supported: 主键(CS)

-- comment on column vi_checkresult.CheckDetailId not supported: 主键(CD)

-- comment on column vi_checkresult.WarehouseId not supported: 盘点仓库Id

-- comment on column vi_checkresult.ParentWarehouseId not supported: 上级仓库Id

-- comment on column vi_checkresult.CheckPerson not supported: 任务发起人Code

-- comment on column vi_checkresult.CheckName not supported: 任务发起人姓名

-- comment on column vi_checkresult.WHManeger not supported: 仓库负责人Code

-- comment on column vi_checkresult.WHManagerName not supported: 仓库负责人姓名

-- comment on column vi_checkresult.ApplyTime not supported: 任务发起时间

-- comment on column vi_checkresult.ExpectEndTime not supported: 预计结束时间(盘点截至时间)

-- comment on column vi_checkresult.StartTime not supported: 盘点开始时间

-- comment on column vi_checkresult.EndTime not supported: 盘点结束时间

-- comment on column vi_checkresult.MaterialId not supported: 物料Id

-- comment on column vi_checkresult.MaterialName not supported: 物料名称

-- comment on column vi_checkresult.MaterialType not supported: 物料类型

-- comment on column vi_checkresult.IsCodeSingle not supported: 是否独立编码(0否1是)

-- comment on column vi_checkresult.Result not supported: 盘点结果(0未分析1正常2盘损3盘盈4销售出库5在途6不记录7出库扫码正常)

-- comment on column vi_checkresult.ReviseState not supported: 调整状态(0无1已调整)

-- comment on column vi_checkresult.MaterialNo not supported: 物料编码

-- comment on column vi_checkresult.ProfitLocationId not supported: 盘盈物料系统所在位置Id

-- comment on column vi_checkresult.InsertTime not supported: 写入时间

