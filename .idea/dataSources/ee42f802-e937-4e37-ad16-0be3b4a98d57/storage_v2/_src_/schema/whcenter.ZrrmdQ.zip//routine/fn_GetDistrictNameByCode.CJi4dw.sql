create
    definer = user_wh@`%` function fn_GetDistrictNameByCode(InCode varchar(10)) returns varchar(100)
    sql security invoker
BEGIN
   
   DECLARE Result VARCHAR(100);
   
   SELECT NAME
     INTO Result
     FROM whcenter.basic_district
    WHERE CODE=InCode;
   
   RETURN IFNULL(Result,'');
	
END;

