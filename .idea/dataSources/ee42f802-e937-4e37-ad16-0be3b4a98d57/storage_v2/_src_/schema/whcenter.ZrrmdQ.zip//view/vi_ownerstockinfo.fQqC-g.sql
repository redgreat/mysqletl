create definer = user_wh@`%` view vi_ownerstockinfo as
select `a`.`Id`                                                                                               AS `Id`,
       `b`.`MainPartId`                                                                                       AS `MainPartId`,
       `fn_GetMainPartNameById`(`b`.`MainPartId`)                                                             AS `MainPartName`,
       `a`.`OwnerId`                                                                                          AS `OwnerId`,
       `fn_GetOwnerNameById`(`a`.`OwnerId`)                                                                   AS `OwnerName`,
       `fn_GetOwnerShortNameById`(`a`.`OwnerId`)                                                              AS `OwnerShortName`,
       `a`.`WarehouseId`                                                                                      AS `WarehouseId`,
       `b`.`Name`                                                                                             AS `WarehouseName`,
       `b`.`Type`                                                                                             AS `Type`,
       (case `b`.`Type` when 0 then '虚拟仓' when 1 then '实体仓' end)                                        AS `TypeName`,
       `b`.`Mode`                                                                                             AS `Mode`,
       (case `b`.`Mode`
            when 0 then '普通仓'
            when 1 then '优工仓'
            when 2 then '门店仓'
            when 3 then '数据仓'
            when 4 then '租赁仓'
            when 5 then '自营仓'
            when 6
                then '客户仓' end)                                                                            AS `ModeName`,
       if((`b`.`LevelCode` = 1), `b`.`Id`, `b`.`ParentId`)                                                    AS `ParentWarehouseId`,
       `b`.`CustStoreId`                                                                                      AS `CustStoreId`,
       `b`.`CustStoreCode`                                                                                    AS `CustStoreCode`,
       `b`.`CustStoreName`                                                                                    AS `CustStoreName`,
       `fn_GetWarehouseNameById`(if((`b`.`LevelCode` = 1), `b`.`Id`, `b`.`ParentId`))                         AS `ParentWarehouseName`,
       `a`.`MaterialType`                                                                                     AS `MaterialType`,
       `a`.`MaterialTypeCode`                                                                                 AS `MaterialTypeCode`,
       `a`.`MaterialId`                                                                                       AS `MaterialId`,
       `a`.`MaterialName`                                                                                     AS `MaterialName`,
       `a`.`IsCodeSingle`                                                                                     AS `IsCodeSingle`,
       if((`c`.`Id` is null), '否', '是')                                                                     AS `IsUnSalable`,
       `a`.`StockNum`                                                                                         AS `StockNum`,
       `a`.`RealityNum`                                                                                       AS `RealityNum`,
       `a`.`AccessoryShortage`                                                                                AS `AccessoryShortage`,
       if((`bb`.`Id` is null), concat(ifnull(convert(`fn_GetStockWarningLowerLimitConcat`(`b`.`MainPartId`,
                                                                                          if((`b`.`LevelCode` = 1), `a`.`WarehouseId`, NULL),
                                                                                          `b`.`LevelCode`,
                                                                                          `a`.`MaterialTypeCode`,
                                                                                          `a`.`MaterialId`, `b`.`Mode`)
                                                     using utf8), ''), '-', ifnull(convert(
                                                                                           `fn_GetStockWarningUpperLimitConcat`(
                                                                                                   `b`.`MainPartId`,
                                                                                                   if((`b`.`LevelCode` = 1), `a`.`WarehouseId`, NULL),
                                                                                                   `b`.`LevelCode`,
                                                                                                   `a`.`MaterialTypeCode`,
                                                                                                   `a`.`MaterialId`,
                                                                                                   `b`.`Mode`) using
                                                                                           utf8), '')),
          NULL)                                                                                               AS `WarningLimitValue`,
       `b`.`LevelCode`                                                                                        AS `LevelCode`
from (((`whcenter`.`tb_ownerstockinfo` `a` left join `whcenter`.`tb_warehouse` `b`
        on (((`b`.`Id` = `a`.`WarehouseId`) and (`b`.`Deleted` = 0)))) left join `whcenter`.`tb_warehouse` `bb`
       on (((`bb`.`Id` = `b`.`ParentId`) and (`bb`.`Type` = 0) and (`b`.`Type` = 1) and
            (`bb`.`Deleted` = 0)))) left join `whcenter`.`tb_unsalableinfo` `c`
      on (((`c`.`MaterialId` = `a`.`MaterialId`) and (`c`.`MainPartId` = `b`.`MainPartId`) and (`c`.`Deleted` = 0) and
           (`c`.`Enable` = 1))))
where (`a`.`Deleted` = 0);

-- comment on column vi_ownerstockinfo.Id not supported: 自增主键

-- comment on column vi_ownerstockinfo.MainPartId not supported: 业务所属Id(tb_mainpartinfo.Id)

-- comment on column vi_ownerstockinfo.OwnerId not supported: 货主Id

-- comment on column vi_ownerstockinfo.WarehouseId not supported: 仓库Id(tb_warehouse.Id)

-- comment on column vi_ownerstockinfo.WarehouseName not supported: 仓库名称

-- comment on column vi_ownerstockinfo.Type not supported: 仓库属性(0虚拟仓1实体仓)

-- comment on column vi_ownerstockinfo.Mode not supported: 经营模式(0普通仓1优工仓2门店仓3数据仓4租赁仓5自营仓6客户仓)

-- comment on column vi_ownerstockinfo.CustStoreId not supported: 门店Id

-- comment on column vi_ownerstockinfo.CustStoreCode not supported: 门店Code

-- comment on column vi_ownerstockinfo.CustStoreName not supported: 门店名称

-- comment on column vi_ownerstockinfo.MaterialType not supported: 物料类型名称

-- comment on column vi_ownerstockinfo.MaterialTypeCode not supported: 物料类型Code

-- comment on column vi_ownerstockinfo.MaterialId not supported: 物料Id

-- comment on column vi_ownerstockinfo.MaterialName not supported: 物料名称

-- comment on column vi_ownerstockinfo.IsCodeSingle not supported: 是否独立编码(0否1是)

-- comment on column vi_ownerstockinfo.StockNum not supported: 在库数量

-- comment on column vi_ownerstockinfo.RealityNum not supported: 可用库存

-- comment on column vi_ownerstockinfo.AccessoryShortage not supported: 辅料缺少数量

-- comment on column vi_ownerstockinfo.LevelCode not supported: 仓库等级(1一级仓2二级仓)

